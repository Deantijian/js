(self.webpackChunkmingdao_web=self.webpackChunkmingdao_web||[]).push([[6706],{66706:(_e,qe,u)=>{"use strict";u.r(qe),u.d(qe,{default:()=>_a});var Y=u(88239),Nn=u(85105),$e=u.n(Nn),en=u(99663),nn=u(22600),tn=u(49135),an=u(93196),e=u(67294),An=u(49611),Zn=u.n(An),U=u(33867),V=u(86735),Tn=u(93967),ne=u.n(Tn),J=u(5017),Ln=u(53825),ke=u(77863),Bn=[{key:"view",list:[{type:"view",text:_l("\u89C6\u56FE"),icon:"view_eye"}]},{key:"aiAssistant",title:_l("AI \u52A9\u624B"),list:[{type:"assistant",text:_l("\u52A9\u624B"),icon:"contact_support",featureId:ke.UU.assistant},{type:"knowledgeBase",text:_l("\u77E5\u8BC6\u5E93"),icon:"import_contacts",featureId:ke.UU.assistant}]}],tr=[{text:_l("\u5168\u90E8\u7C7B\u578B"),value:1},{text:_l("\u89C6\u56FE"),value:2},{text:_l("\u5DE5\u4F5C\u6D41\u8282\u70B9"),value:3},{text:_l("\u81EA\u5B9A\u4E49\u9875\u9762\u7EC4\u4EF6"),value:4},{text:_l("\u8868\u5355\u63A7\u4EF6"),value:5}],Qn=[{text:_l("\u5168\u90E8"),value:2},{text:_l("\u5DF2\u542F\u7528"),value:1},{text:_l("\u672A\u542F\u7528"),value:0}],Dn=[{text:_l("\u6211\u5F00\u53D1\u7684"),value:"myPlugin"},{text:_l("\u7EC4\u7EC7"),value:"project"}],rn={project:[{text:_l("\u7248\u672C\u5386\u53F2"),value:"publishHistory"},{text:_l("\u73AF\u5883\u53C2\u6570"),value:"paramSetting"},{text:_l("\u4F7F\u7528\u660E\u7EC6"),value:"usageDetail"}],myPlugin:[{text:_l("\u8C03\u8BD5\u73AF\u5883"),value:"debugEnv"},{text:_l("\u63D0\u4EA4"),value:"commit"},{text:_l("\u53D1\u5E03\u5386\u53F2"),value:"publishHistory"},{text:_l("\u5BFC\u51FA\u5386\u53F2"),value:"exportHistory"}]},F={create:"create",debugEnv:"debugEnv",commit:"commit",usageDetail:"usageDetail",paramSetting:"paramSetting",publishHistory:"publishHistory",exportHistory:"exportHistory"},Fn={3:_l("\u5BC6\u7801\u4E0D\u6B63\u786E\uFF0C\u8BF7\u91CD\u65B0\u8F93\u5165"),4:_l("\u91CD\u8BD5\u6B21\u6570\u8D85\u6807"),5:_l("\u6587\u4EF6\u89E3\u6790\u9519\u8BEF"),8:_l("\u672A\u6388\u6743\u7684\u7EC4\u7EC7\uFF0C\u65E0\u6CD5\u5BFC\u5165"),11:_l("\u6388\u6743\u5DF2\u8FC7\u671F\uFF0C\u65E0\u6CD5\u5BFC\u5165"),12:_l("\u672A\u6388\u6743\u7684\u670D\u52A1\u5668\uFF0C\u65E0\u6CD5\u5BFC\u5165")},ee=u(15577),jn=(0,V.Z)([`
  width: 241px;
  height: 100%;
  background: #fff;
  border-right: 1px solid #ededed;
  .pLeft18 {
    padding-left: 18px;
  }
  .Height44 {
    height: 44px;
  }
  li {
    width: 230px;
    height: 44px;
    border-radius: 0px 22px 22px 0px;
    padding-left: 18px;
    margin-bottom: 8px;
    &:last-child {
      margin-bottom: 0;
    }

    span {
      font-weight: 600;
      font-size: 14px;
    }
    i {
      color: #757575;
      font-size: 16px;
      margin-right: 8px;
    }
    a {
      display: inline-flex;
      align-items: center;
      width: 100%;
      line-height: 44px;
      color: #333;
    }
    .freeTag {
      display: inline-block;
      line-height: 16px;
      padding: 2px 4px;
      border-radius: 2px;
      background: #f19f39;
      color: #fff;
      margin-left: 4px;
      font-size: 12px;
      font-weight: 500;
    }
    .upgradeIcon {
      color: #fdb432;
      margin-left: 6px;
      font-size: 16px;
    }

    &.isDisabled {
      color: #757575;
      &:hover {
        background: #fff;
      }
    }

    &.isCurrent {
      background: #e3f2fe;
      a {
        color: #2196f3;
        i {
          color: #2196f3;
        }
        .upgradeIcon {
          color: #fdb432 !important;
        }
      }
      &:hover {
        background: #e3f2fe;
      }
    }

    &:hover {
      background: #f5f5f5;
    }
  }
`],[`
  width: 241px;
  height: 100%;
  background: #fff;
  border-right: 1px solid #ededed;
  .pLeft18 {
    padding-left: 18px;
  }
  .Height44 {
    height: 44px;
  }
  li {
    width: 230px;
    height: 44px;
    border-radius: 0px 22px 22px 0px;
    padding-left: 18px;
    margin-bottom: 8px;
    &:last-child {
      margin-bottom: 0;
    }

    span {
      font-weight: 600;
      font-size: 14px;
    }
    i {
      color: #757575;
      font-size: 16px;
      margin-right: 8px;
    }
    a {
      display: inline-flex;
      align-items: center;
      width: 100%;
      line-height: 44px;
      color: #333;
    }
    .freeTag {
      display: inline-block;
      line-height: 16px;
      padding: 2px 4px;
      border-radius: 2px;
      background: #f19f39;
      color: #fff;
      margin-left: 4px;
      font-size: 12px;
      font-weight: 500;
    }
    .upgradeIcon {
      color: #fdb432;
      margin-left: 6px;
      font-size: 16px;
    }

    &.isDisabled {
      color: #757575;
      &:hover {
        background: #fff;
      }
    }

    &.isCurrent {
      background: #e3f2fe;
      a {
        color: #2196f3;
        i {
          color: #2196f3;
        }
        .upgradeIcon {
          color: #fdb432 !important;
        }
      }
      &:hover {
        background: #e3f2fe;
      }
    }

    &:hover {
      background: #f5f5f5;
    }
  }
`]),Pn=J.ZP.div(jn),Hn=function(n){(0,an.default)(r,n);function r(){return(0,en.default)(this,r),(0,tn.default)(this,(r.__proto__||$e()(r)).apply(this,arguments))}return(0,nn.default)(r,[{key:"componentWillReceiveProps",value:function(g){var i=g.match.params,d=i===void 0?{}:i;d.type?safeLocalStorageSetItem("pluginUrl",d.type):localStorage.removeItem("pluginUrl")}},{key:"render",value:function(){var g=this.props,i=g.match,d=i===void 0?{params:{}}:i,b=g.currentProjectId,I=g.isAdmin,x=d.params.type,o=x===void 0?"":x;return e.createElement(Pn,null,Bn.filter(function(a){return!(a.key==="aiAssistant"&&(!I||!(0,ee.XH)(b,ke.UU.assistant)||(0,ee.XH)(b,ke.UU.assistant)==="2"))}).map(function(a,w){return e.createElement(e.Fragment,null,a.title&&e.createElement("div",{className:"Gray_9e mTop28 pLeft18"},a.title),e.createElement("ul",{className:w===0?"mTop16":"mTop12"},a.list.map(function(p,h){return e.createElement("li",{key:h,className:ne()({isCurrent:p.type===o||!o&&p.type==="view",isDisabled:p.disabled})},e.createElement(Ln.Z,{className:"overflow_ellipsis pRight10",to:"/plugin/"+p.type},e.createElement(U.Z,{icon:p.icon}),e.createElement("span",null,p.text),p.type==="assistant"&&e.createElement("div",{className:"freeTag"},_l("\u9650\u514D"))))})))}))}}]),r}(e.Component);const Rn=Hn;var Un=u(98523),Oe=u(15028),On=u(22177),Be=u(25273),xe=u(54208),Te=u(43727),on=u(66946),ar=u(45142),ln=u(40987),rr=u(97373),Ie=u(94055),je=u(6100),v=u(12424),pe=u(93002),Mn=u(96486),O=u.n(Mn),Gn=u(15682),zn=u.n(Gn),Me=u(12935),Wn=u(72557),ie=u(70801),Pe=u(31261),ue=u(95248),Yn=(0,V.Z)([`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
`],[`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
`]),Vn=(0,V.Z)([`
  padding: 0 20px;
  line-height: 36px;
  cursor: pointer;
  color: #f44336;
  &:hover {
    background-color: #f5f5f5;
  }
`],[`
  padding: 0 20px;
  line-height: 36px;
  cursor: pointer;
  color: #f44336;
  &:hover {
    background-color: #f5f5f5;
  }
`]),Jn=(0,V.Z)([`
  .mui-dialog-desc {
    padding-top: 8px !important;
    font-size: 13px;
  }
  .passwordInput {
    box-shadow: none !important;
    line-height: 28px !important;
    border-radius: 3px !important;
    border: 1px solid #ccc !important;
    padding: 3px 10px !important;
    &.ant-input-affix-wrapper-focused {
      border-color: #2196f3 !important;
    }
  }
`],[`
  .mui-dialog-desc {
    padding-top: 8px !important;
    font-size: 13px;
  }
  .passwordInput {
    box-shadow: none !important;
    line-height: 28px !important;
    border-radius: 3px !important;
    border: 1px solid #ccc !important;
    padding: 3px 10px !important;
    &.ant-input-affix-wrapper-focused {
      border-color: #2196f3 !important;
    }
  }
`]),Xn=J.ZP.div(Yn),Kn=J.ZP.div(Vn),_n=(0,J.ZP)(ie.Z)(Jn);function qn(n){var r=n.pluginId,c=n.source,g=n.onDeleteSuccess,i=n.projectId,d=(0,e.useState)(!1),b=(0,v.Z)(d,2),I=b[0],x=b[1],o=(0,e.useState)(!1),a=(0,v.Z)(o,2),w=a[0],p=a[1],h=(0,e.useState)(!1),j=(0,v.Z)(h,2),C=j[0],T=j[1],D=(0,e.useState)(""),R=(0,v.Z)(D,2),k=R[0],s=R[1],S=function(){ue.Z.remove({id:r,source:c}).then(function(f){f&&(alert(_l("\u5220\u9664\u6210\u529F")),p(!1),g())})},P=function(){C?(0,ee.Gv)({password:k,success:function(){return S()}}):S()};return e.createElement(e.Fragment,null,e.createElement(Pe.Z,{action:["click"],popupClassName:"moreOption",getPopupContainer:function(){return document.body},popupVisible:I,onPopupVisibleChange:function(f){return x(f)},popupAlign:{points:["tr","bl"],offset:[25,5],overflow:{adjustX:!0,adjustY:!0}},popup:e.createElement(Xn,null,e.createElement(Kn,{onClick:function(f){f.stopPropagation(),x(!1),p(!0),(0,ee.Gv)({projectId:i,checkNeedAuth:!0,customActionName:"checkAccount",ignoreAlert:!0,success:function(){return T(!1)},fail:function(){return T(!0)}})}},_l("\u5220\u9664")))},e.createElement("div",{className:"operateIcon",onClick:function(f){return f.stopPropagation()}},e.createElement(U.Z,{icon:"moreop",className:"Font18 pointer"}))),e.createElement(_n,{width:480,visible:w,title:_l("\u5220\u9664\u63D2\u4EF6"),description:_l("\u5220\u9664\u540E\uFF0C\u4F7F\u7528\u8BE5\u63D2\u4EF6\u7684\u89C6\u56FE\u5C06\u65E0\u6CD5\u4F7F\u7528"),buttonType:"danger",onOk:P,onCancel:function(){return p(!1)}},C&&e.createElement(Wn.Z,{onChange:function(f){var Z=f.password;return s(Z)}})))}var Ne=u(3540),$n=u(12692),et=u(63239),Ye=u.n(et),sn=u(35710),nt=u(62232),Qe=u(97553),ve=u(88106),tt=u(91088),He=u(77632),at=u(44897),rt=(0,V.Z)([`
  .envList {
    .headTr,
    .dataItem {
      display: flex;
      align-items: center;
      margin: 0;
      padding: 15px 12px;
      border-bottom: 1px solid #ddd;
    }
    .headTr {
      color: #757575;
      font-weight: 500;
    }
    .dataItem {
      .ming.Dropdown {
        width: 220px;
      }
      .confirmBtn {
        background: #2196f3;
        :hover {
          background: #1565c0;
        }
      }
      .viewCon {
        display: flex;
        align-items: center;

        &.isValidView {
          cursor: pointer;
          &:hover {
            color: #2196f3;
            i {
              color: #2196f3 !important;
            }
          }
        }
      }
      &.isCreate {
        border: none;
      }
    }
    .appName,
    .worksheetName,
    .viewName {
      flex: 5;
      width: 0;
      padding-right: 8px;

      .isDel {
        color: #f44336;
      }
    }
    .operate {
      flex: 1;
      .icon-delete1 {
        color: #9d9d9d;
        font-size: 14px;
        cursor: pointer;
        &:hover {
          color: #f44336;
        }
      }
    }
  }
`],[`
  .envList {
    .headTr,
    .dataItem {
      display: flex;
      align-items: center;
      margin: 0;
      padding: 15px 12px;
      border-bottom: 1px solid #ddd;
    }
    .headTr {
      color: #757575;
      font-weight: 500;
    }
    .dataItem {
      .ming.Dropdown {
        width: 220px;
      }
      .confirmBtn {
        background: #2196f3;
        :hover {
          background: #1565c0;
        }
      }
      .viewCon {
        display: flex;
        align-items: center;

        &.isValidView {
          cursor: pointer;
          &:hover {
            color: #2196f3;
            i {
              color: #2196f3 !important;
            }
          }
        }
      }
      &.isCreate {
        border: none;
      }
    }
    .appName,
    .worksheetName,
    .viewName {
      flex: 5;
      width: 0;
      padding-right: 8px;

      .isDel {
        color: #f44336;
      }
    }
    .operate {
      flex: 1;
      .icon-delete1 {
        color: #9d9d9d;
        font-size: 14px;
        cursor: pointer;
        &:hover {
          color: #f44336;
        }
      }
    }
  }
`]),it=J.ZP.div(rt);function ot(n){var r=n.configType,c=n.debugEnvList,g=n.onChangeDebugEnvList,i=n.onUpdate,d=n.appList,b=n.belongType,I=n.onGetAppList,x=(0,pe.Z)({}),o=(0,v.Z)(x,2),a=o[0],w=o[1],p=(0,pe.Z)({visible:!1}),h=(0,v.Z)(p,2),j=h[0],C=h[1],T=function(s,S){var P=c.map(function(l,f){return f===S?s:l});g(P)},D=function(s,S){T(s,S),a[s.appId]||tt.Z.getWorksheetsByAppId({type:0,appId:s.appId}).then(function(P){if(P){var l=P.map(function(f){return{text:f.workSheetName,value:f.workSheetId}});w((0,ve.default)({},s.appId,l))}})},R=[{dataIndex:"appName",title:_l("\u5E94\u7528"),render:function(s,S){return s.isEdit?e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,placeholder:_l("\u8BF7\u9009\u62E9\u5E94\u7528"),data:d||[],value:s.appId,itemLoading:!d,onVisibleChange:function(l){l&&!d&&I()},onChange:function(l){return D((0,Y.default)({},s,{appId:l,worksheetId:null}),S)}}):e.createElement(Ie.default,{placement:"topLeft",title:s.appName||s.appId},e.createElement("div",{className:ne()("overflow_ellipsis",{isDel:!s.appName})},s.appName||_l("\u5DF2\u5220\u9664")))}},{dataIndex:"worksheetName",title:_l("\u5DE5\u4F5C\u8868"),render:function(s,S){return s.isEdit?e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,disabled:!s.appId,placeholder:_l("\u8BF7\u9009\u62E9\u5DE5\u4F5C\u8868"),data:a[s.appId]||[],value:s.worksheetId,onChange:function(l){return T((0,Y.default)({},s,{worksheetId:l}),S)}}):e.createElement("div",{className:ne()("overflow_ellipsis",{isDel:!s.worksheetName}),title:s.worksheetName},s.worksheetName?s.worksheetName:e.createElement(Ie.default,{title:s.worksheetId},_l("\u5DF2\u5220\u9664")))}},{dataIndex:"viewName",title:_l("\u89C6\u56FE"),render:function(s,S){var P=s.viewId&&s.viewName;return s.isEdit?r!==F.create?e.createElement(Qe.ZP,{type:"primary",className:"confirmBtn",disabled:!s.appId||!s.worksheetId,onClick:function(){i({debugEnvironments:c.map(function(f){return(0,Y.default)({},O().pick(f,["appId","worksheetId","viewId"]))})},function(f){T((0,Y.default)({},s,{isEdit:!1,appName:f.appName,worksheetName:f.worksheetName,viewName:f.viewName,viewId:f.viewId}),S),alert(_l("\u6DFB\u52A0\u8C03\u8BD5\u5E94\u7528\u6210\u529F"))},_l("\u6DFB\u52A0\u8C03\u8BD5\u5E94\u7528\u5931\u8D25"))}},_l("\u786E\u8BA4")):"":e.createElement("div",{className:ne()("viewCon",{isValidView:P}),onClick:function(){P&&(b==="myPlugin"?(0,He.O4)(s.worksheetId,s.viewId):(0,at.Z)({appId:s.appId,appName:s.appName,callback:function(){(0,ee.Ye)("app",s.appId),(0,He.O4)(s.worksheetId,s.viewId)}}))}},e.createElement("div",{className:"overflow_ellipsis",title:s.viewName},s.viewName||"-"),P&&e.createElement(U.Z,{icon:"launch",className:"mLeft4 Gray_9e"}))}},{dataIndex:"operate",title:"",render:function(s,S){return s.isEdit?null:e.createElement(U.Z,{icon:"delete1",onClick:function(){ie.Z.confirm({title:_l("\u5220\u9664\u8C03\u8BD5\u5E94\u7528"),buttonType:"danger",onOk:function(){var f=c.filter(function(Z,y){return y!==S});i({debugEnvironments:f.map(function(Z){return(0,Y.default)({},O().pick(Z,["appId","worksheetId","viewId"]))})},function(){g(f),alert(_l("\u5220\u9664\u8C03\u8BD5\u5E94\u7528\u6210\u529F"))},_l("\u5220\u9664\u8C03\u8BD5\u5E94\u7528\u5931\u8D25"))}})}})}}];return e.createElement(it,null,r===F.create&&e.createElement("p",{className:"Font14 mBottom0 mLeft12 mTop24"},_l("\u9009\u62E9\u5728\u7EBF\u8C03\u8BD5\u73AF\u5883")),e.createElement("div",{className:"envList"},r!==F.create&&e.createElement("div",{className:"headTr"},R.map(function(k,s){return e.createElement("div",{key:s,className:""+k.dataIndex},k.title)})),c.map(function(k,s){return e.createElement("div",{key:s,className:ne()("dataItem",{isCreate:r===F.create})},R.filter(function(S){return r!==F.create||S.dataIndex!=="operate"}).map(function(S,P){return e.createElement("div",{key:s+"-"+P,className:""+S.dataIndex},S.render?S.render(k,s):k[S.dataIndex])}))})),r!==F.create&&!c.filter(function(k){return k.isEdit}).length&&e.createElement("div",{className:"mTop24 InlineBlock ThemeColor ThemeHoverColor2 pointer",onClick:function(){var s=c.concat([{isEdit:!0}]);g(s)}},_l("+ \u8C03\u8BD5\u5E94\u7528")))}var cn=u(12387),lt=u(30381),Ee=u.n(lt),Ve=u(36164),ir=u(6538),st=u(14321),Je=u(20845),Xe=u(1952),ct=u(9958),dt=u(71792),ut=u(86069),pt=u(22252),ft=u(36964),dn=u.n(ft),mt=(0,V.Z)([`
  margin-bottom: 16px;
  .labelText {
    display: flex;
    align-items: center;
    color: #757575;
    margin-bottom: 8px;
    .requiredStar {
      color: #f44336;
      margin-left: 4px;
      font-weight: bold;
    }
    i {
      font-size: 14px;
      color: #bdbdbd;
      margin-left: 8px;
    }
  }
  input {
    width: 100%;
    font-size: 13px !important;
    &.notEditPwd {
      background: #f5f5f5;
      border: none;
    }
  }
  .pwdOperate {
    min-width: 82px;
  }
  .error {
    color: #f44336;
    margin-top: 5px;
  }

  .ant-picker {
    width: 100%;
    height: 36px;
    transition: none;
    border-color: #ccc;
    border-radius: 3px;
    box-shadow: none;
    .ant-picker-input {
      input {
        font-size: 13px !important;
      }
    }
    &:hover {
      border-color: #bbb;
    }
    &.ant-picker-focused {
      border-color: #1e88e5;
    }
  }
  &.fitContent {
    width: fit-content;
  }
`],[`
  margin-bottom: 16px;
  .labelText {
    display: flex;
    align-items: center;
    color: #757575;
    margin-bottom: 8px;
    .requiredStar {
      color: #f44336;
      margin-left: 4px;
      font-weight: bold;
    }
    i {
      font-size: 14px;
      color: #bdbdbd;
      margin-left: 8px;
    }
  }
  input {
    width: 100%;
    font-size: 13px !important;
    &.notEditPwd {
      background: #f5f5f5;
      border: none;
    }
  }
  .pwdOperate {
    min-width: 82px;
  }
  .error {
    color: #f44336;
    margin-top: 5px;
  }

  .ant-picker {
    width: 100%;
    height: 36px;
    transition: none;
    border-color: #ccc;
    border-radius: 3px;
    box-shadow: none;
    .ant-picker-input {
      input {
        font-size: 13px !important;
      }
    }
    &:hover {
      border-color: #bbb;
    }
    &.ant-picker-focused {
      border-color: #1e88e5;
    }
  }
  &.fitContent {
    width: fit-content;
  }
`]),Re=J.ZP.div(mt);function gt(n){var r=n.onClose,c=n.pluginId,g=n.releaseId,i=n.source,d=n.onExportSuccess,b=(0,e.useState)(!1),I=(0,v.Z)(b,2),x=I[0],o=I[1],a=(0,pe.Z)({}),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)(!1),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=(0,e.useState)(!1),k=(0,v.Z)(R,2),s=k[0],S=k[1],P=(0,e.useState)(!1),l=(0,v.Z)(P,2),f=l[0],Z=l[1],y={"zh-Hans":ct.Z,"zh-Hant":ut.Z,en:pt.Z,ja:dt.Z},H=y[md.global.Account.lang],_=function(){if(x){if(!/^[0-9A-Za-z]{8,20}$/.test(p.password)){alert(_l("\u5BC6\u7801\u4E0D\u7B26\u5408\u89C4\u8303"),3);return}if(p.projects&&p.projects.length>10){alert(_l("\u6388\u6743\u7EC4\u7EC7\u4E0D\u80FD\u8D85\u8FC710\u4E2A"),3);return}}Z(!0),ue.Z.export({id:c,releaseId:g,source:i,profile:x?p:void 0}).then(function(Q){Q&&(Z(!1),alert(_l("\u63D2\u4EF6\u5BFC\u51FA\u6210\u529F")),r(),d&&d())}).catch(function(Q){return Z(!1)})};return e.createElement(ie.Z,{visible:!0,width:580,title:_l("\u5BFC\u51FA\u63D2\u4EF6"),description:_l("\u5C06\u63D2\u4EF6\u5BFC\u51FA\u4E3A .mdye \u683C\u5F0F\uFF0C\u53EF\u4EE5\u5BFC\u5165\u5230\u5176\u4ED6\u7EC4\u7EC7\u4F7F\u7528"),okText:f?_l("\u5BFC\u51FA\u4E2D..."):_l("\u5BFC\u51FA"),okDisabled:x&&!p.password||f,onOk:_,onCancel:r},e.createElement(Re,{className:"fitContent"},e.createElement(Je.Z,{text:_l("\u5BFC\u5165\u65F6\u6821\u9A8C\u6388\u6743\u5BC6\u94A5"),checked:x,onClick:function(Q){return o(!Q)}})),x&&e.createElement(e.Fragment,null,e.createElement("div",{className:"flexRow"},e.createElement(Re,{className:"flex"},e.createElement("div",{className:"labelText"},e.createElement("span",null,_l("\u5BC6\u7801")),e.createElement("span",{className:"requiredStar"},"*")),e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement(Ne.Z,{className:!s&&p.password?"notEditPwd":"",placeholder:_l("\u8F93\u5165\u5BC6\u7801"),value:p.password,onChange:function(Q){return h({password:Q})},onFocus:function(){return S(!0)},onBlur:function(Q){Q.target.value&&(D(!/^[0-9A-Za-z]{8,20}$/.test(Q.target.value)),S(!1))}}),e.createElement("div",{className:"pwdOperate"},!s&&p.password?e.createElement(dn(),{className:"pointer Gray_9e ThemeHoverColor3 mLeft16",component:"span","data-clipboard-text":p.password,onSuccess:function(){return alert(_l("\u590D\u5236\u6210\u529F"))}},e.createElement(Ie.default,{title:_l("\u590D\u5236"),placement:"bottom"},e.createElement(U.Z,{icon:"content-copy"}))):e.createElement("span",{className:"ThemeColor ThemeHoverColor2 pointer mLeft10 mRight20 nowrap",onMouseDown:function(){h({password:(0,ee.ne)(8)}),S(!1)}},_l("\u968F\u673A\u751F\u6210")))),T&&e.createElement("div",{className:"error"},_l("\u8BF7\u8F93\u51658-20\u4F4D\u5B57\u7B26\uFF0C\u4EC5\u652F\u6301\u6570\u5B57\u548C\u82F1\u6587\u5B57\u6BCD"))),e.createElement(Re,{className:"flex"},e.createElement("div",{className:"labelText"},e.createElement("span",null," ",_l("\u6388\u6743\u5230\u671F\u65F6\u95F4")),e.createElement(Ie.default,{title:_l("\u63D2\u4EF6\u5230\u671F\u540E\u4E0D\u53EF\u7528\uFF0C\u7559\u7A7A\u5219\u4E3A\u6C38\u4E45\u6709\u6548")},e.createElement(U.Z,{icon:"info_outline"}))),e.createElement(st.default,{locale:H,placeholder:_l("\u8BF7\u9009\u62E9\u6388\u6743\u5230\u671F\u65F6\u95F4"),showNow:!1,allowClear:!0,disabledDate:function(Q){return Q<Ee()().endOf("day")},format:"YYYY-MM-DD 00:00",onChange:function(Q){return h({validityPeriod:Q?Ee()(Q).format("YYYY-MM-DD"):void 0})}}))),e.createElement(Re,null,e.createElement("div",{className:"labelText"},e.createElement("span",null," ",_l("\u6388\u6743\u7ED9\u6307\u5B9A\u7EC4\u7EC7")),e.createElement(Ie.default,{title:_l("\u4E0D\u5728\u8BE5\u5217\u8868\u5185\u7684\u7EC4\u7EC7\u4E0D\u53EF\u5BFC\u5165\uFF0C\u7559\u7A7A\u5219\u6240\u6709\u7EC4\u7EC7\u53EF\u5BFC\u5165")},e.createElement(U.Z,{icon:"info_outline"}))),e.createElement(Ve.Z,{className:"Font13",placeholder:_l(`\u7EC4\u7EC7\u7F16\u53F7\u683C\u5F0F\uFF1Axxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
\u4E00\u884C\u4E00\u4E2A\uFF0C\u6700\u591A10\u4E2A`),minHeight:100,onChange:function(Q){h({projects:Q.split(/[\r\n]/).filter(function(G){return G.trim()}).map(function(G){return G.trim()})})}})),e.createElement(Re,null,e.createElement("div",{className:"labelText"},e.createElement("span",null," ",_l("\u6388\u6743\u7ED9\u6307\u5B9A\u670D\u52A1\u5668\uFF08\u79C1\u6709\u90E8\u7F72\uFF09")),e.createElement(Ie.default,{title:_l("\u6307\u5B9A\u540E\u4EC5\u8BE5\u670D\u52A1\u5668\u53EF\u5BFC\u5165\uFF0C\u7559\u7A7A\u5219\u4E0D\u9650\u5236")},e.createElement(U.Z,{icon:"info_outline"}))),e.createElement(Ne.Z,{placeholder:_l("\u8F93\u5165\u79C1\u6709\u90E8\u7F72\u670D\u52A1\u5668ID"),value:(p.servers||[])[0],onChange:function(Q){return h({servers:[Q]})}}))))}const ht=function(n){return(0,Xe.Z)(gt,(0,Y.default)({},n))};var xt=(0,V.Z)([`
  .headTr,
  .dataItem {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 12px 16px;
    border-bottom: 1px solid #ddd;
    .operate {
      text-align: right;
    }
  }
  .headTr {
    color: #757575;
    font-weight: 500;
  }
  .dataItem {
    &:hover {
      background: #f5f5f5;
      .operateCon {
        display: block;
      }
    }
    .currentTag {
      height: 24px;
      line-height: 24px;
      padding: 0px 8px;
      background: rgba(76, 175, 80, 0.12);
      border-radius: 36px;
      color: #4caf50;
      font-weight: 600;
      font-size: 12px;
      margin: 0px 6px;
      white-space: nowrap;
    }
    img {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      margin-right: 4px;
    }
    .operateCon {
      display: none;

      .redBtn {
        color: #f44336;
        margin-left: 12px;
      }
      span {
        cursor: pointer;
        &:hover {
          opacity: 0.8;
        }
      }
    }
  }

  .commitList {
    .version,
    .message {
      width: 0;
      padding-right: 8px;
    }
    .message {
      flex: 6;
    }
    .version,
    .commitUser {
      flex: 4;
    }
    .commitTime {
      flex: 3;
    }
    .operate {
      flex: 2;
    }
  }

  .publishHistoryList {
    .version,
    .operate {
      width: 116px;
    }

    .publisher,
    .pubTime {
      flex: 4;
    }
    .description {
      flex: 6;
    }
    .publisher,
    .description {
      width: 0;
      padding-right: 5px;
    }
  }

  .usageDetailList {
    .appName,
    .worksheetName,
    .viewName,
    .createUser {
      flex: 4;
      width: 0;
      padding-right: 8px;
    }
    .createTime {
      flex: 3;
    }
    .viewCon {
      display: flex;
      align-items: center;
      cursor: pointer;
      &:hover {
        color: #2196f3;
        i {
          color: #2196f3 !important;
        }
      }
    }
  }

  .exportHistoryList {
    .versionCode,
    .operator,
    .secretKey,
    .exportFile {
      flex: 2;
    }
    .createTime {
      flex: 3;
    }
    .operate {
      flex: 1;
    }
  }
`],[`
  .headTr,
  .dataItem {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 12px 16px;
    border-bottom: 1px solid #ddd;
    .operate {
      text-align: right;
    }
  }
  .headTr {
    color: #757575;
    font-weight: 500;
  }
  .dataItem {
    &:hover {
      background: #f5f5f5;
      .operateCon {
        display: block;
      }
    }
    .currentTag {
      height: 24px;
      line-height: 24px;
      padding: 0px 8px;
      background: rgba(76, 175, 80, 0.12);
      border-radius: 36px;
      color: #4caf50;
      font-weight: 600;
      font-size: 12px;
      margin: 0px 6px;
      white-space: nowrap;
    }
    img {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      margin-right: 4px;
    }
    .operateCon {
      display: none;

      .redBtn {
        color: #f44336;
        margin-left: 12px;
      }
      span {
        cursor: pointer;
        &:hover {
          opacity: 0.8;
        }
      }
    }
  }

  .commitList {
    .version,
    .message {
      width: 0;
      padding-right: 8px;
    }
    .message {
      flex: 6;
    }
    .version,
    .commitUser {
      flex: 4;
    }
    .commitTime {
      flex: 3;
    }
    .operate {
      flex: 2;
    }
  }

  .publishHistoryList {
    .version,
    .operate {
      width: 116px;
    }

    .publisher,
    .pubTime {
      flex: 4;
    }
    .description {
      flex: 6;
    }
    .publisher,
    .description {
      width: 0;
      padding-right: 5px;
    }
  }

  .usageDetailList {
    .appName,
    .worksheetName,
    .viewName,
    .createUser {
      flex: 4;
      width: 0;
      padding-right: 8px;
    }
    .createTime {
      flex: 3;
    }
    .viewCon {
      display: flex;
      align-items: center;
      cursor: pointer;
      &:hover {
        color: #2196f3;
        i {
          color: #2196f3 !important;
        }
      }
    }
  }

  .exportHistoryList {
    .versionCode,
    .operator,
    .secretKey,
    .exportFile {
      flex: 2;
    }
    .createTime {
      flex: 3;
    }
    .operate {
      flex: 1;
    }
  }
`]),vt=(0,V.Z)([`
  text-align: center !important;
  .iconCon {
    width: 130px;
    height: 130px;
    line-height: 130px;
    background: #f5f5f5;
    border-radius: 50%;
    margin: 64px auto 0;
    color: #9e9e9e;
  }
`],[`
  text-align: center !important;
  .iconCon {
    width: 130px;
    height: 130px;
    line-height: 130px;
    background: #f5f5f5;
    border-radius: 50%;
    margin: 64px auto 0;
    color: #9e9e9e;
  }
`]),Et=(0,V.Z)([`
  display: flex;
  margin-bottom: 16px;
  .labelText {
    width: 140px;
    color: #757575;
  }
  .passwordBox {
    width: 180px;
    height: 36px;
    line-height: 36px;
    padding: 0 12px;
    border-radius: 3px;
    background: #f5f5f5;
  }
  .expired {
    color: #f44336;
  }
`],[`
  display: flex;
  margin-bottom: 16px;
  .labelText {
    width: 140px;
    color: #757575;
  }
  .passwordBox {
    width: 180px;
    height: 36px;
    line-height: 36px;
    padding: 0 12px;
    border-radius: 3px;
    background: #f5f5f5;
  }
  .expired {
    color: #f44336;
  }
`]),bt=J.ZP.div(xt),It=J.ZP.div(vt),Ge=J.ZP.div(Et);function Ct(n){var r=n.data,c=n.onClose,g=r.password,i=r.projects,d=r.servers,b=r.validityPeriod,I=Ee()().format("YYYY-MM-DD"),x=b&&Ee()(b).diff(Ee()(I),"days");return e.createElement(ie.Z,{visible:!0,title:_l("\u6388\u6743\u5BC6\u94A5"),width:480,onCancel:c,showFooter:!1},e.createElement(Ge,{className:"alignItemsCenter"},e.createElement("div",{className:"labelText"},_l("\u5BC6\u7801")),e.createElement("div",{className:"flex flexRow alignItemsCenter"},e.createElement("div",{className:"passwordBox"},g),e.createElement(dn(),{className:"pointer Gray_9e ThemeHoverColor3 mLeft16",component:"span","data-clipboard-text":g,onSuccess:function(){return alert(_l("\u590D\u5236\u6210\u529F"))}},e.createElement(Ie.default,{title:_l("\u590D\u5236"),placement:"bottom"},e.createElement(U.Z,{icon:"content-copy"}))))),b&&e.createElement(Ge,null,e.createElement("div",{className:"labelText"},_l("\u6388\u6743\u5230\u671F\u65F6\u95F4")),e.createElement("div",{className:"flex"},e.createElement("span",null,Ee()(b).format("YYYY-MM-DD 00:00")),e.createElement("span",{className:"mLeft8 "+(x>0?"Gray_75":"expired")},x>0?_l("(\u5269\u4F59")+x+_l("\u5929)"):_l("(\u5DF2\u8FC7\u671F)")))),!!i.length&&e.createElement(Ge,null,e.createElement("div",{className:"labelText"},_l("\u6388\u6743\u7ED9\u6307\u5B9A\u7EC4\u7EC7")),e.createElement("div",{className:"flex"},i.map(function(o){return e.createElement("div",null,o)}))),!!d.length&&e.createElement(Ge,null,e.createElement("div",{className:"labelText"},_l("\u6388\u6743\u7ED9\u6307\u5B9A\u670D\u52A1\u5668")),e.createElement("div",{className:"flex"},d[0])))}function ze(n){var r,c,g=n.belongType,i=n.configType,d=n.list,b=d===void 0?[]:d,I=n.currentVersion,x=n.latestVersion,o=n.debugConfiguration,a=n.pluginId,w=n.onRefreshList,p=n.onRefreshDetail,h=n.keywords,j=n.hasOperateAuth,C=n.onDelete,T=n.projectId,D=n.isAdmin,R=n.onExportSuccess,k=n.publishType,s=g==="myPlugin"?0:1,S=(0,e.useState)({visible:!1}),P=(0,v.Z)(S,2),l=P[0],f=P[1],Z=(0,e.useState)({visible:!1}),y=(0,v.Z)(Z,2),H=y[0],_=y[1],X=function(t,E){ie.Z.confirm({title:t===F.commit?_l("\u5220\u9664\u63D0\u4EA4"):_l("\u5220\u9664\u5386\u53F2\u7248\u672C"),buttonType:"danger",description:t===F.commit?_l("\u5F7B\u5E95\u5220\u9664\u63D0\u4EA4\u7684\u4EE3\u7801\uFF0C\u4E0D\u53EF\u6062\u590D"):_l("\u5F7B\u5E95\u5220\u9664\u5386\u53F2\u7248\u672C\uFF0C\u4E0D\u53EF\u6062\u590D"),onOk:function(){(t===F.commit?ue.Z.removeCommit({id:E}):ue.Z.removeRelease({id:E,source:s,pluginId:a})).then(function(L){L&&(alert(_l("\u5220\u9664\u6210\u529F")),C(E))})}})},Q=(r={},(0,ve.default)(r,F.commit,[{dataIndex:"message",title:_l("\u8BF4\u660E"),render:function(t){return e.createElement("div",{className:"overflow_ellipsis bold",title:t.message},t.message)}},{dataIndex:"version",title:_l("\u7248\u672C"),render:function(t){return t.versionTags?e.createElement("div",{className:"bold overflow_ellipsis",title:t.versionTags.join(",")},t.versionTags.join(", ")):_l("\u672A\u53D1\u5E03")}},{dataIndex:"commitUser",title:_l("\u63D0\u4EA4\u4EBA"),render:function(t){return e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("img",{src:t.author.avatar}),e.createElement("span",null,t.author.fullname))}},{dataIndex:"commitTime",title:_l("\u63D0\u4EA4\u65F6\u95F4"),render:function(t){return Ee()(t.commitTime).format("YYYY-MM-DD HH:mm")}},{dataIndex:"operate",renderTitle:function(){return e.createElement(U.Z,{icon:"refresh1",className:"Font18 pointer Gray_9e Hover_21",onClick:function(){return w()}})},render:function(t){return e.createElement("div",{className:"operateCon"},e.createElement("span",{className:"ThemeColor",onClick:function(){return f({visible:!0,commitId:t.id})}},_l("\u53D1\u5E03")),e.createElement("span",{className:"redBtn",onClick:function(){return X(F.commit,t.id)}},_l("\u5220\u9664")))}}]),(0,ve.default)(r,F.publishHistory,[{dataIndex:"version",title:_l("\u7248\u672C"),render:function(t){return e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("span",{className:"bold overflow_ellipsis",title:t.versionCode},t.versionCode),t.versionCode===I.versionCode&&e.createElement("div",{className:"currentTag"},_l("\u5F53\u524D")))}},{dataIndex:"publisher",title:s===0?_l("\u53D1\u5E03\u4EBA"):_l("\u64CD\u4F5C\u4EBA"),render:function(t){return e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("img",{src:t.publisher.avatar}),e.createElement("span",{title:t.publisher.fullname,className:"overflow_ellipsis"},t.publisher.fullname),s===1&&e.createElement("span",{className:"mLeft4 mRight5 nowrap"},k===2?_l("(\u5BFC\u5165)"):_l("(\u53D1\u5E03)")))}},{dataIndex:"pubTime",title:s===0?_l("\u53D1\u5E03\u65F6\u95F4"):_l("\u64CD\u4F5C\u65F6\u95F4"),render:function(t){return e.createElement("div",null,t.pubTime?createTimeSpan(t.pubTime):"")}},{dataIndex:"description",title:_l("\u7248\u672C\u8BF4\u660E"),render:function(t){return e.createElement("div",{className:"overflow_ellipsis",title:t.description},t.description)}},{dataIndex:"operate",renderTitle:function(){return e.createElement(U.Z,{icon:"refresh1",className:"Font18 pointer Gray_9e Hover_21",onClick:function(){return w()}})},render:function(t){return e.createElement("div",{className:"operateCon"},s===0&&e.createElement("span",{className:"mRight12 ThemeColor",onClick:function(){return ht({pluginId:a,releaseId:t.id,source:s,onExportSuccess:R})}},_l("\u5BFC\u51FA")),t.versionCode===I.versionCode&&t.expireDays>=0&&(t.expireDays===0?e.createElement("span",{className:"redBtn"},_l("(\u5DF2\u8FC7\u671F)")):e.createElement("span",{className:"Gray_75"},_l("(\u5269\u4F59")+t.expireDays+_l("\u5929)"))),t.versionCode!==I.versionCode&&(t.expireDays===0?e.createElement("span",{className:"redBtn"},_l("(\u5DF2\u8FC7\u671F)")):e.createElement("span",{className:"ThemeColor",onClick:function(){ie.Z.confirm({title:_l("\u5207\u6362\u5230\u5F53\u524D\u7248\u672C \uFF08"+t.versionCode+"\uFF09"),onOk:function(){ue.Z.rollback({pluginId:a,releaseId:t.id,source:s}).then(function(L){L&&(alert(_l("\u5207\u6362\u7248\u672C\u6210\u529F")),w(),p())})}})}},_l("\u8BBE\u4E3A\u5F53\u524D\u7248\u672C"))))}}]),(0,ve.default)(r,F.usageDetail,[{dataIndex:"appName",title:_l("\u5E94\u7528"),render:function(t){return e.createElement("div",{className:"overflow_ellipsis",title:(t.app||{}).appName},(t.app||{}).appName)}},{dataIndex:"worksheetName",title:_l("\u5DE5\u4F5C\u8868"),render:function(t){return e.createElement("div",{className:"overflow_ellipsis",title:(t.worksheet||{}).name},(t.worksheet||{}).name)}},{dataIndex:"viewName",title:_l("\u89C6\u56FE"),render:function(t){return e.createElement("div",{className:"viewCon",onClick:function(){return(0,He.O4)(t.worksheet.id,t.view.id)}},e.createElement("div",{className:"overflow_ellipsis",title:(t.view||{}).name},(t.view||{}).name||"-"),(t.view||{}).name&&e.createElement(U.Z,{icon:"launch",className:"mLeft4 Gray_9e"}))}},{dataIndex:"createUser",title:_l("\u521B\u5EFA\u8005"),render:function(t){return e.createElement("div",null,(t.creator||{}).fullname)}},{dataIndex:"createTime",title:_l("\u521B\u5EFA\u65F6\u95F4"),render:function(t){return Ee()(t.createTime).format("YYYY-MM-DD HH:mm")}}]),(0,ve.default)(r,F.exportHistory,[{dataIndex:"versionCode",title:_l("\u7248\u672C")},{dataIndex:"operator",title:_l("\u5BFC\u51FA\u4EBA"),render:function(t){return e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("img",{src:t.operator.avatar}),e.createElement("span",null,t.operator.fullname))}},{dataIndex:"createTime",title:_l("\u5BFC\u51FA\u65F6\u95F4"),render:function(t){return Ee()(t.createTime).format("YYYY-MM-DD HH:mm")}},{dataIndex:"exportFile",title:_l("\u5BFC\u51FA\u6587\u4EF6"),render:function(t){return t.url?e.createElement("span",{className:"ThemeColor pointer ThemeHoverColor2",onClick:function(){return window.open((0,ee.Sv)(md.global.Config.AjaxApiUrl+"Download/Plugin?projectId="+T+"&id="+t.id))}},_l("\u4E0B\u8F7D")):e.createElement("span",{className:"Gray_9e"},_l("\u4E0B\u8F7D"))}},{dataIndex:"secretKey",title:_l("\u6388\u6743\u5BC6\u94A5"),render:function(t){return t.profile?e.createElement("span",{className:"ThemeColor pointer ThemeHoverColor2",onClick:function(){return _({visible:!0,data:t.profile})}},_l("\u67E5\u770B")):e.createElement("span",{className:"Gray_9e"},_l("\u65E0"))}},{dataIndex:"operate",renderTitle:function(){return e.createElement(U.Z,{icon:"refresh1",className:"Font18 pointer Gray_9e Hover_21",onClick:function(){return w()}})}}]),r),G=(c={},(0,ve.default)(c,F.commit,{icon:"code",text:_l("\u6682\u65E0\u63D0\u4EA4\u7684\u4EE3\u7801")}),(0,ve.default)(c,F.publishHistory,{icon:"extension",text:_l("\u6682\u65E0\u53D1\u5E03\u5386\u53F2")}),(0,ve.default)(c,F.usageDetail,{icon:"extension",text:_l("\u6682\u65E0\u4F7F\u7528")}),(0,ve.default)(c,F.exportHistory,{icon:"extension",text:_l("\u6682\u65E0\u5BFC\u51FA\u5386\u53F2")}),c);return e.createElement(bt,null,b.length?e.createElement("div",{className:i+"List"},e.createElement("div",{className:"headTr"},(Q[i]||[]).filter(function(m){return i!==F.publishHistory||g==="myPlugin"||j||m.dataIndex!=="operate"}).map(function(m,t){return e.createElement("div",{key:t,className:""+m.dataIndex},m.renderTitle?m.renderTitle():m.title)})),b.map(function(m,t){return e.createElement("div",{key:t,className:"dataItem"},(Q[i]||[]).filter(function(E){return i!==F.publishHistory||g==="myPlugin"||j||E.dataIndex!=="operate"}).map(function(E,A){return e.createElement("div",{key:t+"-"+A,className:""+E.dataIndex},E.render?E.render(m,t):m[E.dataIndex])}))})):e.createElement(It,null,e.createElement("span",{className:"iconCon InlineBlock TxtCenter "},e.createElement(U.Z,{icon:G[i].icon,className:"Font64 TxtMiddle"})),e.createElement("p",{className:"Gray_9e mTop20 mBottom0"},h?_l("\u6682\u65E0\u641C\u7D22\u7ED3\u679C"):G[i].text)),l.visible&&e.createElement(cn.Z,{latestVersion:x,pluginId:a,source:s,commitId:l.commitId,debugConfiguration:o,onClose:function(){return f({visible:!1})},onRefreshDetail:p}),H.visible&&e.createElement(Ct,{data:H.data,onClose:function(){return _({visible:!1})}}))}var un=u(49365),kt=u(63025),yt=u(15405),pn=u(49863),wt=u(46417),St=u(94942),De=u.n(St),Ke=u(36803),or=u(34279),Nt=u(64749),At=u(94797),Zt=u.n(At),Tt=u(63256),Lt=u.n(Tt),Bt=u(68379),Qt=(0,V.Z)([`
  .uploadBox {
    width: 100%;
    height: 240px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    border: 1px dashed #eaeaea;
    box-sizing: border-box;
    .uploadImg {
      width: 52px;
      height: 59px;
      margin-bottom: 15px;
    }
    .error {
      color: #f44336;
    }
  }
`],[`
  .uploadBox {
    width: 100%;
    height: 240px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    border: 1px dashed #eaeaea;
    box-sizing: border-box;
    .uploadImg {
      width: 52px;
      height: 59px;
      margin-bottom: 15px;
    }
    .error {
      color: #f44336;
    }
  }
`]),Dt=(0,V.Z)([`
  display: flex;
  align-items: center;
  margin-bottom: 30px;
  .labelText {
    width: 80px;
  }
  .selectItem {
    flex: 1;
    font-size: 13px;
    .ant-select-selector {
      min-height: 36px;
      padding: 2px 11px !important;
      border: 1px solid #ccc !important;
      border-radius: 3px !important;
      box-shadow: none !important;
    }
    &.ant-select-focused {
      .ant-select-selector {
        border-color: #1e88e5 !important;
      }
    }
  }
`],[`
  display: flex;
  align-items: center;
  margin-bottom: 30px;
  .labelText {
    width: 80px;
  }
  .selectItem {
    flex: 1;
    font-size: 13px;
    .ant-select-selector {
      min-height: 36px;
      padding: 2px 11px !important;
      border: 1px solid #ccc !important;
      border-radius: 3px !important;
      box-shadow: none !important;
    }
    &.ant-select-focused {
      .ant-select-selector {
        border-color: #1e88e5 !important;
      }
    }
  }
`]),Ft=J.ZP.div(Qt),ye=J.ZP.div(Dt);function jt(n){var r=n.onClose,c=n.pluginInfo,g=n.onImport,i=n.importing,d=n.projectId,b=(0,e.useState)([]),I=(0,v.Z)(b,2),x=I[0],o=I[1],a=(0,e.useState)(void 0),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)(!1),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=c.pluginSourceId,k=c.name,s=c.versionCode,S=c.releaseTime;(0,e.useEffect)(function(){R&&ue.Z.getPluginListBySourece({projectId:d,sourceId:R}).then(function(l){l&&o(l)})},[R]);var P=e.createElement("div",{className:"flexRow alignItemsCenter justifyContentRight"},e.createElement(Qe.ZP,{type:"link",onClick:r},_l("\u53D6\u6D88")),e.createElement(Qe.ZP,{onClick:function(){D(!1),g(!1,p==="create"?void 0:p)}},e.createElement("div",{className:"flexRow alignItemsCenter"},i&&!T&&e.createElement("div",{className:"notificationIconWrap mRight8"},e.createElement("i",{className:"icon-loading_button Font20 White"})),_l("\u786E\u8BA4"))));return e.createElement(ie.Z,{visible:!0,width:580,title:_l("\u68C0\u6D4B\u5230\u5DF2\u6709\u63D2\u4EF6"),description:_l("\u68C0\u6D4B\u5230\u5F53\u524D\u7EC4\u7EC7\u4E2D\u5B58\u5728\u76F8\u540C\u7684\u63D2\u4EF6\uFF0C\u60A8\u53EF\u4EE5\u9009\u62E9\u5BFC\u5165\u5DF2\u6709\u63D2\u4EF6\u6216\u8005\u521B\u5EFA\u4E00\u4E2A\u65B0\u63D2\u4EF6"),footer:P,onCancel:r},e.createElement(ye,{className:"mTop24"},e.createElement("div",{className:"labelText"},_l("\u5C06\u63D2\u4EF6")),e.createElement("div",{className:"bold"},[k,s,"("+S+")"].join(" "))),e.createElement(ye,{className:"mBottom0"},e.createElement("div",{className:"labelText"},_l("\u5BFC\u5165\u5230")),e.createElement(Nt.default,{className:"selectItem",allowClear:!0,options:[{label:_l("\u521B\u5EFA\u65B0\u63D2\u4EF6"),value:"create"}].concat(x.map(function(l){return{label:e.createElement("span",null,[l.name,l.currentVersion.versionCode,"("+l.currentVersion.releaseTime+")"].join(" ")),value:l.id}})),notFoundContent:_l("\u6682\u65E0\u53D1\u5E03\u5386\u53F2"),value:p,onChange:function(f){return h(f)}})))}function Pt(n){var r=this,c=n.onClose,g=n.projectId,i=n.pluginId,d=n.onImportCreateSuccess,b=(0,e.useState)({}),I=(0,v.Z)(b,2),x=I[0],o=I[1],a=(0,e.useState)(!1),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)(!1),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=(0,e.useState)(""),k=(0,v.Z)(R,2),s=k[0],S=k[1],P=(0,e.useState)(!1),l=(0,v.Z)(P,2),f=l[0],Z=l[1],y=(0,e.useState)(""),H=(0,v.Z)(y,2),_=H[0],X=H[1],Q=(0,e.useState)({}),G=(0,v.Z)(Q,2),m=G[0],t=G[1],E=(0,e.useState)(!1),A=(0,v.Z)(E,2),L=A[0],N=A[1],te=(0,e.useState)(!1),z=(0,v.Z)(te,2),W=z[0],oe=z[1],q=function(){var we=(0,Ke.Z)(De().mark(function me(fe,ge){var ae;return De().wrap(function(ce){for(;;)switch(ce.prev=ce.next){case 0:return D(!0),ae=!1,ce.next=4,Bt.Z.check({projectId:g,source:1,url:fe,pluginId:i,password:f?_:void 0}).then(function(re){switch(D(!1),re.resultCode){case 0:t(re.metadata||{}),ae=!0;break;case 2:Z(!0),t(re.metadata||{});break;case 13:oe(!0),t(re.metadata||{});break;default:var Se=Fn[re.resultCode]||_l("\u6587\u4EF6\u89E3\u6790\u9519\u8BEF");ge?alert(Se,2):S(Se);break}}).catch(function(re){ge?alert(_l("\u6587\u4EF6\u89E3\u6790\u9519\u8BEF"),2):S(_l("\u6587\u4EF6\u89E3\u6790\u9519\u8BEF")),D(!1)});case 4:return ce.abrupt("return",ae);case 5:case"end":return ce.stop()}},me,r)}));return function(fe,ge){return we.apply(this,arguments)}}(),se=function(){var we=(0,Ke.Z)(De().mark(function me(fe,ge){var ae,he;return De().wrap(function(re){for(;;)switch(re.prev=re.next){case 0:if(N(!0),ae=md.global.FileStoreConfig.documentHost+x.key,re.t0=!fe,re.t0){re.next=7;break}return re.next=6,q(ae,!0);case 6:re.t0=!!re.sent;case 7:he=re.t0,he?ue.Z.import({projectId:g,url:ae,pluginId:ge}).then(function(Se){N(!1),Se===1?(alert(_l("\u5BFC\u5165\u63D2\u4EF6\u6210\u529F")),d&&d(),c()):alert(_l("\u5BFC\u5165\u63D2\u4EF6\u5931\u8D25"),2)}).catch(function(Se){return N(!1)}):N(!1);case 9:case"end":return re.stop()}},me,r)}));return function(fe,ge){return we.apply(this,arguments)}}(),Ze=function(me){return e.createElement(wt.Z,{className:"mTop24",options:{multi_selection:!1,filters:{mime_types:[{extensions:"mdye"}]}},onAdd:function(ge,ae){S(""),Z(!1)},onUploaded:function(ge,ae){h(!1),o(ae);var he=md.global.FileStoreConfig.documentHost+ae.key;q(he)},onError:function(){alert(_l("\u4E0A\u4F20\u5931\u8D25, \u8BF7\u9009\u62E9.mdye\u683C\u5F0F\u6587\u4EF6"),2),o({}),h(!1)}},me)},Ce=function(){var me=m.name,fe=m.iconUrl,ge=m.iconColor,ae=m.versionCode,he=m.author,ce=m.releaseTime,re=m.description,Se=m.type;return e.createElement(e.Fragment,null,e.createElement("div",{className:"flexRow mTop24"},e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u540D\u79F0")),fe?e.createElement(je.Z,{url:fe,fill:ge,size:16}):e.createElement(U.Z,{icon:"extension",className:"Font16 Gray_bd"}),e.createElement("span",{title:me,className:"mLeft8 bold overflow_ellipsis"},me)),e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u63D2\u4EF6\u7C7B\u578B")),e.createElement("div",{className:"bold"},Se===1?_l("\u89C6\u56FE"):""))),e.createElement("div",{className:"flexRow"},e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u7248\u672C")),e.createElement("div",{className:"bold"},ae)),e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u4F5C\u8005")),e.createElement("div",{className:"bold"},he))),e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u53D1\u5E03\u65F6\u95F4")),e.createElement("div",{className:"bold"},Ee()(ce).format("YYYY-MM-DD HH:mm:ss"))),e.createElement(ye,{className:"flex"},e.createElement("div",{className:"labelText"},_l("\u53D1\u5E03\u8BF4\u660E")),e.createElement("div",{className:"bold"},re)),f&&e.createElement(ye,null,e.createElement("div",{className:"labelText"},_l("\u5BC6\u7801")),e.createElement(Ne.Z,{className:"flex",placeholder:_l("\u8BF7\u8F93\u5165\u5BFC\u51FA\u65F6\u8BBE\u7F6E\u7684\u5BC6\u7801"),value:_,onChange:function(Le){return X(Le)}})))};return e.createElement(ie.Z,{visible:!0,width:580,title:_l("\u5BFC\u5165\u63D2\u4EF6"),showFooter:!O().isEmpty(m),okDisabled:f&&!_,okText:e.createElement("div",{className:"flexRow alignItemsCenter"},L&&e.createElement("div",{className:"notificationIconWrap mRight8"},e.createElement("i",{className:"icon-loading_button Font20 White"})),e.createElement("span",null,i?_l("\u5BFC\u5165"):_l("\u5BFC\u5165\u521B\u5EFA"))),onOk:function(){return!L&&se(f,i)},onCancel:c},O().isEmpty(m)?e.createElement(Ft,null,e.createElement("div",{className:"Gray_75 mBottom24"},_l("\u5C06\u63D2\u4EF6\u6587\u4EF6\u5BFC\u5165\u7EC4\u7EC7\u521B\u5EFA\u4E00\u4E2A\u65B0\u7684\u63D2\u4EF6\uFF0C\u542F\u7528\u540E\u5373\u53EF\u5728\u5168\u7EC4\u7EC7\u8303\u56F4\u5185\u4F7F\u7528\u3002"),e.createElement(on.Z,{text:_l("\u5E2E\u52A9"),type:3,href:"https://help.mingdao.com/"})),e.createElement("div",{className:"uploadBox"},e.createElement("img",{className:"uploadImg",src:x.name?Lt():Zt()}),x.name?e.createElement(e.Fragment,null,e.createElement("div",{className:"Font17"},x.name),e.createElement("div",{className:"Gray_75 mTop6"},_l("\u5927\u5C0F\uFF1A")+(0,ee.sS)(x.size)),s&&e.createElement("div",{className:"mTop15 error Font14"},e.createElement("span",{className:"icon-closeelement-bg-circle Font15 mRight6"}),e.createElement("span",null,_l(s)))):e.createElement("div",{className:"Gray_9e"},_l("\u8BF7\u9009\u62E9.mdye\u683C\u5F0F\u7684\u5E94\u7528\u6587\u4EF6")),(T||p)&&e.createElement("div",{className:"flexRow mTop16"},e.createElement("div",{className:"notificationIconWrap"},e.createElement("i",{className:"icon-loading_button Font20 ThemeColor3"})),e.createElement("span",{className:"Gray_75 mLeft10"},T?_l("\u6B63\u5728\u89E3\u6790\u6587\u4EF6..."):_l("\u6587\u4EF6\u4E0A\u4F20\u4E2D..."))),!(T||p)&&(O().isEmpty(x)?Ze(e.createElement(Qe.ZP,{type:"primary",radius:!0},_l("\u4E0A\u4F20\u6587\u4EF6"))):Ze(e.createElement("div",{className:"ThemeColor Hand"},_l("\u91CD\u65B0\u4E0A\u4F20")))))):Ce(),W&&e.createElement(jt,{onClose:function(){return oe(!1)},pluginInfo:m,onImport:se,importing:L,projectId:g}))}const fn=function(n){return(0,Xe.Z)(Pt,(0,Y.default)({},n))};var Ht=(0,V.Z)([`
  display: flex;
  flex-direction: column;
  width: 800px;
  height: 100%;
  position: fixed;
  z-index: 100;
  right: 0;
  top: 0;
  bottom: 0;
  background: #fff;
  box-shadow: 0px 3px 24px rgba(0, 0, 0, 0.16);

  .tabList {
    width: 100%;
    background: #fff;
    position: sticky;
    top: -1px;

    ul {
      padding: 24px 24px 0 24px;
      border-bottom: 1px solid #ebebeb;
      li {
        display: inline-block;
        font-size: 15px;
        font-weight: 600;
        margin: 0;
        padding: 10px 20px;
        box-sizing: border-box;
        border-bottom: 2px solid rgba(0, 0, 0, 0);
        cursor: pointer;
        &.isCur {
          color: #2196f3;
          border-bottom: 2px solid #2196f3;
        }
      }
    }
    .searchWrapper {
      display: flex;
      justify-content: flex-end;
      padding: 12px 24px;
      .workflowSearchWrap {
        width: 220px;
        input {
          width: 100%;
          border-radius: 3px;
        }
      }
    }
  }

  .closeIcon {
    position: absolute;
    z-index: 10;
    right: 24px;
    top: 22px;
    font-size: 24px;
    cursor: pointer;
    &:hover {
      color: #2196f3;
    }
  }

  .configHeader {
    background: #ffffff;
    padding: 32px 24px 0px 24px;
    width: 100%;
    transition: height 0.2s;
    position: relative;

    .iconWrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 48px;
      height: 48px;
      min-width: 48px;
      margin-right: 20px;
      background: #fff;
      color: #bdbdbd;
      border-radius: 8px;
      cursor: pointer;
    }
    .nameInput {
      width: 100%;
      font-size: 20px;
      font-weight: bold;
      border: none;
      padding: 0;
    }

    .validVersionCard {
      display: flex;
      align-items: center;
      width: 100%;
      background: #ffffff;
      border: 1px solid #ddd;
      border-radius: 6px;
      padding: 22px 20px;
      margin-top: 24px;

      .versionPublishBtn {
        display: flex;
        align-items: center;
        height: 36px;
        line-height: 36px;
        padding: 0 16px;
        border-radius: 36px;
        background: #e3f2fd;
        color: #2196f3;
        cursor: pointer;
        i {
          margin-right: 6px;
          font-size: 16px;
        }
        &:hover {
          opacity: 0.8;
        }
      }
    }
  }

  .configContent {
    padding: 12px 24px;
    .tagInputareaIuput {
      min-height: 220px;
      .CodeMirror-sizer {
        min-height: 220px !important;
      }
    }
  }

  .configFooter {
    background: #fff;
    padding: 16px 20px;

    .footerBtn {
      display: inline-block;
      height: 36px;
      line-height: 36px;
      border-radius: 3px;
      padding: 0 30px;
      cursor: pointer;

      &.close,
      &.recoverDefault {
        color: #757575;
        border: 1px solid #ebebeb;
        &:hover {
          color: #2196f3;
          border: 1px solid #2196f3;
        }
      }
      &.save {
        color: #fff;
        background: #2196f3;
        border: 1px solid #2196f3;
        &:hover {
          background: #1764c0;
          border: 1px solid #1764c0;
        }
      }
    }
  }
`],[`
  display: flex;
  flex-direction: column;
  width: 800px;
  height: 100%;
  position: fixed;
  z-index: 100;
  right: 0;
  top: 0;
  bottom: 0;
  background: #fff;
  box-shadow: 0px 3px 24px rgba(0, 0, 0, 0.16);

  .tabList {
    width: 100%;
    background: #fff;
    position: sticky;
    top: -1px;

    ul {
      padding: 24px 24px 0 24px;
      border-bottom: 1px solid #ebebeb;
      li {
        display: inline-block;
        font-size: 15px;
        font-weight: 600;
        margin: 0;
        padding: 10px 20px;
        box-sizing: border-box;
        border-bottom: 2px solid rgba(0, 0, 0, 0);
        cursor: pointer;
        &.isCur {
          color: #2196f3;
          border-bottom: 2px solid #2196f3;
        }
      }
    }
    .searchWrapper {
      display: flex;
      justify-content: flex-end;
      padding: 12px 24px;
      .workflowSearchWrap {
        width: 220px;
        input {
          width: 100%;
          border-radius: 3px;
        }
      }
    }
  }

  .closeIcon {
    position: absolute;
    z-index: 10;
    right: 24px;
    top: 22px;
    font-size: 24px;
    cursor: pointer;
    &:hover {
      color: #2196f3;
    }
  }

  .configHeader {
    background: #ffffff;
    padding: 32px 24px 0px 24px;
    width: 100%;
    transition: height 0.2s;
    position: relative;

    .iconWrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 48px;
      height: 48px;
      min-width: 48px;
      margin-right: 20px;
      background: #fff;
      color: #bdbdbd;
      border-radius: 8px;
      cursor: pointer;
    }
    .nameInput {
      width: 100%;
      font-size: 20px;
      font-weight: bold;
      border: none;
      padding: 0;
    }

    .validVersionCard {
      display: flex;
      align-items: center;
      width: 100%;
      background: #ffffff;
      border: 1px solid #ddd;
      border-radius: 6px;
      padding: 22px 20px;
      margin-top: 24px;

      .versionPublishBtn {
        display: flex;
        align-items: center;
        height: 36px;
        line-height: 36px;
        padding: 0 16px;
        border-radius: 36px;
        background: #e3f2fd;
        color: #2196f3;
        cursor: pointer;
        i {
          margin-right: 6px;
          font-size: 16px;
        }
        &:hover {
          opacity: 0.8;
        }
      }
    }
  }

  .configContent {
    padding: 12px 24px;
    .tagInputareaIuput {
      min-height: 220px;
      .CodeMirror-sizer {
        min-height: 220px !important;
      }
    }
  }

  .configFooter {
    background: #fff;
    padding: 16px 20px;

    .footerBtn {
      display: inline-block;
      height: 36px;
      line-height: 36px;
      border-radius: 3px;
      padding: 0 30px;
      cursor: pointer;

      &.close,
      &.recoverDefault {
        color: #757575;
        border: 1px solid #ebebeb;
        &:hover {
          color: #2196f3;
          border: 1px solid #2196f3;
        }
      }
      &.save {
        color: #fff;
        background: #2196f3;
        border: 1px solid #2196f3;
        &:hover {
          background: #1764c0;
          border: 1px solid #1764c0;
        }
      }
    }
  }
`]),Rt=J.ZP.div(Ht);function Ut(n){var r=n.belongType,c=n.configType,g=n.pluginId,i=n.projectId,d=n.onClose,b=n.onUpdateSuccess,I=n.isAdmin,x=(0,pe.Z)({name:"",icon:"",iconUrl:"",iconColor:"",debugEnvironments:[],currentVersion:{},configuration:"",recentOperation:{}}),o=(0,v.Z)(x,2),a=o[0],w=o[1],p=(0,e.useState)([{isEdit:!0}]),h=(0,v.Z)(p,2),j=h[0],C=h[1],T=(0,pe.Z)({debugConfiguration:{},configuration:{}}),D=(0,v.Z)(T,2),R=D[0],k=D[1],s=(0,e.useState)(!1),S=(0,v.Z)(s,2),P=S[0],l=S[1],f=(0,pe.Z)({loading:!1,pageIndex:1,keywords:"",noMore:!1}),Z=(0,v.Z)(f,2),y=Z[0],H=Z[1],_=(0,pe.Z)({usageList:[],publishHistoryList:[],commitList:[],exportHistoryList:[]}),X=(0,v.Z)(_,2),Q=X[0],G=X[1],m=(0,e.useState)(),t=(0,v.Z)(m,2),E=t[0],A=t[1],L=(0,e.useState)(!1),N=(0,v.Z)(L,2),te=N[0],z=N[1],W=(0,e.useState)(c===F.create?F.debugEnv:c),oe=(0,v.Z)(W,2),q=oe[0],se=oe[1],Ze=(0,e.useState)(!1),Ce=(0,v.Z)(Ze,2),we=Ce[0],me=Ce[1],fe=(0,e.useRef)(),ge=(0,e.useRef)(),ae=r==="myPlugin"?0:1;(0,e.useEffect)(function(){g&&he()},[]),(0,e.useEffect)(function(){ce(1)},[q]);var he=function(){l(!0),ue.Z.getDetail({id:g,source:ae}).then(function(B){B&&(l(!1),w(B.debugEnvironments.length?B:(0,Y.default)({},B,{debugEnvironments:[{isEdit:!0}]})),C(B.debugEnvironments.length?B.debugEnvironments:[{isEdit:!0}]),k({debugConfiguration:ae===0?B.configuration:B.debugConfiguration,configuration:B.configuration}))})},ce=function(B,K){switch(O().includes([F.debugEnv,F.paramSetting],q)||H({loading:!0,pageIndex:B,keywords:K}),q){case F.commit:ue.Z.getCommitHistory({id:g,source:ae,pageSize:50,pageIndex:B}).then(function(M){M&&(H({loading:!1,noMore:M.history.length<50}),G({commitList:B>1?Q.commitList.concat(M.history):M.history}))}).catch(function(M){return H({loading:!1})});break;case F.publishHistory:ue.Z.getReleaseHistory({id:g,pageSize:50,pageIndex:B,source:ae}).then(function(M){M&&(H({loading:!1,noMore:M.history.length<50}),G({publishHistoryList:B>1?Q.publishHistoryList.concat(M.history):M.history}))}).catch(function(M){return H({loading:!1})});break;case F.usageDetail:ue.Z.getUseDetail({id:g,pageSize:50,type:1,pageIndex:B,keywords:K||""}).then(function(M){M&&(H({loading:!1,noMore:M.details.length<50}),G({usageList:B>1?Q.usageList.concat(M.details):M.details}))}).catch(function(M){return H({loading:!1})});break;case F.debugEnv:w({debugEnvironments:j});break;case F.exportHistory:ue.Z.getExportHistory({id:g,pageSize:50,pageIndex:B,source:ae}).then(function(M){M&&(H({loading:!1,noMore:M.length<50}),G({exportHistoryList:B>1?Q.exportHistoryList.concat(M):M}))}).catch(function(M){return H({loading:!1})});break;default:break}},re=function(){un.Z.getAppForManager({projectId:i,type:0}).then(function(B){if(B){var K=B.map(function(M){return{text:M.appName,value:M.appId}});A(K)}})},Se=function(){!y.loading&&!y.noMore&&(H({pageIndex:y.pageIndex+1}),ce(y.pageIndex+1,y.keywords))},Sn=function(){if(!a.debugEnvironments[0].appId){alert(_l("\u8BF7\u9009\u62E9\u5E94\u7528"),3);return}if(!a.debugEnvironments[0].worksheetId){alert(_l("\u8BF7\u9009\u62E9\u5DE5\u4F5C\u8868"),3);return}ue.Z.create((0,Y.default)({projectId:i,pluginType:1},O().pick(a,["icon","iconColor"]),{name:a.name||_l("\u672A\u547D\u540D\u63D2\u4EF6"),debugEnvironments:a.debugEnvironments.map(function(B){return(0,Y.default)({},O().pick(B,["appId","worksheetId"]))})})).then(function(B){if(B){alert("\u63D2\u4EF6\u521B\u5EFA\u6210\u529F"),d();var K=B.debugEnvironments[0]||{},M=K.worksheetId,be=K.viewId;(0,He.O4)(M,be)}})},Le=function(){var B=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},K=arguments.length>1&&arguments[1]!==void 0?arguments[1]:function(be){},M=arguments[2];ue.Z.edit((0,Y.default)({projectId:i,id:g,source:ae},B)).then(function(be){if(be){b(g,B);var Fe=be.debugEnvironments||[];K&&K(Fe[Fe.length-1]||{}),C(Fe)}else alert(M||_l("\u66F4\u65B0\u5931\u8D25"),2)})},qa=function(){var B=e.createElement("div",{className:"iconWrapper",style:{backgroundColor:a.iconColor?(0,nt.YT)(a.iconColor,"0.08"):"#fff"}},a.iconUrl?e.createElement(je.Z,{url:a.iconUrl,fill:a.iconColor,size:32}):e.createElement(U.Z,{icon:"extension",className:"Font32"}));return I||md.global.Account.accountId===O().get(a,"creator.accountId")||r==="myPlugin"?e.createElement(Pe.Z,{action:["click"],popup:e.createElement(sn.Z,{hideInput:!0,iconColor:a.iconColor,icon:a.icon,projectId:i,onModify:function(M){var be=M.iconColor,Fe=M.icon,nr=M.iconUrl,We={};be?We={iconColor:be}:We={icon:Fe,iconUrl:nr},c!==F.create?Le(be?{iconColor:be}:{icon:Fe},function(){w((0,Y.default)({},a,We))}):w((0,Y.default)({},a,We))}}),zIndex:1e3,popupAlign:{points:["tl","bl"],overflow:{adjustX:!0,adjustY:!0}}},B):B},$a=function(){var B=r==="myPlugin"?rn[r].filter(function(K){return c!==F.create||K.value==="debugEnv"}):rn[r].filter(function(K){return I||md.global.Account.accountId===O().get(a,"creator.accountId")||K.value==="publishHistory"});return e.createElement("div",{className:"tabList"},e.createElement("ul",null,B.map(function(K,M){return e.createElement("li",{key:M,className:ne()({isCur:q===K.value}),onClick:function(){return se(K.value)}},K.text,!!a.usageTotalCount&&K.value===F.usageDetail&&e.createElement("span",{className:"mLeft4"},a.usageTotalCount))})),q===F.usageDetail&&e.createElement("div",{className:"searchWrapper"},e.createElement(kt.Z,{placeholder:_l("\u5E94\u7528\u540D\u79F0"),handleChange:O().debounce(function(K){ce(1,K)},500)})))},er=function(){switch(q){case F.debugEnv:return e.createElement(ot,(0,Y.default)({},n,{appList:E,onGetAppList:re,debugEnvList:a.debugEnvironments,onChangeDebugEnvList:function(K){return w((0,Y.default)({},a,{debugEnvironments:K}))},onUpdate:Le}));case F.paramSetting:return e.createElement("div",{className:"mTop12"},e.createElement("p",{className:"Gray_75 mBottom8"},_l("\u914D\u7F6E\u63D2\u4EF6\u8FD0\u884C\u65F6\u6240\u9700\u8981\u7684\u73AF\u5883\u53C2\u6570\uFF0C\u91C7\u7528JSON\u683C\u5F0F")),e.createElement($n.Z,{getRef:function(K){return ge.current=K},defaultValue:O().isEmpty(R.configuration)?"":Ye()(R.configuration),codeMirrorMode:"javascript",onChange:function(K,M){return w((0,Y.default)({},a,{configuration:M}))}}));case F.commit:return e.createElement(ze,(0,Y.default)({},n,{configType:q,list:Q.commitList,latestVersion:a.latestVersion,debugConfiguration:R.debugConfiguration,onRefreshList:function(){return ce(1)},onRefreshDetail:function(){return he()},onDelete:function(K){return G({commitList:Q.commitList.filter(function(M){return K!==M.id})})}}));case F.publishHistory:return e.createElement(ze,(0,Y.default)({},n,{configType:q,list:Q.publishHistoryList,currentVersion:a.currentVersion,onRefreshList:function(){return ce(1)},onRefreshDetail:function(){return he()},hasOperateAuth:I||md.global.Account.accountId===O().get(a,"creator.accountId"),onDelete:function(K){return G({publishHistoryList:Q.publishHistoryList.filter(function(M){return K!==M.id})})},onExportSuccess:function(){return se(F.exportHistory)},publishType:a.source}));case F.usageDetail:return e.createElement(ze,(0,Y.default)({},n,{configType:q,list:Q.usageList,onRefreshList:function(){return ce(1)},keywords:y.keywords}));case F.exportHistory:return e.createElement(ze,(0,Y.default)({},n,{configType:q,list:Q.exportHistoryList,onRefreshList:function(){return ce(1)},onDelete:function(K){return G({exportHistoryList:Q.exportHistoryList.filter(function(M){return K!==M.id})})}}));default:return null}};return e.createElement(Rt,null,e.createElement(U.Z,{icon:"close",className:"closeIcon",onClick:d}),P?e.createElement(xe.Z,{className:"mTop10"}):e.createElement(Be.Z,{className:"flex",onScrollEnd:Se},e.createElement("div",{className:ne()("configHeader")},e.createElement("div",{className:"flexRow alignItemsCenter"},qa(),e.createElement("div",{className:"flex"},te?e.createElement(e.Fragment,null,e.createElement(Ne.Z,{manualRef:fe,className:"nameInput",value:a.name,placeholder:_l("\u6DFB\u52A0\u63D2\u4EF6\u540D\u79F0"),maxLength:20,onChange:function(B){return w((0,Y.default)({},a,{name:B}))},onBlur:function(B){var K={name:B.target.value.trim()?B.target.value.trim():_l("\u672A\u547D\u540D\u63D2\u4EF6")};c!==F.create?Le(K,function(){w((0,Y.default)({},a,K)),z(!1)}):(w((0,Y.default)({},a,K)),z(!1))}})):e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("span",{className:"Font20 bold Block LineHeight36"},a.name||_l("\u672A\u547D\u540D\u63D2\u4EF6")),(I||md.global.Account.accountId===O().get(a,"creator.accountId")||r==="myPlugin")&&e.createElement(U.Z,{icon:"edit",className:"Font16 mLeft5 Gray_9d Hand Hover_21",onClick:function(){z(!0),setTimeout(function(){fe.current&&fe.current.focus()},300)}})))),c!==F.create&&e.createElement("div",{className:"validVersionCard"},a.currentVersion.versionCode?e.createElement("div",{className:"flex flexRow alignItemsCenter"},e.createElement("span",{className:"Font24 bold"},a.currentVersion.versionCode),e.createElement("span",{className:"Gray_75 mLeft12 flexColumn minWidth0"},e.createElement("div",null,ae===0?a.creator.fullname+" \u53D1\u5E03\u4E8E "+Ee()(a.currentVersion.releaseTime).format("YYYY\u5E74MM\u6708DD\u65E5 HH:mm"):(0,pn.Yl)(a.recentOperation)),e.createElement("div",{className:"ellipsis"},a.currentVersion.versionDescription))):e.createElement("div",{className:"flex Font24 bold Gray_9e"},_l("\u672A\u53D1\u5E03\u7248\u672C")),(I||md.global.Account.accountId===O().get(a,"creator.accountId")||r==="myPlugin")&&e.createElement("div",{className:"versionPublishBtn",onClick:function(){return a.source===2?fn({projectId:i,pluginId:g,onImportCreateSuccess:function(){he(),ce(1)}}):me(!0)}},e.createElement(U.Z,{icon:"publish"}),e.createElement("span",null,a.source===2?_l("\u5BFC\u5165\u5347\u7EA7"):_l("\u53D1\u5E03\u65B0\u7248\u672C"))),we&&e.createElement(cn.Z,{latestVersion:a.latestVersion,pluginId:g,source:ae,debugConfiguration:R.debugConfiguration,onClose:function(){return me(!1)},onRefreshDetail:function(){return he()}}))),$a(),e.createElement("div",{className:"configContent"},y.loading&&y.pageIndex===1?e.createElement(xe.Z,{className:"mTop10"}):er())),(q===F.paramSetting||q===F.debugEnv&&c===F.create)&&e.createElement("div",{className:"configFooter"},e.createElement("div",{className:"flexRow"},e.createElement("div",{className:"footerBtn save",onClick:c===F.create?Sn:function(){if(a.configuration.replace(/\s/g,"")&&a.configuration.replace(/\s/g,"")!=="{}"&&O().isEmpty(safeParse(a.configuration))){alert(_l("\u914D\u7F6E\u683C\u5F0F\u4E0D\u6B63\u786E,\u8BF7\u8F93\u5165JSON\u683C\u5F0F"),3);return}var de={configuration:safeParse(a.configuration)};Le(de,function(){k({configuration:safeParse(a.configuration)}),alert(_l("\u66F4\u65B0\u914D\u7F6E\u6210\u529F"))},_l("\u66F4\u65B0\u914D\u7F6E\u5931\u8D25"))}},c===F.create?_l("\u521B\u5EFA\u63D2\u4EF6"):_l("\u66F4\u65B0\u914D\u7F6E")),q===F.paramSetting&&e.createElement("div",{className:"footerBtn recoverDefault mLeft10",onClick:function(){ge.current.setValue(O().isEmpty(R.configuration)?"":Ye()(R.configuration)),Le({configuration:R.configuration},function(){return alert(_l("\u6062\u590D\u9ED8\u8BA4\u6210\u529F"))},_l("\u6062\u590D\u9ED8\u8BA4\u5931\u8D25"))}},_l("\u6062\u590D\u9ED8\u8BA4")))))}const Ot=(0,yt.Z)(Ut);var Mt=(0,V.Z)([`
  background: #fff;
  min-height: 100%;
  .headerWrapper {
    height: 260px;
    background: linear-gradient(180deg, #ffffff 0%, #f7f7f7 100%);
    box-sizing: border-box;

    .headerContent {
      padding: 80px 0 0 50px;
      background: url(`,`) no-repeat right;
      background-size: auto 100%;
      width: 100%;
      height: 100%;
    }
  }
  .navTab {
    margin-top: -48px;
    ul {
      text-align: center;
      li {
        display: inline-block;
        margin: 0 30px;
        box-sizing: border-box;
        border-bottom: 4px solid rgba(0, 0, 0, 0);
        a {
          height: 44px;
          color: #333;
          padding: 10px;
          font-weight: 600;
          display: inline-block;
          font-size: 16px;
        }
        &.isCur {
          border-bottom: 4px solid #2196f3;
          a {
            color: #2196f3;
          }
        }
      }
    }
  }
  .contentWrapper {
    display: flex;
    flex-direction: column;
    padding: 32px;
    .contentHeader {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      .searchInput {
        width: 220px;
        min-width: 220px;
        height: 36px;
        margin-right: 24px;
      }
      .filterDropdown {
        width: 120px;
        .Dropdown--input {
          padding: 4px 8px 4px 12px;
        }
      }
      .headerBtn {
        padding: 8px 24px;
        background: #2196f3;
        border-radius: 18px;
        color: #fff;
        display: inline-block;
        cursor: pointer;

        &:hover {
          background: #1764c0;
        }
      }
    }
  }
`],[`
  background: #fff;
  min-height: 100%;
  .headerWrapper {
    height: 260px;
    background: linear-gradient(180deg, #ffffff 0%, #f7f7f7 100%);
    box-sizing: border-box;

    .headerContent {
      padding: 80px 0 0 50px;
      background: url(`,`) no-repeat right;
      background-size: auto 100%;
      width: 100%;
      height: 100%;
    }
  }
  .navTab {
    margin-top: -48px;
    ul {
      text-align: center;
      li {
        display: inline-block;
        margin: 0 30px;
        box-sizing: border-box;
        border-bottom: 4px solid rgba(0, 0, 0, 0);
        a {
          height: 44px;
          color: #333;
          padding: 10px;
          font-weight: 600;
          display: inline-block;
          font-size: 16px;
        }
        &.isCur {
          border-bottom: 4px solid #2196f3;
          a {
            color: #2196f3;
          }
        }
      }
    }
  }
  .contentWrapper {
    display: flex;
    flex-direction: column;
    padding: 32px;
    .contentHeader {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      .searchInput {
        width: 220px;
        min-width: 220px;
        height: 36px;
        margin-right: 24px;
      }
      .filterDropdown {
        width: 120px;
        .Dropdown--input {
          padding: 4px 8px 4px 12px;
        }
      }
      .headerBtn {
        padding: 8px 24px;
        background: #2196f3;
        border-radius: 18px;
        color: #fff;
        display: inline-block;
        cursor: pointer;

        &:hover {
          background: #1764c0;
        }
      }
    }
  }
`]),Gt=(0,V.Z)([`
  .headTr {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 14px 8px;
    border-bottom: 1px solid #e0e0e0;
  }

  .dataItem {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 8px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
    &.isActive {
      background: rgba(247, 247, 247, 1);
    }
    &:hover {
      background: rgba(247, 247, 247, 1);
      .name {
        color: #2196f3;
      }
      .operateIcon {
        background: rgba(247, 247, 247, 1);
      }
    }

    .ant-switch-checked {
      background-color: rgba(40, 202, 131, 1);
    }
  }

  .name {
    padding-right: 8px;
    width: 0;
    flex: 9;
  }
  .developers,
  .operateTime {
    flex: 5;
  }
  .state,
  .currentVersion,
  .createTime {
    flex: 3;
  }
  .operate {
    flex: 1;
    text-align: right;
    .operateIcon {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      color: #9e9e9e;
      background: #fff;

      &:hover {
        color: #2196f3;
        background: #fff !important;
      }
    }
  }
`],[`
  .headTr {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 14px 8px;
    border-bottom: 1px solid #e0e0e0;
  }

  .dataItem {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 8px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
    &.isActive {
      background: rgba(247, 247, 247, 1);
    }
    &:hover {
      background: rgba(247, 247, 247, 1);
      .name {
        color: #2196f3;
      }
      .operateIcon {
        background: rgba(247, 247, 247, 1);
      }
    }

    .ant-switch-checked {
      background-color: rgba(40, 202, 131, 1);
    }
  }

  .name {
    padding-right: 8px;
    width: 0;
    flex: 9;
  }
  .developers,
  .operateTime {
    flex: 5;
  }
  .state,
  .currentVersion,
  .createTime {
    flex: 3;
  }
  .operate {
    flex: 1;
    text-align: right;
    .operateIcon {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      color: #9e9e9e;
      background: #fff;

      &:hover {
        color: #2196f3;
        background: #fff !important;
      }
    }
  }
`]),zt=(0,V.Z)([`
  text-align: center !important;
  .iconCon {
    width: 130px;
    height: 130px;
    line-height: 130px;
    background: #f5f5f5;
    border-radius: 50%;
    margin: 64px auto 0;
    color: #9e9e9e;
  }
`],[`
  text-align: center !important;
  .iconCon {
    width: 130px;
    height: 130px;
    line-height: 130px;
    background: #f5f5f5;
    border-radius: 50%;
    margin: 64px auto 0;
    color: #9e9e9e;
  }
`]),Wt=J.ZP.div(Mt,zn()),mn=J.ZP.div(Gt),Yt=J.ZP.div(zt);function gn(n){var r=n.currentProjectId,c=n.isAdmin,g=(0,pe.Z)({pageIndex:1,loading:!0,noMore:!1,state:2,keyWords:""}),i=(0,v.Z)(g,2),d=i[0],b=i[1],I=(0,e.useState)([]),x=(0,v.Z)(I,2),o=x[0],a=x[1],w=(0,e.useState)(localStorage.getItem("viewPluginTab")||"myPlugin"),p=(0,v.Z)(w,2),h=p[0],j=p[1],C=(0,e.useState)({visible:!1}),T=(0,v.Z)(C,2),D=T[0],R=T[1],k=function(){d.loading&&ue.Z.getList({projectId:r,pluginType:1,pageSize:50,pageIndex:d.pageIndex,keyWords:d.keyWords,state:d.state!==2?d.state:void 0,type:h==="myPlugin"?0:1}).then(function(f){f&&(a(d.pageIndex>1?o.concat(f.plugins):f.plugins),b({loading:!1,noMore:f.plugins.length<50}))}).catch(function(f){b({loading:!1}),a([])})},s=function(){!d.noMore&&!d.loading&&b({loading:!0,pageIndex:d.pageIndex+1})},S=(0,e.useCallback)(O().debounce(function(l){b({loading:!0,pageIndex:1,keyWords:l})},500),[]);(0,e.useEffect)(k,[h,d.loading,d.pageIndex,d.keyWords,d.state]);var P=function(){var f=[{dataIndex:"name",title:_l("\u540D\u79F0"),render:function(y){return e.createElement("div",{className:"flexRow alignItemsCenter"},y.iconUrl?e.createElement(je.Z,{url:y.iconUrl,fill:y.iconColor,size:16,className:"pTop3"}):e.createElement(U.Z,{icon:"extension",className:"Font16 Gray_bd"}),e.createElement("span",{title:y.name,className:"mLeft8 bold overflow_ellipsis"},y.name))}},{dataIndex:"state",renderTitle:function(){return e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("span",null,_l("\u72B6\u6001")),e.createElement(Ie.default,{title:_l("\u542F\u7528\u65F6\u5168\u7EC4\u7EC7\u53EF\u7528\uFF0C\u5173\u95ED\u540E\u4E0D\u5F71\u54CD\u5DF2\u521B\u5EFA\u89C6\u56FE")},e.createElement(U.Z,{icon:"info_outline",className:"Gray_bd mLeft4 pointer"})))},render:function(y){return e.createElement(ln.Z,{checkedChildren:_l("\u5F00\u542F"),unCheckedChildren:_l("\u5173\u95ED"),disabled:!c,checked:!!y.state,onChange:function(_,X){X.stopPropagation();var Q=o.map(function(G){return G.id===y.id?(0,Y.default)({},G,{state:_?1:0}):G});a(Q),ue.Z.edit({projectId:r,id:y.id,source:h==="myPlugin"?0:1,state:_?1:0}).then(function(G){if(G){var m=o.map(function(t){return t.id===y.id?(0,Y.default)({},t,{state:_?1:0}):t});a(m)}})}})}},{dataIndex:"developers",title:_l("\u5F00\u53D1\u8005"),render:function(y){return e.createElement("div",null,(y.developers||[]).join(","))}},{dataIndex:"currentVersion",title:_l("\u5F53\u524D\u7248\u672C"),render:function(y){return e.createElement("span",{className:y.currentVersion.versionCode?"bold":"Gray_9e bold"},y.currentVersion.versionCode?y.currentVersion.versionCode:_l("\u672A\u53D1\u5E03"))}},{dataIndex:h==="myPlugin"?"createTime":"operateTime",title:h==="myPlugin"?_l("\u521B\u5EFA\u65F6\u95F4"):_l("\u6700\u8FD1\u64CD\u4F5C"),render:function(y){return h==="myPlugin"?e.createElement("div",null,y.createTime?createTimeSpan(y.createTime):""):e.createElement("div",null,(0,pn.Yl)(y.recentOperation))}},{dataIndex:"operate",renderTitle:function(){return e.createElement("div",{className:"operateIcon",onClick:function(){return b({loading:!0,pageIndex:1})}},e.createElement(U.Z,{icon:"refresh1",className:"Font18 pointer"}))},render:function(y){return c||h==="myPlugin"?e.createElement(qn,{projectId:r,pluginId:y.id,source:h==="myPlugin"?0:1,onDeleteSuccess:function(){var _=o.filter(function(X){return X.id!==y.id});a(_)}}):null}}];return f.filter(function(Z){return h==="project"||!O().includes(["state","developers"],Z.dataIndex)})};return e.createElement(Be.Z,{onScrollEnd:s},e.createElement(Wt,null,e.createElement("div",{className:"headerWrapper"},e.createElement("div",{className:"headerContent"},e.createElement("h3",{className:"Bold Font24"},_l("\u63D2\u4EF6\u4E2D\u5FC3")),e.createElement("p",{className:"Font15 flexRow alignItemsCenter"},_l("\u5236\u4F5C\u548C\u7BA1\u7406\u63D2\u4EF6\uFF0C\u81EA\u7531\u6269\u5C55\u7CFB\u7EDF\u529F\u80FD"),e.createElement(on.Z,{type:3,href:"https://help.mingdao.com/extensions/developer/view",text:_l("\u63D2\u4EF6\u5F00\u53D1\u6587\u6863"),className:"mLeft4 Font15"})))),e.createElement("div",{className:"navTab"},e.createElement("ul",null,Dn.map(function(l,f){return e.createElement("li",{key:f,className:ne()({isCur:l.value===h}),onClick:function(){h!==l.value&&(safeLocalStorageSetItem("viewPluginTab",l.value),j(l.value),b({loading:!0}))}},e.createElement("a",null,l.text))}))),e.createElement("div",{className:"contentWrapper"},e.createElement("div",{className:"contentHeader"},e.createElement("div",{className:"flexRow "},e.createElement(Me.Z,{className:"searchInput",placeholder:h==="myPlugin"?_l("\u641C\u7D22\u63D2\u4EF6"):_l("\u641C\u7D22\u63D2\u4EF6 / \u5F00\u53D1\u8005"),value:d.keyWords,onChange:S}),h==="project"&&e.createElement(Te.Z,{className:"filterDropdown",border:!0,isAppendToBody:!0,placeholder:_l("\u542F\u7528\u72B6\u6001"),value:d.state,data:Qn,onChange:function(f){return b({state:f,loading:!0})}})),!(h==="project"&&!c)&&e.createElement("div",{className:"headerBtn",onClick:function(){return h==="myPlugin"?R({visible:!0,configType:F.create}):fn({projectId:r,onImportCreateSuccess:function(){return b({loading:!0,pageIndex:1})}})}},e.createElement("span",{className:"bold"},h==="myPlugin"?_l("\u5236\u4F5C\u63D2\u4EF6"):_l("+ \u5BFC\u5165")))),e.createElement(mn,null,e.createElement("div",{className:"headTr"},P().map(function(l,f){return e.createElement("div",{key:f,className:""+l.dataIndex},l.renderTitle?l.renderTitle():l.title)}))),d.pageIndex===1&&d.loading?e.createElement(xe.Z,{className:"mTop10"}):e.createElement(mn,null,o&&o.length>0?o.map(function(l,f){return e.createElement("div",{key:f,className:ne()("dataItem",{isActive:D.pluginId===l.id}),onClick:function(){R({visible:!0,configType:h==="myPlugin"?F.debugEnv:F.publishHistory,pluginId:l.id})}},P().map(function(Z,y){return e.createElement("div",{key:f+"-"+y,className:""+Z.dataIndex},Z.render?Z.render(l):l[Z.dataIndex])}))}):e.createElement(Yt,null,e.createElement("span",{className:"iconCon InlineBlock TxtCenter "},e.createElement("i",{className:"icon-extension Font64 TxtMiddle"})),e.createElement("p",{className:"Gray_9e mTop20 mBottom0"},d.keyWords?_l("\u6682\u65E0\u641C\u7D22\u7ED3\u679C"):_l("\u6682\u65E0\u6570\u636E")))),D.visible&&e.createElement(Ot,(0,Y.default)({},n,{projectId:r,belongType:h,pluginId:D.pluginId,configType:D.configType,onClose:function(){return R({visible:!1})},onUpdateSuccess:function(f,Z){var y=o.map(function(H){return H.id===f?(0,Y.default)({},H,Z):H});a(y)},onClickAway:function(){return R({visible:!1})},onClickAwayExceptions:[".mui-dialog-container",".dropdownTrigger",".ant-select-dropdown",".selectIconWrap",".ant-picker-dropdown"]})))))}var Vt=(0,V.Z)([`
  display: flex;
  align-items: center;
  width: 100%;

  .searchInput {
    width: 200px;
    margin-right: 10px;
    border: 1px solid #e0e0e0;
    background: #fff;
    input {
      min-width: 0;
    }
  }
`],[`
  display: flex;
  align-items: center;
  width: 100%;

  .searchInput {
    width: 200px;
    margin-right: 10px;
    border: 1px solid #e0e0e0;
    background: #fff;
    input {
      min-width: 0;
    }
  }
`]),Jt=(0,V.Z)([`
  padding: 8px 24px;
  min-width: 92px;
  background: #2196f3;
  border-radius: 18px;
  color: #fff;
  display: inline-block;
  cursor: pointer;
  font-weight: bold;
  &:hover {
    background: #1764c0;
  }
`],[`
  padding: 8px 24px;
  min-width: 92px;
  background: #2196f3;
  border-radius: 18px;
  color: #fff;
  display: inline-block;
  cursor: pointer;
  font-weight: bold;
  &:hover {
    background: #1764c0;
  }
`]),Xt=J.ZP.div(Vt),Kt=J.ZP.div(Jt);function hn(n){var r=n.showSearch,c=n.title,g=n.description,i=n.limitInfo,d=n.keywords,b=n.onSearch,I=n.onAdd,x=n.addText;return e.createElement(Xt,null,e.createElement("div",{className:"flex"},e.createElement("div",{className:"flexRow alignItemsCenter mBottom12 LineHeight36"},e.createElement("div",{className:"Bold Font24"},c),e.createElement("div",{className:"Font14 bold Gray_75 mLeft8"},i)),e.createElement("p",{className:"Font15 mBottom0 flexRow alignItemsCenter"},g)),r&&e.createElement("div",{className:"flexRow"},e.createElement(Me.Z,{className:"searchInput",placeholder:_l("\u641C\u7D22"),value:d,onChange:b}),e.createElement(Kt,{onClick:I},e.createElement(U.Z,{icon:"add",className:"Font13"}),e.createElement("span",{className:"mLeft5 bold LineHeight20"},x))))}var _t=u(40240),qt=(0,V.Z)([`
  margin: 0 -12px;
  display: flex;
  flex-wrap: wrap;
  .listItem {
    flex: 1;
    min-width: 325px;
    height: 180px;
    margin: 12px;
    border: 1px solid #eaeaea;
    border-radius: 8px;
    padding: 20px;
    cursor: pointer;
    &:hover {
      box-shadow: rgba(0, 0, 0, 0.16) 0 2px 5px;
      .itemHeader {
        .moreOperate {
          display: block;
        }
      }
    }
    .itemHeader {
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .iconWrapper {
        width: 36px;
        min-width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        &.hasBorder {
          border: 1px solid #e0e0e0;
        }
      }
      .moreOperate {
        display: none;
        width: 32px;
        min-width: 32px;
        height: 32px;
        text-align: center;
        border-radius: 4px;
        cursor: pointer;
        &:hover {
          background: #f5f5f5;
        }
        &.isShow {
          display: block;
        }
      }
    }
    .itemContent {
      flex: 1;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
      overflow: hidden;
      text-overflow: ellipsis;
      margin: 16px 0 24px;
      color: #9e9e9e;
    }
    .itemFooter {
      display: flex;
      align-items: center;
      justify-content: space-between;
      img {
        width: 20px;
        height: 20px;
        border-radius: 50%;
      }
      .ant-switch {
        min-width: 56px;
      }
      .ant-switch-checked {
        background-color: rgba(40, 202, 131, 1);
      }
    }
  }
`],[`
  margin: 0 -12px;
  display: flex;
  flex-wrap: wrap;
  .listItem {
    flex: 1;
    min-width: 325px;
    height: 180px;
    margin: 12px;
    border: 1px solid #eaeaea;
    border-radius: 8px;
    padding: 20px;
    cursor: pointer;
    &:hover {
      box-shadow: rgba(0, 0, 0, 0.16) 0 2px 5px;
      .itemHeader {
        .moreOperate {
          display: block;
        }
      }
    }
    .itemHeader {
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .iconWrapper {
        width: 36px;
        min-width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        &.hasBorder {
          border: 1px solid #e0e0e0;
        }
      }
      .moreOperate {
        display: none;
        width: 32px;
        min-width: 32px;
        height: 32px;
        text-align: center;
        border-radius: 4px;
        cursor: pointer;
        &:hover {
          background: #f5f5f5;
        }
        &.isShow {
          display: block;
        }
      }
    }
    .itemContent {
      flex: 1;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
      overflow: hidden;
      text-overflow: ellipsis;
      margin: 16px 0 24px;
      color: #9e9e9e;
    }
    .itemFooter {
      display: flex;
      align-items: center;
      justify-content: space-between;
      img {
        width: 20px;
        height: 20px;
        border-radius: 50%;
      }
      .ant-switch {
        min-width: 56px;
      }
      .ant-switch-checked {
        background-color: rgba(40, 202, 131, 1);
      }
    }
  }
`]),$t=(0,V.Z)([`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
  .menuItem {
    padding: 0 20px;
    line-height: 36px;
    cursor: pointer;
    color: #f44336;
    &:hover {
      background-color: #f5f5f5;
    }
  }
`],[`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
  .menuItem {
    padding: 0 20px;
    line-height: 36px;
    cursor: pointer;
    color: #f44336;
    &:hover {
      background-color: #f5f5f5;
    }
  }
`]),ea=J.ZP.div(qt),na=J.ZP.div($t);function ta(n){var r=n.list,c=r===void 0?[]:r,g=n.width,i=n.onEdit,d=n.onDelete,b=n.onSwitchStatus,I=(0,e.useState)(null),x=(0,v.Z)(I,2),o=x[0],a=x[1],w=function(){var h=325,j=Math.floor((g+24)/(h+24)),C=(c||[]).length%j,T=[];if(!C)return null;for(var D=0;D<j-C;D++)T.push(e.createElement("div",{className:"listItem Visibility"}));return T};return e.createElement(ea,null,c.map(function(p,h){return e.createElement("div",{className:"listItem flexColumn",key:h,onClick:function(){return i(p.id,p.name)}},e.createElement("div",{className:"itemHeader"},e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("div",{className:ne()("iconWrapper",{hasBorder:!p.iconUrl}),style:{backgroundColor:p.iconUrl?p.iconColor||"#2196f3":""}},p.iconUrl?e.createElement(je.Z,{url:p.iconUrl,fill:"#fff",size:24}):e.createElement(U.Z,{icon:"ai1",className:"Font24 Gray_bd"})),e.createElement("div",{className:"Font20 bold mLeft8 overflow_ellipsis",title:p.name||_l("\u672A\u547D\u540D\u52A9\u624B")},p.name||_l("\u672A\u547D\u540D\u52A9\u624B"))),e.createElement(Pe.Z,{onClick:function(C){return C.stopPropagation()},action:["click"],getPopupContainer:function(){return document.body},popupVisible:(o||{}).id===p.id,onPopupVisibleChange:function(C){return a(C?p:null)},popupAlign:{points:["tr","bl"],offset:[25,5],overflow:{adjustX:!0,adjustY:!0}},popup:e.createElement(na,null,e.createElement("div",{className:"menuItem",onClick:function(C){C.stopPropagation(),a(null),ie.Z.confirm({title:e.createElement("div",{style:{color:"#f44336"}},_l("\u5220\u9664\u52A9\u624B")+("\u201C"+o.name+"\u201D")),buttonType:"danger",description:_l("\u5220\u9664\u540E\u5C06\u4E0D\u53EF\u6062\u590D\uFF0C\u786E\u8BA4\u5220\u9664\u5417\uFF1F"),okText:_l("\u5220\u9664"),onOk:function(){return d(o.id)}})}},_l("\u5220\u9664")))},e.createElement("div",{className:ne()("moreOperate",{isShow:(o||{}).id===p.id})},e.createElement(U.Z,{icon:"more_horiz",className:"Font16 Gray_9e LineHeight32"})))),e.createElement("div",{className:"itemContent",title:p.description},p.description),e.createElement("div",{className:"itemFooter"},e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement("img",{src:p.creatorInfo.avatar}),e.createElement("span",{className:"mLeft8 Gray_9e"},p.creatorInfo.fullname),e.createElement("span",{className:"mLeft8 Gray_9e"},createTimeSpan(p.createTime))),e.createElement(ln.Z,{checkedChildren:_l("\u5F00\u542F"),unCheckedChildren:_l("\u5173\u95ED"),checked:p.status===2,onChange:function(C,T){T.stopPropagation();var D=C?2:3;b(p.id,D,function(){return alert(D===2?_l("\u5F00\u542F\u6210\u529F"):_l("\u5173\u95ED\u6210\u529F"))})}})))}),w())}const aa=(0,_t.Z)(ta);var le=u(88271),ra=u(20640),xn=u.n(ra),vn=u(36021),ia=(0,V.Z)([`
  height: 100%;
  display: flex;
  flex-direction: column;
  .searchInput {
    width: 200px;
    margin-right: 10px;
    border: 1px solid #e0e0e0;
    background: #fff;
    input {
      min-width: 0;
    }
  }
  .knowledgeItem {
    margin-top: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    height: 64px;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    cursor: pointer;
    .nameText {
      font-size: 15px;
      font-weight: 500;
    }
    &:hover {
      border-color: #2196f3;
    }
  }
`],[`
  height: 100%;
  display: flex;
  flex-direction: column;
  .searchInput {
    width: 200px;
    margin-right: 10px;
    border: 1px solid #e0e0e0;
    background: #fff;
    input {
      min-width: 0;
    }
  }
  .knowledgeItem {
    margin-top: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    height: 64px;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    cursor: pointer;
    .nameText {
      font-size: 15px;
      font-weight: 500;
    }
    &:hover {
      border-color: #2196f3;
    }
  }
`]),oa=(0,V.Z)([`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  .iconWrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    background: #f5f5f5;
    margin-bottom: 20px;
  }
`],[`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  .iconWrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    background: #f5f5f5;
    margin-bottom: 20px;
  }
`]),la=J.ZP.div(ia),sa=J.ZP.div(oa);function ca(n){var r=n.onOk,c=n.onClose,g=n.projectId,i=(0,pe.Z)({loading:!0,pageIndex:1,noMore:!1,keywords:""}),d=(0,v.Z)(i,2),b=d[0],I=d[1],x=(0,e.useState)([]),o=(0,v.Z)(x,2),a=o[0],w=o[1],p=function(){b.loading&&le.Z.getListKnowledgeBase({projectId:g,pageIndex:b.pageIndex,pageSize:50,keywords:b.keywords}).then(function(T){if(T){var D=T.list.filter(function(R){return R.fileCount});w(b.pageIndex>1?a.concat(D):D),I({loading:!1,noMore:T.list.length<50})}}).catch(function(T){I({loading:!1})})},h=function(){!b.noMore&&!b.loading&&I({loading:!0,pageIndex:b.pageIndex+1})},j=(0,e.useCallback)(O().debounce(function(C){I({loading:!0,pageIndex:1,keywords:C})},500),[]);return(0,e.useEffect)(p,[b.loading,b.pageIndex,b.keywords]),e.createElement(ie.Z,{visible:!0,type:"fixed",showFooter:!1,width:660,title:_l("\u9009\u62E9\u77E5\u8BC6\u5E93"),onCancel:c},e.createElement(la,null,e.createElement("div",{className:"flexRow alignItemsCenter"},e.createElement(Me.Z,{className:"searchInput",placeholder:_l("\u641C\u7D22"),value:b.keywords,onChange:j}),e.createElement("div",{className:"flex"}),e.createElement("div",{className:"InlineBlock ThemeColor ThemeHoverColor2 pointer",onClick:function(){c(),(0,vn.T8)("/plugin/knowledgeBase")}},_l("+ \u65B0\u5EFA\u77E5\u8BC6\u5E93"))),!a.length&&(b.loading?e.createElement(xe.Z,{className:"mTop10"}):e.createElement(sa,null,e.createElement("div",{className:"iconWrapper"},e.createElement(U.Z,{icon:"import_contacts",className:"Font48 Gray_bd"})),e.createElement("div",{className:"mBottom20 Font17 Gray_bd"},_l("\u6682\u65E0\u6570\u636E\uFF0C\u8BF7\u5148\u6DFB\u52A0\u77E5\u8BC6\u5E93")))),!!a.length&&e.createElement(Be.Z,{className:"flex",onScrollEnd:h},a.map(function(C){return e.createElement("div",{className:"knowledgeItem",onClick:function(){r(C),c()}},e.createElement("div",{className:"nameText"},C.name),e.createElement("div",{className:"Font14 Gray_9e"},(0,ee.sS)(C.fileSize)))}),b.loading&&e.createElement(xe.Z,{className:"mTop10"}))))}const En=function(n){return(0,Xe.Z)(ca,(0,Y.default)({},n))};var da=(0,V.Z)([`
  padding: 0 50px;

  .avatarWrapper {
    display: flex;
    justify-content: center;
    margin-bottom: 16px;
    height: 64px;
    .updateAvatarBtn {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 64px;
      height: 64px;
      border-radius: 50%;
      cursor: pointer;
      &.isAdd {
        border: 1px dashed #bdbdbd;
      }
    }
  }

  .divider {
    height: 1px;
    background: #e0e0e0;
    margin: 20px 0;
  }
  .requiredStar {
    color: #f44336;
    margin-left: 4px;
    font-size: 15px;
    font-weight: bold;
  }
  .groupTitle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
    .titleText {
      font-size: 17px;
      font-weight: 600;
      margin-left: 4px;
    }
    .autoGenerate {
      display: flex;
      align-items: center;
      height: 36px;
      padding: 0 8px;
      border-radius: 5px;

      i {
        color: #f19f39;
        font-size: 20px;
      }
      span {
        color: #757575;
        margin-left: 4px;
      }
      &.notGenerating {
        cursor: pointer;
        &:hover {
          background: #fff;
        }
      }
    }
  }
`],[`
  padding: 0 50px;

  .avatarWrapper {
    display: flex;
    justify-content: center;
    margin-bottom: 16px;
    height: 64px;
    .updateAvatarBtn {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 64px;
      height: 64px;
      border-radius: 50%;
      cursor: pointer;
      &.isAdd {
        border: 1px dashed #bdbdbd;
      }
    }
  }

  .divider {
    height: 1px;
    background: #e0e0e0;
    margin: 20px 0;
  }
  .requiredStar {
    color: #f44336;
    margin-left: 4px;
    font-size: 15px;
    font-weight: bold;
  }
  .groupTitle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
    .titleText {
      font-size: 17px;
      font-weight: 600;
      margin-left: 4px;
    }
    .autoGenerate {
      display: flex;
      align-items: center;
      height: 36px;
      padding: 0 8px;
      border-radius: 5px;

      i {
        color: #f19f39;
        font-size: 20px;
      }
      span {
        color: #757575;
        margin-left: 4px;
      }
      &.notGenerating {
        cursor: pointer;
        &:hover {
          background: #fff;
        }
      }
    }
  }
`]),ua=(0,V.Z)([`
  margin-bottom: 16px;
  .labelText {
    font-size: 14px;
    margin-bottom: 8px;
  }
  input {
    width: 100%;
  }
  .knowledgeLibWrapper {
    display: flex;
    align-items: center;
    height: 56px;
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    padding: 0 16px;
    font-size: 15px;
    font-weight: 600;
    background-color: #fff;
    cursor: pointer;

    &.isDel {
      border: 1px solid #f44336;
      .delText {
        color: #f44336;
      }
    }
    .swapIcon {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      i {
        color: #bdbdbd;
        font-size: 20px;
      }
      &:hover {
        background: #f5f5f5;
      }
    }
  }
  .exampleQuestionList {
    .questionItem {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
    }
  }
  .linkBox {
    display: flex;
    width: 100%;
    min-height: 36px;
    line-height: 36px;
    box-sizing: border-box;
    border-radius: 3px;
    padding: 0 12px;
    font-size: 14px;
    background: #fff;
    .copyBtn {
      cursor: pointer;
      margin-left: 12px;
      margin-top: 10px;
      font-size: 16px;
      color: #757575;
      &:hover {
        color: #2196f3;
      }
    }
  }
`],[`
  margin-bottom: 16px;
  .labelText {
    font-size: 14px;
    margin-bottom: 8px;
  }
  input {
    width: 100%;
  }
  .knowledgeLibWrapper {
    display: flex;
    align-items: center;
    height: 56px;
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    padding: 0 16px;
    font-size: 15px;
    font-weight: 600;
    background-color: #fff;
    cursor: pointer;

    &.isDel {
      border: 1px solid #f44336;
      .delText {
        color: #f44336;
      }
    }
    .swapIcon {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      i {
        color: #bdbdbd;
        font-size: 20px;
      }
      &:hover {
        background: #f5f5f5;
      }
    }
  }
  .exampleQuestionList {
    .questionItem {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
    }
  }
  .linkBox {
    display: flex;
    width: 100%;
    min-height: 36px;
    line-height: 36px;
    box-sizing: border-box;
    border-radius: 3px;
    padding: 0 12px;
    font-size: 14px;
    background: #fff;
    .copyBtn {
      cursor: pointer;
      margin-left: 12px;
      margin-top: 10px;
      font-size: 16px;
      color: #757575;
      &:hover {
        color: #2196f3;
      }
    }
  }
`]),pa=(0,V.Z)([`
  .indicateExample {
    padding: 12px 8px;
    border-radius: 4px;
    background: #f5f5f5;
  }
`],[`
  .indicateExample {
    padding: 12px 8px;
    border-radius: 4px;
    background: #f5f5f5;
  }
`]),fa=J.ZP.div(da),Ae=J.ZP.div(ua),ma=(0,J.ZP)(ie.Z)(pa);function ga(n){var r=n.assistantConfig,c=n.onChangeConfig,g=n.projectId,i=r.id,d=r.icon,b=r.iconColor,I=r.iconUrl,x=r.name,o=r.description,a=r.instructions,w=r.preamble,p=r.exampleQuestions,h=p===void 0?[]:p,j=r.knowledgeBaseName,C=r.knowledgeFileSize,T=r.status,D=r.shareUrl,R=(0,e.useState)([]),k=(0,v.Z)(R,2),s=k[0],S=k[1],P=(0,e.useState)(!1),l=(0,v.Z)(P,2),f=l[0],Z=l[1],y=(0,e.useState)(!1),H=(0,v.Z)(y,2),_=H[0],X=H[1],Q="<iframe width=\u201C100%\u201D height=\u201C100%\u201D style=\u201Cborder: none;margin: 0; padding: 0;\u201D src=\u201C"+D+"\u201D></iframe>",G=function(){if(!_){if(!x||!o||!a){alert(x?o?_l("\u6307\u793A\u4E0D\u80FD\u4E3A\u7A7A"):_l("\u63CF\u8FF0\u4E0D\u80FD\u4E3A\u7A7A"):_l("\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A"),3);return}X(!0),le.Z.generateAssistantPreamble({projectId:g,name:x,description:o,instructions:a}).then(function(A){X(!1);var L=safeParse(O().get(safeParse(A),["choices","0","message","tool_calls","0","function","arguments"])||"{}");if(!O().isEmpty(L)){var N=L.welcome_message||"",te=L.Example_Questions||"";c({preamble:N,exampleQuestions:te})}}).catch(function(A){return X(!1)})}},m=function(A){var L={knowledgeBase:{text:_l("\u77E5\u8BC6\u5E93"),isRequired:!0},chatSet:{text:_l("\u5BF9\u8BDD\u8BBE\u7F6E"),isRequired:!1},integrationSet:{text:_l("\u96C6\u6210\u8BBE\u7F6E"),isRequired:!1}},N=O().includes(s,A);return e.createElement("div",{className:"groupTitle"},e.createElement("div",{className:"flexRow alignItemsCenter pointer",onClick:function(){S(N?s.filter(function(z){return z!==A}):s.concat(A))}},e.createElement(U.Z,{icon:N?"arrow-right-border":"arrow-down-border"}),e.createElement("div",{className:"titleText"},L[A].text),L[A].isRequired&&e.createElement("span",{className:"requiredStar"},"*")),A==="chatSet"&&e.createElement("div",{className:ne()("autoGenerate",{notGenerating:!_}),onClick:G},_?e.createElement(xe.Z,{size:"small"}):e.createElement(U.Z,{icon:"ai"}),e.createElement("span",null,_?_l("\u751F\u6210\u4E2D..."):_l("\u81EA\u52A8\u751F\u6210"))))},t=function(){var A="# \u89D2\u8272 \u4F01\u4E1A\u7EA7\u77E5\u8BC6\u5E93\u95EE\u7B54\u52A9\u624B## \u76EE\u6807  \u60A8\u7684\u4E3B\u8981\u4EFB\u52A1\u662F\u6839\u636E\u5BA2\u6237\u95EE\u9898\u548C\u4E0A\u4F20\u7684\u4F01\u4E1A\u77E5\u8BC6\u5E93\u6587\u6863\u63D0\u4F9B\u603B\u7ED3\u7B54\u6848\u3002\u60A8\u9700\u8981\u5728\u56DE\u7B54\u4E2D\u5C55\u793A\u5BF9\u6587\u6863\u5185\u5BB9\u7684\u6DF1\u523B\u7406\u89E3\u5E76\u5904\u7406\u4F01\u4E1A\u76F8\u5173\u7684\u67E5\u8BE2\uFF0C\u4ECE\u4F01\u4E1A\u77E5\u8BC6\u5E93\u4E2D\u63D0\u53D6\u5FC5\u8981\u7684\u4FE1\u606F\uFF0C\u5E2E\u52A9\u89E3\u7B54\u5458\u5DE5\u7684\u7591\u95EE\u3002## \u6280\u80FD  1. \u7528\u6237\u63D0\u51FA\u57FA\u4E8E\u4F01\u4E1A\u77E5\u8BC6\u5E93\u7684\u95EE\u9898\u30022. \u5206\u6790\u95EE\u9898\uFF0C\u786E\u5B9A\u5173\u952E\u8BCD\u548C\u76F8\u5173\u9886\u57DF\u30023. \u5728\u4F01\u4E1A\u77E5\u8BC6\u5E93\u4E2D\u68C0\u7D22\u76F8\u5173\u4FE1\u606F\u30024. \u6839\u636E\u68C0\u7D22\u7ED3\u679C\uFF0C\u5F62\u6210\u51C6\u786E\u3001\u5168\u9762\u7684\u56DE\u7B54## \u9650\u5236  1. \u4EC5\u4F7F\u7528\u4F01\u4E1A\u77E5\u8BC6\u5E93\u4E2D\u7684\u4FE1\u606F\u8FDB\u884C\u56DE\u7B54\uFF0C\u4E0D\u5F15\u5165\u5916\u90E8\u4FE1\u606F\u30022. \u4FDD\u6301\u56DE\u7B54\u7684\u4E13\u4E1A\u6027\u548C\u51C6\u786E\u6027\uFF0C\u786E\u4FDD\u4FE1\u606F\u7684\u5B89\u5168\u6027\u548C\u4FDD\u5BC6\u6027\u30023. \u5728\u4EA4\u4E92\u8FC7\u7A0B\u4E2D\u4FDD\u6301\u4E2D\u7ACB\uFF0C\u907F\u514D\u63D0\u4F9B\u4EFB\u4F55\u4E3B\u89C2\u5224\u65AD\u6216\u5EFA\u8BAE\u3002";return e.createElement(ma,{visible:!0,title:_l("\u793A\u4F8B"),okText:_l("\u4F7F\u7528"),onOk:function(){c({instructions:A}),Z(!1)},onCancel:function(){return Z(!1)}},e.createElement("div",{className:"mBottom16"},_l("\u6211\u4EEC\u5EFA\u8BAE\u4F7F\u7528\u7ED3\u6784\u5316\u63D0\u793A\u6765\u521B\u5EFA\u52A9\u624B\u7684\u89D2\u8272\u548C\u9884\u63D0\u793A\u3002\u7ED3\u6784\u5316\u63D0\u793A\u66F4\u6613\u4E8E\u9605\u8BFB\uFF0C\u53EF\u4EE5\u63D0\u9AD8\u8FED\u4EE3\u6548\u7387\uFF0C\u5E76\u4F7FBot\u7684\u6027\u80FD\u66F4\u52A0\u7A33\u5B9A\u3002\u4EE5\u4E0B\u662F\u4E00\u4F4D\u4F01\u4E1A\u77E5\u8BC6\u5E93\u52A9\u624B\u7684\u4F8B\u5B50\uFF1A")),e.createElement("div",{className:"indicateExample"},A))};return e.createElement(Be.Z,{className:"flex"},e.createElement(fa,null,e.createElement("div",{className:"avatarWrapper"},e.createElement(Pe.Z,{action:["click"],popup:e.createElement(sn.Z,{hideInput:!0,style:{left:"-480px",top:"10px"},iconColor:b||"#2196f3",icon:d,projectId:g,onModify:function(A){var L=A.iconColor,N=A.icon,te=A.iconUrl,z={};L?z={iconColor:L}:z={icon:N,iconUrl:te},c(z)}}),zIndex:1e3,popupAlign:{points:["tl","bl"],overflow:{adjustX:!0,adjustY:!0}}},e.createElement("div",{className:ne()("updateAvatarBtn",{isAdd:!I}),style:{backgroundColor:I?b||"#2196f3":""}},I?e.createElement(je.Z,{url:I,fill:"#fff",size:32}):e.createElement(U.Z,{icon:"add",className:"Font28 Gray_bd"})))),e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u540D\u79F0")),e.createElement(Ne.Z,{maxLength:20,value:x,onChange:function(A){return c({name:A})}})),e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u63CF\u8FF0")),e.createElement(Ne.Z,{maxLength:200,value:o,onChange:function(A){return c({description:A})}})),e.createElement(Ae,null,e.createElement("div",{className:"flexRow"},e.createElement("div",{className:"labelText flex"},_l("\u6307\u793A"),e.createElement("span",{className:"requiredStar"},"*")),e.createElement("div",{className:"ThemeColor ThemeHoverColor2 pointer",onClick:function(){return Z(!0)}},_l("\u67E5\u770B\u793A\u4F8B"))),e.createElement(Ve.Z,{value:a,onChange:function(A){return c({instructions:A})},minHeight:160,maxHeight:240,placeholder:_l("\u53EF\u4EE5\u8BBE\u5B9A\u5BF9\u8BDD\u7684\u80CC\u666F\u3001\u89D2\u8272\u53CA\u9650\u5236\u6761\u4EF6\uFF0C\u4EE5\u4FBF\u6839\u636E\u8FD9\u4E9B\u8BBE\u5B9A\u6765\u5B9A\u5236\u548C\u4F18\u5316\u52A9\u624B\u7684\u56DE\u7B54")}),f&&t()),e.createElement("div",{className:"divider"}),m("knowledgeBase"),!O().includes(s,"knowledgeBase")&&e.createElement(Ae,null,e.createElement("div",{className:ne()("knowledgeLibWrapper",{isDel:i&&!j})},i&&!j?e.createElement("span",{className:"delText"},_l("\u77E5\u8BC6\u5E93\u5DF2\u5220\u9664")):e.createElement(e.Fragment,null,e.createElement("span",null,j),e.createElement("span",{className:"Font12 Gray_bd mLeft16"},(0,ee.sS)(C))),e.createElement("div",{className:"flex"}),e.createElement("div",{className:"swapIcon",onClick:function(A){A.stopPropagation(),En({projectId:g,onOk:function(N){return c({knowledgeBaseId:N.id,knowledgeBaseName:N.name,knowledgeFileSize:N.fileSize})}})}},e.createElement(U.Z,{icon:"swap_horiz"})))),e.createElement("div",{className:"divider"}),m("chatSet"),!O().includes(s,"chatSet")&&e.createElement(e.Fragment,null,e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u5F00\u573A\u767D")),e.createElement(Ve.Z,{value:w,onChange:function(A){return c({preamble:A})},minHeight:76,maxHeight:76})),e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u793A\u4F8B\u63D0\u95EE")),e.createElement("div",{className:"exampleQuestionList"},h.map(function(E,A){return e.createElement("div",{className:"questionItem",key:A},e.createElement(Ne.Z,{className:"flex",value:E,onChange:function(N){c({exampleQuestions:h.map(function(te,z){return z===A?N:te})})}}),e.createElement(U.Z,{icon:"remove_circle_outline1",className:"Font20 mLeft10 "+(h.length>1?"pointer Gray_9e ThemeHoverColor3":"Gray_d"),onClick:function(){h.length>1&&c({exampleQuestions:h.filter(function(N,te){return te!==A})})}}),e.createElement(U.Z,{icon:"add_circle_outline",className:"Font20 mLeft10 "+(h.length<4?"pointer Gray_9e ThemeHoverColor3":"Gray_d"),onClick:function(){h.length<4&&c({exampleQuestions:h.concat([""])})}}))})))),e.createElement("div",{className:"divider"}),T>1&&e.createElement("div",{className:"mBottom24"},m("integrationSet"),!O().includes(s,"integrationSet")&&e.createElement(e.Fragment,null,e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u65B9\u5F0F\u4E00\uFF1A\u9875\u9762\u94FE\u63A5")),e.createElement("div",{className:"linkBox"},e.createElement("div",{className:"flex overflow_ellipsis"},D),e.createElement(U.Z,{icon:"copy",className:"copyBtn",onClick:function(){xn()(D),alert(_l("\u590D\u5236\u6210\u529F"))}}))),e.createElement(Ae,null,e.createElement("div",{className:"labelText"},_l("\u65B9\u5F0F\u4E8C\uFF1Aiframe\u94FE\u63A5")),e.createElement("div",{className:"linkBox"},e.createElement("div",{className:"flex breakAll"},Q),e.createElement(U.Z,{icon:"copy",className:"copyBtn",onClick:function(){xn()(Q),alert(_l("\u590D\u5236\u6210\u529F"))}})))))))}var bn=u(30752),lr=u(917),ha=(0,V.Z)([`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 999;
  background-color: #f8f8f8;
  display: flex;
  flex-direction: column;
`],[`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 999;
  background-color: #f8f8f8;
  display: flex;
  flex-direction: column;
`]),xa=(0,V.Z)([`
  display: flex;
  z-index: 1;
  height: 55px;
  min-height: 55px;
  padding: 0 16px 0 10px;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  box-shadow: 0 1px 2px 1px rgba(0, 0, 0, 0.16);

  .headerBtn {
    min-width: 50px;
    height: 38px;
    padding: 0 16px;

    &.disabled {
      background: #93c4f1 !important;
    }
  }
  .workflowStatusWrap {
    .disable,
    .disable:hover {
      .iconWrap .workflowSwitchIcon-active {
        color: #bdbdbd !important;
      }
    }
  }
`],[`
  display: flex;
  z-index: 1;
  height: 55px;
  min-height: 55px;
  padding: 0 16px 0 10px;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  box-shadow: 0 1px 2px 1px rgba(0, 0, 0, 0.16);

  .headerBtn {
    min-width: 50px;
    height: 38px;
    padding: 0 16px;

    &.disabled {
      background: #93c4f1 !important;
    }
  }
  .workflowStatusWrap {
    .disable,
    .disable:hover {
      .iconWrap .workflowSwitchIcon-active {
        color: #bdbdbd !important;
      }
    }
  }
`]),va=(0,V.Z)([`
  display: flex;
  flex: 1;

  .left {
    border-right: 1px solid #e0e0e0;
    background: #fff;
  }
  .right {
    .tabWrapper {
      display: flex;
      width: 330px;
      height: 40px;
      padding: 4px;
      margin: 24px 0 16px 0;
      background: #eff0f0;
      border-radius: 4px;
      .tabItem {
        flex: 1;
        border-radius: 4px;
        line-height: 32px;
        text-align: center;
        font-weight: 500;
        color: #757575;
        cursor: pointer;
        &.isActive {
          background: #fff;
          color: #2196f3;
        }
      }
    }
  }
`],[`
  display: flex;
  flex: 1;

  .left {
    border-right: 1px solid #e0e0e0;
    background: #fff;
  }
  .right {
    .tabWrapper {
      display: flex;
      width: 330px;
      height: 40px;
      padding: 4px;
      margin: 24px 0 16px 0;
      background: #eff0f0;
      border-radius: 4px;
      .tabItem {
        flex: 1;
        border-radius: 4px;
        line-height: 32px;
        text-align: center;
        font-weight: 500;
        color: #757575;
        cursor: pointer;
        &.isActive {
          background: #fff;
          color: #2196f3;
        }
      }
    }
  }
`]),Ea=J.ZP.div(ha),ba=J.ZP.div(xa),Ia=J.ZP.div(va),Ca=[{key:"create",text:_l("\u521B\u5EFA")},{key:"setting",text:_l("\u914D\u7F6E")}];function ka(n){var r=n.onClose,c=n.projectId,g=n.assistantId,i=n.assistantName,d=n.knowledgeBase,b=d===void 0?{}:d,I=n.onRefreshList,x=n.onUpdateSuccess,o=n.onSwitchStatus,a=(0,pe.Z)((0,Y.default)({id:g,name:i,iconUrl:"",description:"",instructions:"",preamble:"",exampleQuestions:[""],status:1},b)),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)([{role:"assistant",content:""}]),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=(0,e.useState)(g?"setting":"create"),k=(0,v.Z)(R,2),s=k[0],S=k[1],P=(0,e.useState)(!1),l=(0,v.Z)(P,2),f=l[0],Z=l[1],y=(0,e.useState)(!0),H=(0,v.Z)(y,2),_=H[0],X=H[1],Q=p.id,G=p.status,m=p.instructions,t=p.knowledgeBaseName,E=G===2?"active":"close";(0,e.useEffect)(function(){g&&le.Z.get({projectId:c,assistantId:g}).then(function(L){L&&h(O().omit(L,["creator","createTime"]))})},[]);var A=function(){if(!(f||_)){if(!m){alert(_l("\u6307\u793A\u4E0D\u80FD\u4E3A\u7A7A"),3);return}if(!t){alert(_l("\u77E5\u8BC6\u5E93\u4E0D\u5B58\u5728"),3);return}Z(!0),le.Z.upsert((0,Y.default)({projectId:c},O().pick(p,["id","icon","iconColor","name","description","instructions","knowledgeBaseId","preamble"]),{exampleQuestions:p.exampleQuestions.filter(function(N){return!!N})})).then(function(N){N&&(alert(_l("\u4FDD\u5B58\u6210\u529F")),!Q&&h({id:N}),Q?x(Q,p):I(),Z(!1))}).catch(function(N){return Z(!1)})}};return e.createElement(Ea,null,e.createElement(ba,null,e.createElement("div",{className:"flexRow alignItemsCenter Hand",onClick:r},e.createElement(U.Z,{icon:"arrow_back",className:"Gray_75 Font22 bold"}),e.createElement("span",{className:"Gray Font16 bold pLeft10"},g?i:_l("\u521B\u5EFA\u52A9\u624B"))),e.createElement("div",{className:"flexRow"},G===1&&Q&&e.createElement(Qe.ZP,{type:"ghost",className:"headerBtn",onClick:function(){return o(Q,2,function(){h({status:2}),alert(_l("\u53D1\u5E03\u6210\u529F"))})}},_l("\u53D1\u5E03\u52A9\u624B")),O().includes([2,3],G)&&e.createElement("div",{className:"workflowStatusWrap"},e.createElement("div",{className:ne()("switchWrap","switchWrap-"+E,{disable:!1}),onClick:function(){var N=G===2?3:2;o(Q,N,function(){h({status:N}),alert(N===2?_l("\u5F00\u542F\u6210\u529F"):_l("\u5173\u95ED\u6210\u529F"))})}},e.createElement("div",{className:ne()("contentWrap","contentWrap-"+E)},e.createElement("div",null,G===2?_l("\u8FD0\u884C\u4E2D"):_l("\u5DF2\u5173\u95ED"))),e.createElement("div",{className:ne()("iconWrap","iconWrap-"+E)},e.createElement(U.Z,{icon:"hr_ok",className:ne()("Font20 Gray_bd","workflowSwitchIcon-"+E)})))),e.createElement(Qe.ZP,{type:"primary",className:ne()("headerBtn mLeft16",{disabled:f||_}),disabled:f||_,onClick:A},f?_l("\u4FDD\u5B58\u4E2D..."):_l("\u4FDD\u5B58")))),e.createElement(Ia,null,e.createElement("div",{className:"flex minWidth0"},e.createElement(bn.Z,{className:"left",assistantConfig:p,projectId:c})),e.createElement("div",{className:"flex right flexColumn alignItemsCenter"},e.createElement("div",{className:"tabWrapper"},Ca.map(function(L){return e.createElement("div",{className:ne()("tabItem",{isActive:L.key===s}),onClick:function(){return S(L.key)}},L.text)})),s==="create"?e.createElement(bn.Z,{isDialogueCreate:!0,notAllowRestart:!0,projectId:c,assistantConfig:p,onChangeConfig:function(N){X(!1),h(N)},createMsgList:T,setCreateMsgList:D}):e.createElement(ga,{projectId:c,assistantConfig:p,onChangeConfig:function(N){X(!1),h(N)}}))))}var ya=(0,V.Z)([`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  .iconWrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    background: #f5f5f5;
    margin-bottom: 20px;
  }
`],[`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  .iconWrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    background: #f5f5f5;
    margin-bottom: 20px;
  }
`]),wa=(0,V.Z)([`
  padding: 8px 24px;
  min-width: 92px;
  background: #2196f3;
  border-radius: 18px;
  color: #fff;
  display: inline-block;
  cursor: pointer;
  font-weight: bold;
  &:hover {
    background: #1764c0;
  }
`],[`
  padding: 8px 24px;
  min-width: 92px;
  background: #2196f3;
  border-radius: 18px;
  color: #fff;
  display: inline-block;
  cursor: pointer;
  font-weight: bold;
  &:hover {
    background: #1764c0;
  }
`]),Sa=J.ZP.div(ya),Na=J.ZP.div(wa);function In(n){var r=n.icon,c=n.emptyText,g=n.showAddIcon,i=n.onAdd,d=n.addText;return e.createElement(Sa,null,e.createElement("div",{className:"iconWrapper"},e.createElement(U.Z,{icon:r,className:"Font48 Gray_bd"})),e.createElement("div",{className:"mBottom20 Font17 Gray_bd"},c),g&&e.createElement(Na,{onClick:i},e.createElement(U.Z,{icon:"add",className:"Font13"}),e.createElement("span",{className:"mLeft5 bold LineHeight20"},d)))}var Aa=(0,V.Z)([`
  background: #fff;
  min-height: 100%;
  padding: 32px;
`],[`
  background: #fff;
  min-height: 100%;
  padding: 32px;
`]),Za=J.ZP.div(Aa);function Ta(n){var r=n.currentProjectId,c=(0,e.useState)([]),g=(0,v.Z)(c,2),i=g[0],d=g[1],b=(0,e.useState)(""),I=(0,v.Z)(b,2),x=I[0],o=I[1],a=(0,e.useState)(!0),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)({}),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=(0,e.useState)({visible:!1}),k=(0,v.Z)(R,2),s=k[0],S=k[1],P=(0,e.useState)(null),l=(0,v.Z)(P,2),f=l[0],Z=l[1],y=(0,ee.XH)(r,ke.UU.assistant);(0,e.useEffect)(function(){le.Z.getAIAssistantLimitNumber({projectId:r}).then(function(m){m&&D(m)})},[]),(0,e.useEffect)(function(){return H()},[x]);var H=function(){!p&&h(!0),le.Z.getList({projectId:r,keywords:x}).then(function(t){t&&(h(!1),d(t))}).catch(function(t){h(!1)})},_=function(){var t=T.aiAssistantLimitNumber<=0;t?ie.Z.confirm({buttonType:"danger",title:_l("\u5BB9\u91CF\u4E0D\u8DB3"),description:_l("\u8D85\u8FC7\u52A9\u624B\u6570\u91CF\u9650\u5236"),removeCancelBtn:!0}):En({projectId:r,onOk:function(A){Z({knowledgeBaseId:A.id,knowledgeBaseName:A.name,knowledgeFileSize:A.fileSize}),ie.Z.confirm({title:_l("\u63D0\u9192"),description:_l("\u672C\u529F\u80FD\u9700\u8981\u5C06\u5BF9\u8BDD\u6570\u636E\u4F20\u8F93\u81F3 OpenAI\uFF0C\u8BF7\u786E\u8BA4\u77E5\u6653\u5E76\u5F00\u59CB\u4F7F\u7528"),onOk:function(){return S({visible:!0})},removeCancelBtn:!0})}})},X=(0,e.useCallback)(O().debounce(function(m){return o(m)},500),[]),Q=function(t){le.Z.delete({projectId:r,assistantId:t}).then(function(E){E&&(alert(_l("\u5220\u9664\u6210\u529F")),d(i.filter(function(A){return A.id!==t})),window.updateAssistantApiList&&window.updateAssistantApiList())})},G=function(t,E,A){le.Z.setStatus({projectId:r,assistantId:t,status:E}).then(function(L){L&&(A&&A(),d(i.map(function(N){return N.id===t?(0,Y.default)({},N,{status:E}):N})),window.updateAssistantApiList&&window.updateAssistantApiList())})};return y==="2"?(0,ee.j0)(r,ke.UU.assistant,{dialogType:"content"}):e.createElement(Za,{className:"flexColumn h100"},e.createElement(hn,{title:_l("\u52A9\u624B"),description:_l("\u57FA\u4E8E\u4F01\u4E1A\u77E5\u8BC6\u7EC4\u5B66\u4E60\uFF0C\u642D\u5EFA AI \u95EE\u7B54\u52A9\u624B"),limitInfo:"("+(T.aiAssistantCount||0)+" / "+(T.aiAssistantTotalLimitNumber||0)+")",showSearch:!!i.length||x,keywords:x,onSearch:X,onAdd:_,addText:_l("\u52A9\u624B")}),!i.length&&(p?e.createElement(xe.Z,{className:"mTop10"}):e.createElement(In,{icon:"contact_support",emptyText:x?_l("\u6682\u65E0\u641C\u7D22\u7ED3\u679C"):_l("\u6682\u65E0\u6570\u636E\uFF0C\u8BF7\u5148\u6DFB\u52A0\u52A9\u624B"),showAddIcon:!x,onAdd:function(){return S({visible:!0})},addText:_l("\u52A9\u624B")})),!!i.length&&e.createElement(Be.Z,{className:"flex mTop12"},e.createElement(aa,{list:i,onEdit:function(t,E){return S({visible:!0,editId:t,editName:E})},onDelete:Q,onSwitchStatus:G}),p&&e.createElement(xe.Z,{className:"mTop10"})),s.visible&&e.createElement(ka,{projectId:r,assistantId:s.editId,assistantName:s.editName,knowledgeBase:f,onClose:function(){return S({visible:!1})},onRefreshList:H,onUpdateSuccess:function(t,E){return d(i.map(function(A){return A.id===t?(0,Y.default)({},A,E):A}))},onSwitchStatus:G}))}var La=(0,V.Z)([`
  .mui-dialog-header {
    padding: 20px 24px 24px !important;
    .mui-dialog-desc {
      padding-top: 8px !important;
    }
  }
`],[`
  .mui-dialog-header {
    padding: 20px 24px 24px !important;
    .mui-dialog-desc {
      padding-top: 8px !important;
    }
  }
`]),Ba=(0,V.Z)([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  .foldableTitle {
    width: fit-content;
    margin-left: -15px;
    i {
      color: #9e9e9e;
      font-weight: bold;
      margin-right: 2px;
    }
    &:hover {
      i {
        color: #2196f3;
      }
    }
  }
  .searchInput {
    width: 200px;
    min-width: 200px;
    input {
      min-width: 0;
    }
  }
`],[`
  display: flex;
  justify-content: space-between;
  align-items: center;
  .foldableTitle {
    width: fit-content;
    margin-left: -15px;
    i {
      color: #9e9e9e;
      font-weight: bold;
      margin-right: 2px;
    }
    &:hover {
      i {
        color: #2196f3;
      }
    }
  }
  .searchInput {
    width: 200px;
    min-width: 200px;
    input {
      min-width: 0;
    }
  }
`]),Qa=(0,V.Z)([`
  display: flex;
  align-items: center;
  padding: 12px 0;
  &:hover {
    background: #f5f5f5;
    .deleteIcon {
      display: block;
    }
  }
  &.isHeader {
    padding: 0;
    margin-top: 24px;
    font-size: 12px;
    font-weight: 600;
    color: #757575;
    &:hover {
      background: #fff;
    }
  }
  &.disabled {
    color: #9e9e9e !important;
    .fileName {
      .source {
        color: #9e9e9e !important;
      }
    }
  }
  .fileName {
    flex: 6;
    display: flex;
    align-items: center;
    min-width: 0;
    padding-right: 8px;
    .fileIcon {
      width: 21px;
      min-width: 21px;
      height: 24px;
      margin-right: 8px;
    }
    .source {
      color: #757575;
      margin-top: 4px;
    }
  }
  .uploadTime {
    flex: 3;
  }
  .fileSize,
  .creator {
    flex: 2;
  }
  .deleteIcon {
    display: none;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    text-align: center;
    cursor: pointer;
    color: #9e9e9e;
    i {
      line-height: 36px;
    }
    &:hover {
      color: #f44336;
      background: #fff;
    }
  }
`],[`
  display: flex;
  align-items: center;
  padding: 12px 0;
  &:hover {
    background: #f5f5f5;
    .deleteIcon {
      display: block;
    }
  }
  &.isHeader {
    padding: 0;
    margin-top: 24px;
    font-size: 12px;
    font-weight: 600;
    color: #757575;
    &:hover {
      background: #fff;
    }
  }
  &.disabled {
    color: #9e9e9e !important;
    .fileName {
      .source {
        color: #9e9e9e !important;
      }
    }
  }
  .fileName {
    flex: 6;
    display: flex;
    align-items: center;
    min-width: 0;
    padding-right: 8px;
    .fileIcon {
      width: 21px;
      min-width: 21px;
      height: 24px;
      margin-right: 8px;
    }
    .source {
      color: #757575;
      margin-top: 4px;
    }
  }
  .uploadTime {
    flex: 3;
  }
  .fileSize,
  .creator {
    flex: 2;
  }
  .deleteIcon {
    display: none;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    text-align: center;
    cursor: pointer;
    color: #9e9e9e;
    i {
      line-height: 36px;
    }
    &:hover {
      color: #f44336;
      background: #fff;
    }
  }
`]),Da=(0,J.ZP)(ie.Z)(La),Fa=J.ZP.div(Ba),Cn=J.ZP.div(Qa);function ja(n){var r=n.onClose,c=n.projectId,g=n.knowledgeBaseId,i=n.knowledgeSource,d=(0,e.useState)(""),b=(0,v.Z)(d,2),I=b[0],x=b[1],o=(0,e.useState)([]),a=(0,v.Z)(o,2),w=a[0],p=a[1],h=(0,e.useState)([]),j=(0,v.Z)(h,2),C=j[0],T=j[1],D=(0,e.useState)(!0),R=(0,v.Z)(D,2),k=R[0],s=R[1],S=(0,e.useState)([]),P=(0,v.Z)(S,2),l=P[0],f=P[1],Z=(0,e.useState)([]),y=(0,v.Z)(Z,2),H=y[0],_=y[1];(0,e.useEffect)(function(){le.Z.getListKnowledgeFile({projectId:c,knowledgeBaseId:g}).then(function(m){return m&&T(m)}),le.Z.getListAllowUploadFile({projectId:c,knowledgeBaseId:g}).then(function(m){m&&(s(!1),p(m))})},[]),(0,e.useEffect)(function(){w.length&&_(O().take(w.filter(function(m){return m.fileSize/(1024*1024)<20&&!O().find(C,function(t){return t.fileId===m.fileId})}),20-C.length))},[w,C]);var X=function(t){ie.Z.confirm({title:e.createElement("div",{style:{color:"#f44336"}},_l("\u786E\u8BA4\u5220\u9664\u8BE5\u6587\u4EF6\uFF1F")),buttonType:"danger",okText:_l("\u5220\u9664"),onOk:function(){le.Z.deleteKnowledgeFile({projectId:c,knowledgeFileId:t}).then(function(A){A&&(alert(_l("\u5220\u9664\u6210\u529F")),T(C.filter(function(L){return L.id!==t})))})}})},Q=function(){le.Z.uploadFile({projectId:c,knowledgeBaseId:g,fileIds:H.map(function(t){return t.fileId})}).then(function(t){t.uploadResult?r():alert(t.errMsg,2)})},G=function(t){var E=t==="waitingUpload",A=!!O().includes(l,t),L=E?w.filter(function(N){return!O().find(C,function(te){return te.fileId===N.fileId})&&N.fileName.toLowerCase().indexOf(I.toLowerCase())>-1}):C;if(!(!E&&!C.length))return e.createElement("div",{className:"mBottom24"},e.createElement(Fa,null,e.createElement("div",null,e.createElement("div",{className:"flexRow alignItemsCenter pointer foldableTitle",onClick:function(){return f(A?l.filter(function(te){return te!==t}):l.concat(t))}},e.createElement(U.Z,{icon:A?"arrow-right-border":"arrow-down-border"}),e.createElement("div",{className:"Font15 bold"},E?_l("\u5F85\u4E0A\u4F20"):_l("\u5DF2\u4E0A\u4F20"),!E&&e.createElement("span",{className:"mLeft4"},L.length))),E&&e.createElement("div",{className:"Gray_75 breakAll mRight8"},_l("\u6765\u6E90: ")+i)),E&&e.createElement(Me.Z,{className:"searchInput",placeholder:_l("\u6587\u4EF6\u540D\u79F0"),value:I,onChange:(0,e.useCallback)(O().debounce(function(N){return x(N)},500),[])})),k&&E&&e.createElement(xe.Z,{className:"mTop10"}),!A&&!(k&&E)&&e.createElement(e.Fragment,null,e.createElement(Cn,{className:"isHeader"},E&&e.createElement(Je.Z,{size:"small",className:"mRight16",clearselected:!!H.length&&H.length!==L.length,checked:H.length===L.length&&!!L.length,onClick:function(){_(H.length?[]:O().take(L.filter(function(te){return te.fileSize/(1024*1024)<20}),20-C.length))}}),e.createElement("div",{className:"fileName"},_l("\u6587\u4EF6")),e.createElement("div",{className:"fileSize flexRow alignItemsCenter"},e.createElement("span",null,_l("\u5927\u5C0F")," "),E&&e.createElement(Ie.default,{title:_l("\u5355\u4E2A\u6587\u4EF6\u5927\u5C0F\u4E0D\u5F97\u8D85\u8FC720MB")},e.createElement(U.Z,{icon:"help_center",className:"Gray_9e mLeft4 Font14"}))),e.createElement("div",{className:"uploadTime"},_l("\u4E0A\u4F20\u65F6\u95F4")),e.createElement("div",{className:"creator"},_l("\u4E0A\u4F20\u8005")),!E&&e.createElement("div",{className:"flex"})),L.length?L.map(function(N,te){var z=!!H.filter(function(q){return q.fileId===N.fileId}).length,W=E&&(H.length+C.length===20||N.fileSize/(1024*1024)>=20)&&!z,oe=function(){_(z?H.filter(function(se){return se.fileId!==N.fileId}):H.concat([N]))};return e.createElement(Cn,{key:te,className:ne()({pointer:E&&!W,disabled:W}),onClick:function(){E&&!W&&oe()}},E&&e.createElement(Je.Z,{size:"small",className:"mRight16",disabled:W,checked:z,onClick:oe}),e.createElement("div",{className:"fileName"},e.createElement("span",{className:"fileIcon fileIcon-"+(0,ee.Jw)(N.ext.slice(1))}),e.createElement("div",{className:"overflowHidden"},e.createElement("div",{className:"Font14 overflow_ellipsis",title:N.fileName},N.fileName),e.createElement("div",{className:"source overflow_ellipsis",title:N.source},_l("\u6765\u81EA ")+N.source))),e.createElement("div",{className:"fileSize"},(0,ee.sS)(N.fileSize)),e.createElement("div",{className:"uploadTime"},createTimeSpan(N.createTime)),e.createElement("div",{className:"creator"},N.creatorInfo.fullname),!E&&e.createElement("div",{className:"flex"},e.createElement("div",{className:"deleteIcon",onClick:function(){return X(N.id)}},e.createElement(U.Z,{icon:"delete1",className:"Font16"}))))}):e.createElement("div",{className:"TxtCenter mTop80"},I?_l("\u65E0\u641C\u7D22\u7ED3\u679C"):_l("\u6682\u65E0\u6587\u4EF6"))))};return e.createElement(Da,{visible:!0,width:800,type:"fixed",title:_l("\u4E0A\u4F20\u6587\u4EF6")+(H.length?"\uFF08"+H.length+"/20\uFF09":""),description:_l("\u652F\u6301pdf\u3001docx\u3001txt\u3001md \u7B49\u683C\u5F0F\uFF0C\u4E0D\u652F\u6301\u7684\u4F1A\u88AB\u8FC7\u6EE4"),showCancel:!1,okText:_l("\u4E0A\u4F20")+(H.length?"\uFF08"+H.length+"\uFF09":""),okDisabled:!H.length,onOk:Q,onCancel:r},G("uploaded"),G("waitingUpload"))}var Pa=(0,V.Z)([`
  display: flex;
  align-items: center;
  margin: 0;
  padding: 12px 8px;
  border-bottom: 1px solid #e0e0e0;

  &:hover {
    background: rgba(247, 247, 247, 1);
    .titleText {
      color: #2196f3 !important;
    }
    .uploadBtn {
      background: rgba(247, 247, 247, 1);
    }
    .operateIcon {
      background: rgba(247, 247, 247, 1);
    }
  }
  .titleText {
    font-size: 14px;
    color: #333;
    font-weight: 600;
    cursor: pointer;
    min-width: 0;
  }
  .uploadBtn {
    padding: 4px 12px;
    background: #fff;
    font-size: 12px;
    font-weight: bold;
    color: #2196f3;
    margin-right: 8px;
    border-radius: 20px;
    height: fit-content;
    cursor: pointer;
    min-width: 48px;
    &:hover {
      background: #fff !important;
    }
  }
  .operateIcon {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 32px;
    min-width: 32px;
    height: 32px;
    border-radius: 50%;
    color: #9e9e9e;
    background: #fff;
    cursor: pointer;

    &:hover {
      color: #2196f3;
      background: #fff !important;
    }
  }

  &.isHeader {
    padding: 14px 8px;
    .sortIcon {
      color: #bfbfbf;
      height: 8px;
      &.selected {
        color: #2196f3;
      }
    }
    &:hover {
      background: #fff;
    }
  }

  .name,
  .source {
    margin-right: 6px;
    word-break: break-all;
  }
  .name {
    flex: 6;
  }
  .source {
    flex: 4;
  }
  .fileSize,
  .fileCount,
  .creator,
  .createTime,
  .operateColumn {
    flex: 2;
  }
`],[`
  display: flex;
  align-items: center;
  margin: 0;
  padding: 12px 8px;
  border-bottom: 1px solid #e0e0e0;

  &:hover {
    background: rgba(247, 247, 247, 1);
    .titleText {
      color: #2196f3 !important;
    }
    .uploadBtn {
      background: rgba(247, 247, 247, 1);
    }
    .operateIcon {
      background: rgba(247, 247, 247, 1);
    }
  }
  .titleText {
    font-size: 14px;
    color: #333;
    font-weight: 600;
    cursor: pointer;
    min-width: 0;
  }
  .uploadBtn {
    padding: 4px 12px;
    background: #fff;
    font-size: 12px;
    font-weight: bold;
    color: #2196f3;
    margin-right: 8px;
    border-radius: 20px;
    height: fit-content;
    cursor: pointer;
    min-width: 48px;
    &:hover {
      background: #fff !important;
    }
  }
  .operateIcon {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 32px;
    min-width: 32px;
    height: 32px;
    border-radius: 50%;
    color: #9e9e9e;
    background: #fff;
    cursor: pointer;

    &:hover {
      color: #2196f3;
      background: #fff !important;
    }
  }

  &.isHeader {
    padding: 14px 8px;
    .sortIcon {
      color: #bfbfbf;
      height: 8px;
      &.selected {
        color: #2196f3;
      }
    }
    &:hover {
      background: #fff;
    }
  }

  .name,
  .source {
    margin-right: 6px;
    word-break: break-all;
  }
  .name {
    flex: 6;
  }
  .source {
    flex: 4;
  }
  .fileSize,
  .fileCount,
  .creator,
  .createTime,
  .operateColumn {
    flex: 2;
  }
`]),Ha=(0,V.Z)([`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
  .menuItem {
    padding: 0 20px;
    line-height: 36px;
    cursor: pointer;
    &:hover {
      background-color: #f5f5f5;
    }
    &.isDel {
      color: #f44336;
    }
  }
`],[`
  position: relative !important;
  width: 220px !important;
  padding: 6px 0 !important;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  border-radius: 3px;
  background: #fff;
  .menuItem {
    padding: 0 20px;
    line-height: 36px;
    cursor: pointer;
    &:hover {
      background-color: #f5f5f5;
    }
    &.isDel {
      color: #f44336;
    }
  }
`]),kn=J.ZP.div(Pa),Ra=J.ZP.div(Ha);function Ua(n){var r=n.list,c=r===void 0?[]:r,g=n.loading,i=n.projectId,d=n.sortInfo,b=n.onSort,I=n.onScrollEnd,x=n.onEdit,o=n.onDelete,a=(0,e.useState)(null),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)(null),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=function(s){var S=s.key,P=s.text,l=s.sortKey;return e.createElement("div",{className:"flexRow pointer "+S,onClick:function(){var Z=d.sort!==l||d.sort===l&&d.isAsc?l:0,y=d.sort!==l?!0:!d.isAsc;b({sort:Z,isAsc:y})}},e.createElement("span",null,P),e.createElement("div",{className:"flexColumn mLeft6"},e.createElement(U.Z,{icon:"arrow-up",className:ne()("sortIcon",{selected:d.sort===l&&d.isAsc})}),e.createElement(U.Z,{icon:"arrow-down",className:ne()("sortIcon",{selected:d.sort===l&&!d.isAsc})})))};return e.createElement("div",{className:"flex flexColumn mTop12"},e.createElement(kn,{className:"isHeader"},e.createElement("div",{className:"name"},_l("\u540D\u79F0")),e.createElement("div",{className:"source"},_l("\u6765\u6E90")),R({text:_l("\u5927\u5C0F"),key:"fileSize",sortKey:1}),R({text:_l("\u6587\u4EF6\u6570\u91CF"),key:"fileCount",sortKey:2}),e.createElement("div",{className:"creator"},_l("\u64CD\u4F5C\u8005")),e.createElement("div",{className:"createTime"},_l("\u521B\u5EFA\u65F6\u95F4")),e.createElement("div",{className:"operateColumn"})),e.createElement(Be.Z,{className:"flex",onScrollEnd:I},c.map(function(k,s){return e.createElement(kn,{key:s},e.createElement("div",{className:"name titleText",onClick:function(){return x(k)}},k.name),e.createElement("div",{className:"source"},[k.appName,k.worksheetName,k.controlName].join(" / ")),e.createElement("div",{className:"fileSize"},(0,ee.sS)(k.fileSize)),e.createElement("div",{className:"fileCount"},k.fileCount),e.createElement("div",{className:"creator"},k.creatorInfo.fullname),e.createElement("div",{className:"createTime"},createTimeSpan(k.createTime)),e.createElement("div",{className:"operateColumn flexRow alignItemsCenter justifyContentRight"},e.createElement("div",{className:"uploadBtn",onClick:function(){return D(k)}},_l("\u4E0A\u4F20")),e.createElement(Pe.Z,{action:["click"],getPopupContainer:function(){return document.body},popupVisible:p===k.id,onPopupVisibleChange:function(P){return h(P?k.id:null)},popupAlign:{points:["tr","bl"],offset:[25,5],overflow:{adjustX:!0,adjustY:!0}},popup:e.createElement(Ra,null,e.createElement("div",{className:"menuItem",onClick:function(){h(null),x(k)}},_l("\u7F16\u8F91")),e.createElement("div",{className:"menuItem isDel",onClick:function(){h(null),ie.Z.confirm({title:e.createElement("div",{style:{color:"#f44336"}},_l("\u5220\u9664\u77E5\u8BC6\u201C"+k.name+"\u201D")),buttonType:"danger",description:_l("\u5220\u9664\u540E\uFF0C\u6240\u6709\u52A9\u624B\u4E2D\u7684\u5F15\u7528\u5C06\u5931\u6548\u3002"),okText:_l("\u5220\u9664"),onOk:function(){return o(k.id)}})}},_l("\u5220\u9664")))},e.createElement("div",{className:"operateIcon",onClick:function(P){return P.stopPropagation()}},e.createElement(U.Z,{icon:"moreop",className:"Font18"})))))}),g&&e.createElement(xe.Z,{className:"mTop10"})),T&&e.createElement(ja,{projectId:i,knowledgeBaseId:T.id,knowledgeSource:[T.appName,T.worksheetName,T.controlName].join(" / "),onClose:function(){return D(null)}}))}var Oa=u(45231),Ma=u(5420),Ga=u(68111),za=u(57296),Wa=(0,V.Z)([`
  margin-bottom: 24px;
  .labelText {
    font-size: 14px;
    margin-bottom: 8px;
  }
  .filterBtn {
    width: 36px;
    height: 36px;
    text-align: center;
    margin-left: 10px;
    border-radius: 3px;
    border: 1px solid #dddddd;
    color: #989898;
    cursor: pointer;
    i {
      font-size: 20px;
      line-height: 34px;
    }
    &:hover {
      color: #2196f3;
    }
    &.isActive {
      color: #2196f3;
    }
  }
`],[`
  margin-bottom: 24px;
  .labelText {
    font-size: 14px;
    margin-bottom: 8px;
  }
  .filterBtn {
    width: 36px;
    height: 36px;
    text-align: center;
    margin-left: 10px;
    border-radius: 3px;
    border: 1px solid #dddddd;
    color: #989898;
    cursor: pointer;
    i {
      font-size: 20px;
      line-height: 34px;
    }
    &:hover {
      color: #2196f3;
    }
    &.isActive {
      color: #2196f3;
    }
  }
`]),Ue=J.ZP.div(Wa);function Ya(n){var r=this,c=n.projectId,g=n.onClose,i=n.editRecord,d=n.onRefreshList,b=n.onUpdateSuccess,I=(0,pe.Z)(i||{attachmentIds:[]}),x=(0,v.Z)(I,2),o=x[0],a=x[1],w=(0,e.useState)(!!i),p=(0,v.Z)(w,2),h=p[0],j=p[1],C=(0,e.useState)(null),T=(0,v.Z)(C,2),D=T[0],R=T[1],k=(0,pe.Z)({}),s=(0,v.Z)(k,2),S=s[0],P=s[1],l=(0,pe.Z)({}),f=(0,v.Z)(l,2),Z=f[0],y=f[1],H=(0,pe.Z)({}),_=(0,v.Z)(H,2),X=_[0],Q=_[1],G=(0,e.useState)(!1),m=(0,v.Z)(G,2),t=m[0],E=m[1];(0,e.useEffect)(function(){i?A():L()},[]);var A=function(){var z=(0,Ke.Z)(De().mark(function W(){return De().wrap(function(q){for(;;)switch(q.prev=q.next){case 0:return q.next=2,le.Z.getKnowledgeBase({projectId:c,knowledgeBaseId:i.id}).then(function(se){se&&a({filters:safeParse(se.filter)})});case 2:N(i.worksheetId,!0);case 3:case"end":return q.stop()}},W,r)}));return function(){return z.apply(this,arguments)}}(),L=function(){un.Z.getAppForManager({projectId:c,type:0}).then(function(W){if(W){var oe={},q=W.map(function(se){var Ze=se.workSheetInfo.map(function(Ce){return{text:Ce.workSheetName,value:Ce.workSheetId}});return oe[se.appId]=Ze,{text:se.appName,value:se.appId}});R(q),P(oe)}})},N=function(W,oe){Oa.Z.getWorksheetInfo({worksheetId:W,getTemplate:!0,getViews:!0}).then(function(q){if(q){var se=(q.views||[]).map(function(Ce){return{text:Ce.name,value:Ce.viewId}}),Ze=O().get(q,"template.controls");y((0,ve.default)({},W,se)),Q((0,ve.default)({},W,Ze)),oe&&a({appId:q.appId,appName:i.appName,worksheetId:W,worksheetName:q.name}),h&&j(!1)}})},te=function(){var W=(0,Y.default)({id:(i||{}).id,projectId:c},O().omit(o,["filters","appName","worksheetName"]),{filter:Ye()((o.filters||[]).map(He.gC))});le.Z.upsertKnowledgeBase(W).then(function(oe){oe&&(alert(i?_l("\u4FEE\u6539\u6210\u529F"):_l("\u6DFB\u52A0\u6210\u529F")),i?b(i.id,(0,Y.default)({},i,W)):d(),g())})};return e.createElement(ie.Z,{visible:!0,title:i?_l("\u7F16\u8F91\u77E5\u8BC6"):_l("\u6DFB\u52A0\u77E5\u8BC6"),okDisabled:!(o.name&&o.appId&&o.worksheetId&&o.viewId&&!O().isEmpty(o.attachmentIds)),onOk:te,onCancel:g},h?e.createElement(xe.Z,{className:"mTop10"}):e.createElement("div",{className:"mTop12"},e.createElement(Ue,null,e.createElement("div",{className:"labelText"},_l("\u540D\u79F0")),e.createElement(Ne.Z,{className:"w100",value:o.name,onChange:function(W){return a({name:W})}})),e.createElement(Ue,null,e.createElement("div",{className:"labelText"},_l("\u5E94\u7528")),e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,className:"w100",placeholder:_l("\u8BF7\u9009\u62E9\u5E94\u7528"),renderTitle:!D&&o.appId?function(){return o.appName}:void 0,itemLoading:!D,onVisibleChange:function(W){return W&&!D&&L()},value:o.appId,data:D||[],onChange:function(W){return a({appId:W,worksheetId:null,viewId:null,attachmentIds:[],filters:[]})}})),e.createElement(Ue,null,e.createElement("div",{className:"labelText"},_l("\u5DE5\u4F5C\u8868")),e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,className:"w100",placeholder:_l("\u8BF7\u9009\u62E9\u5DE5\u4F5C\u8868"),disabled:!o.appId,renderTitle:!S[o.appId]&&o.worksheetId?function(){return o.worksheetName}:void 0,itemLoading:!S[o.appId],onVisibleChange:function(W){return W&&!D&&L()},value:o.worksheetId,data:S[o.appId]||[],onChange:function(W){a({worksheetId:W,viewId:null,attachmentIds:[],filters:[]}),N(W)}})),e.createElement(Ue,null,e.createElement("div",{className:"labelText"},_l("\u89C6\u56FE")),e.createElement("div",{className:"flexRow"},e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,className:"w100",placeholder:_l("\u8BF7\u9009\u62E9\u89C6\u56FE"),disabled:!o.worksheetId,itemLoading:!Z[o.worksheetId],value:o.viewId,data:Z[o.worksheetId]||[],onChange:function(W){return a({viewId:W})}}),e.createElement(Ie.default,{title:_l("\u8FC7\u6EE4\u9009\u62E9\u8303\u56F4")},e.createElement("div",{className:ne()("filterBtn",{isActive:o.filters&&!!o.filters.length}),onClick:function(){if(!o.filters||!o.filters.length){if(!o.worksheetId){alert(_l("\u8BF7\u5148\u9009\u62E9\u5DE5\u4F5C\u8868"),3);return}E(!0)}else a({filters:[]})}},e.createElement(U.Z,{icon:"filter"})))),t&&e.createElement(Ga.Z,{allowEmpty:!0,showCustom:!0,supportGroup:!0,hideSupport:!0,title:"\u7B5B\u9009",filters:o.filters||[],relationControls:X[o.worksheetId]||[],globalSheetInfo:{projectId:c,appId:o.appId},onChange:function(W){var oe=W.filters;a({filters:oe}),E(!1)},onClose:function(){return E(!1)}}),!O().isEmpty(o.filters)&&e.createElement(za.Z,{loading:!1,filterItemTexts:(0,Ma.cm)(X[o.worksheetId]||[],o.filters||[]),editFn:function(){return E(!0)}})),e.createElement(Ue,null,e.createElement("div",{className:"labelText"},_l("\u9644\u4EF6\u5B57\u6BB5")),e.createElement(Te.Z,{border:!0,isAppendToBody:!0,openSearch:!0,className:"w100",placeholder:_l("\u8BF7\u9009\u62E9\u9644\u4EF6\u5B57\u6BB5"),disabled:!o.worksheetId,itemLoading:!X[o.worksheetId],value:o.attachmentIds[0],data:(X[o.worksheetId]||[]).filter(function(z){return z.type===14}).map(function(z){return{text:z.controlName,value:z.controlId}}),onChange:function(W){return a({attachmentIds:[W]})}}))))}var Va=(0,V.Z)([`
  background: #fff;
  min-height: 100%;
  padding: 32px;
`],[`
  background: #fff;
  min-height: 100%;
  padding: 32px;
`]),Ja=J.ZP.div(Va);function Xa(n){var r=n.currentProjectId,c=(0,pe.Z)({keywords:"",pageIndex:1,loading:!0,noMore:!1,sortInfo:{sort:0,isAsc:!1}}),g=(0,v.Z)(c,2),i=g[0],d=g[1],b=(0,e.useState)([]),I=(0,v.Z)(b,2),x=I[0],o=I[1],a=(0,e.useState)({}),w=(0,v.Z)(a,2),p=w[0],h=w[1],j=(0,e.useState)({visible:!1,editRecord:null}),C=(0,v.Z)(j,2),T=C[0],D=C[1],R=(0,ee.XH)(r,ke.UU.assistant);(0,e.useEffect)(function(){le.Z.getKnowledgeFileTotalSize({projectId:r}).then(function(l){l&&h(l)})},[]),(0,e.useEffect)(function(){return k()},[i.loading,i.pageIndex,i.keywords]);var k=function(){i.loading&&le.Z.getListKnowledgeBase((0,Y.default)({projectId:r,pageIndex:i.pageIndex,pageSize:50,keywords:i.keywords},i.sortInfo)).then(function(f){f&&(o(i.pageIndex>1?x.concat(f.list):f.list),d({loading:!1,noMore:f.list.length<50}))}).catch(function(f){d({loading:!1})})},s=function(){var f=p.knowledgeBaseLimitFileSize<=0;f?ie.Z.confirm({buttonType:"danger",title:_l("\u5BB9\u91CF\u4E0D\u8DB3"),description:_l("\u8D85\u8FC7\u77E5\u8BC6\u5E93\u53EF\u7528\u5BB9\u91CF"),removeCancelBtn:!0}):D({visible:!0})},S=(0,e.useCallback)(O().debounce(function(l){return d({keywords:l,loading:!0,pageIndex:1})},500),[]),P=function(f){le.Z.deleteKnowledgeBase({projectId:r,knowledgeBaseId:f}).then(function(Z){Z&&(alert(_l("\u5220\u9664\u6210\u529F")),o(x.filter(function(y){return y.id!==f})))})};return R==="2"?(0,ee.j0)(r,ke.UU.assistant,{dialogType:"content"}):e.createElement(Ja,{className:"flexColumn h100"},e.createElement(hn,{title:_l("\u77E5\u8BC6\u5E93"),description:_l("\u4ECE\u5DE5\u4F5C\u8868\u4E2D\u83B7\u53D6\u6587\u4EF6\u6765\u751F\u6210\u95EE\u7B54\u77E5\u8BC6\uFF0C\u901A\u8FC7\u52A9\u624B\u7684\u642D\u5EFA\u5B9E\u73B0\u57FA\u4E8E\u77E5\u8BC6\u7684\u95EE\u7B54\u670D\u52A1\u3002"),limitInfo:"("+(0,ee.sS)(p.knowledgeBaseTotalFileSize)+" / "+(0,ee.sS)(p.knowledgeBaseTotalLimitFileSize)+")",showSearch:!!x.length||i.keywords,keywords:i.keywords,onSearch:S,onAdd:s,addText:_l("\u77E5\u8BC6")}),!x.length&&(i.loading?e.createElement(xe.Z,{className:"mTop10"}):e.createElement(In,{icon:"import_contacts",emptyText:i.keywords?_l("\u6682\u65E0\u641C\u7D22\u7ED3\u679C"):_l("\u6682\u65E0\u6570\u636E\uFF0C\u8BF7\u5148\u6DFB\u52A0\u77E5\u8BC6"),showAddIcon:!i.keywords,onAdd:s,addText:_l("\u77E5\u8BC6")})),!!x.length&&e.createElement(Ua,{projectId:r,list:x,loading:i.loading,sortInfo:i.sortInfo,onSort:function(f){return d({loading:!0,pageIndex:1,sortInfo:f})},onScrollEnd:function(){!i.noMore&&!i.loading&&d({loading:!0,pageIndex:i.pageIndex+1})},onEdit:function(f){return D({visible:!0,editRecord:f})},onDelete:P}),T.visible&&e.createElement(Ya,{projectId:r,editRecord:T.editRecord,onClose:function(){return D({visible:!1})},onRefreshList:function(){return d({loading:!0,pageIndex:1})},onUpdateSuccess:function(f,Z){return o(x.map(function(y){return y.id===f?(0,Y.default)({},y,Z):y}))}}))}var Ka,yn,wn,_a=(yn=Ka=function(n){(0,an.default)(r,n);function r(c){(0,en.default)(this,r);var g=(0,tn.default)(this,(r.__proto__||$e()(r)).call(this,c));wn.call(g);var i=g.getProjectInfo(),d=i.projectId,b=d===void 0?"":d,I=i.isSuperAdmin,x=I===void 0?!1:I,o=i.isProjectAppManager,a=o===void 0?!1:o,w=i.companyName;return g.state={showCreateCustomBtn:!1,isAdmin:x||a,currentProjectId:b,currentProjectName:w},g}return(0,nn.default)(r,[{key:"componentDidMount",value:function(){$("html").addClass("plugin"),ee.uY.addListener("CHANGE_CURRENT_PROJECT",this.reload)}},{key:"componentWillUnmount",value:function(){$("html").removeClass("plugin"),ee.uY.removeListener("CHANGE_CURRENT_PROJECT",this.reload)}},{key:"render",value:function(){var g=this.props.match,i=g===void 0?{params:{}}:g,d=i.params.type,b=d===void 0?"":d,I=this.state,x=I.isAdmin,o=I.currentProjectId,a=I.currentProjectName,w=(0,Y.default)({},this.props,{currentProjectId:o,currentProjectName:a,isAdmin:x}),p=(0,ee.XH)(o,ke.UU.assistant),h=O().get(O().find(md.global.Account.projects,function(j){return j.projectId===o}),"allowPlugin");return h?(!x||!p||p==="2")&&["assistant","knowledgeBase"].includes(b)?((0,vn.T8)("/plugin/view"),""):e.createElement("div",{className:"flexRow h100"},e.createElement(Zn(),{title:_l("\u63D2\u4EF6\u4E2D\u5FC3")}),e.createElement(Rn,w),e.createElement("div",{className:"flex"},e.createElement(On.Z,null,e.createElement(Un.Z,null,e.createElement(Oe.Z,{path:"/plugin/view",component:function(){return e.createElement(gn,w)}}),e.createElement(Oe.Z,{path:"/plugin/assistant",component:function(){return e.createElement(Ta,w)}}),e.createElement(Oe.Z,{path:"/plugin/knowledgeBase",component:function(){return e.createElement(Xa,w)}}),e.createElement(Oe.Z,{path:"*",component:function(){return e.createElement(gn,w)},exact:!0}))))):(0,ee.Yg)({dialogType:"content",removeFooter:!0,hint:_l("\u672A\u542F\u7528\u63D2\u4EF6\u4E2D\u5FC3"),explainText:"",projectId:o})}}]),r}(e.Component),wn=function(){var r=this;this.getProjectInfo=function(){var c=O().isEmpty((0,ee.vo)(localStorage.getItem("currentProjectId")))?O().get(md,"global.Account.projects.0"):(0,ee.vo)(localStorage.getItem("currentProjectId"));return c||{}},this.reload=function(){var c=r.getProjectInfo(),g=c.projectId,i=g===void 0?"":g,d=c.isSuperAdmin,b=d===void 0?!1:d,I=c.isProjectAppManager,x=I===void 0?!1:I,o=c.companyName;r.setState({isAdmin:b||x,currentProjectId:i,currentProjectName:o})}},yn)},15682:_e=>{_e.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAIcCAMAAAA5YTo4AAAC7lBMVEUAAAAVfckae8wNUZQjidkYeMEcid0fj+ofhtohb7kWZLAbfMYabq0ebaMiiuErl/Qbjubn8fnK3/T7/P2z2Pr8/f/E4fQAO779/v/o8/3U5fiSvuXY5/nr9f3y+v/z+v/y+f9kodH/1wHe7//+///w+P/g8fqo0PICKlL+2AHs9v3r9f0ACRAGBAMEGC/WxRz////y0wrb7P3pzxH/2QHw9/8AAAEAAwYAAAHa7frW5/cDZMgAAgSstz/w+P/t9v3/2QH92ALg7vr31QfM4vfy+v/+2ADq0A/y+f//2AACBwzizBazuaMFTsAKIlAAS77e7P0ATcDu+P4ATb/B2vD92AH92AH81wIDHDe5ujD/5p8BTMABS7sKIU4AS73Y6fvW6Pvz1AjX6foJULgHJ1jcwqD2xJvywZv81wL61wT/5ZzY6fvu05r5xJsATMDf7/sATL7b6/zR5vv1pmEBRrP4xJv3+/741gXvypvnvqAEtv4AAALwwJgATL741gQGq/T5xJsJJFT41QUKIEzR5fjlzZoMI0/4xJkFTsD85J7Tx6P115cAt//95Z8Csvv/2CD3unxVRDK+0fELJFEDsPkAt/8Ns/nL5fvV5vj645n2wpwAtv3/3zpkeJk5tOf+/v8As/371gM9UnfTrH/545/4xZkIHko9a9EAsP8Btv4AgLIAs/7wohsDrfeafFwAqf4At/+XqsM5UXX/////2QAAO8AAAAAATsDz+v8AuP/Y6Pn6xJz/5p/a6fnf7/8KIk7G4f0Aq//6yJbU5ff3+v40Zc0bT8ZAbNAJpPAAPKoVVpNJddTo8/4DrPgRSMSIpOKovOrznFUDGCn/5IMOU570v4tzlN0JUao2LB/M2PNfg9iaflz2sHCXusIFNH+7m2+vrDK7wrIAO1J7ZEnUwBsAisAAVndOdm/mfi32tBMApeUAl9Khs8wAZo//4VP4t1OKl0rtjiZ2RRvcxZ0AbZgyZ4CzYiNnhF/jnBf6xEbAjc0tAAAAs3RSTlMADgwFDQsPEA4GCQkIBQ4REkhFjEi6MLDDaIMXwZPs1vwQ+e7by1kfFfGhd0nyMxrlRMst5rPJgN9FPyGaC8GF3LleWjbzxjre0WMiFsfAkP7vo34mrJ+TIxPxuTbd2bGSUHJZRy6rj4Z91qJE96pPR95n/vvepmJXTuqzdWtqLuudcGJQN/DPnp4jY9S7YP79/feARMB5V/GGvKL9/PvgiHX9+3HBUOSol/yzs6DSuLWllCsEFvkAAEZqSURBVHja7Nq9bYRAEIDRFRLBGuiDABxyBFRABe7FfU19tnWygdv7kUOf3+vh0+5oJgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPBX9OuyrAm44m2KL/NrAi71U5yNCoHCEt/GlwQc9LE5JeBgjZ0EHJxip0/AzUCGBNwMxDIEjgaBwB1jbGxCYG9YptjMCfixjhFmdLh3Y7JZElD28XhE77p81nVdgn9gisJQhpHbpq6uaZqctcLTGqI0X6Tx2UFdPdC0OcHTeY9N8cnKTfUbdest4YO9u1ltIoriAN4Zc7XJtNJXcOfCuqyB6gtIH6B7absxKym0NZBuJKAhKKRdKJSCCH7gx+rCMAvJrNxk0UJBUBErulBc6QM4k9vpneTc+bgJTmbk/7sMseD2z5kzZ07yn5nnnvcPFG162WLM9I8ZXDFK4jJM00Ilgf8I9zxwj+Z52MLUrJ+OERiGYRoMGYH/RdXPh+t+HgwI6zPDJ5moIf4pGebMFMB/4Arnj13PB1VA9Bl+DRGXaaEjgcJb9guITMjXo34PwgRT1o60fYioH+LCvRYU3/VXrvDY79Rdl3uuBwHR59eO0GVaUwCF9sQNHH0QAZmv1ZeYQHqQZIY4peCgjEChrbrSA9e/xfrgutv1CyOWENmDyE9EBIqr7oZ95vy96wkistjpNOY0ZyFBDyIPIgKFteKGPX7wIfjn+gZrt+y+1s5uQ6+GyKvkX6giUFhNd8j9W+Lzy5Yd0nrWMZMN1hBUESi+DXfIRxGQT/awrf2G3ixEXEFWGAYjUESr7oCjg49BPqhHjaQehNYQefDQFwroWtMNu3Vw5N9f2QSNiBrtQcTlH9xnQfHcbQ7kw7/D+m0TJCKRdYTUj+CgW4cCmmFmveYK67cODu57n3u2oBsR+hzLP4ZMSKnEpgAKZJZ5luqrT56s1lfYyq2DkxusbrdrR9rpJM9CaB3BfRYUDxuyVvMLSPeEHeXpou4sxPDrR/9CEYHCqLBhK80vfv1IishWO3EWEn1QRKAYyowyd+xuSPR9ViPlLGQoLyV0IlAQs0xlqzvAjvRsLsVeiH/QiUAhWYwyG3aXJETzPssw1H1ISfQhKCJQCGWm0u7SgOjeZ5H7KsUxpwByjSntd4fFT0UWE/dCaFb60KtDrpWZ0ouuXkK2ds/FzUKiTwlvZ0GeMbVWQkCoVjvtLET2IWhEIOfKTG1LLyC0FSE1JOagEYG8YmrTXcqm6CPfdHsh4vjQiECelZlaRzMgshUxRO3Q7EMMNCKQRxZT29UMiNTqmCGxPYi40IhAbs2yCE+7VM9O50XjtAcpDdYPTESgWCyWvkfv9ey09udS7oUMwr465AyL0OhS797ZqW21Sxo9iEgL3u+FvCmzCO1RA0Jbkbj3scQVwMwQcqai0YL0SEASPPVbEdGFpOpBkBDImcgWfbGnKiDverae/TnVXoh6FoKHWZA7ZRZhX1FAdAMiX4RP3AuRd1yYqkOOWCzCa0UBEQHRtdNJtxciISGQFxZLPSbsaQdEvghP923VJ2BMAeRAOSogd7c/kQIiA6Jra38uYS8EAxHII8uKSEjTcT71aD5kQPRbkdQ9CBICeREVkDXH83uvK/V0A0JfhI95Jws1BHKpYlUsRm06QqiIvBNsQqcVSTMLQUIgN8qWR9WAOCdqn/aCfAj2OFqLoRpCUoEaAnljVbyAVFQNiPTFj8jeHrnD0vainXoW4juPHSqYNKuPDVl1BFlGvvgfm4vtly/fjNqk7y+m3QuR8K1yMFGzXgWhXUjdUVpjfYu7rRHisTuntRdyGhAkBCaobAksbKXmqDxkpzot7Xjo7oXIhKAPgYmpWOKEE7K07qisLzHp7DOdx7vt83q76eE+xDDQqcPEWIGhBoSqrbABu3ZKz2+YUuJeCIWEwORUrOAMTgipTTbkkZ3Gt0M+v2wKunshwrSXkCmASThjkRKyEdWgE60U1eMt9yyYUuJeCOX9R7y5CBNRlhWkktCgUw07Xu/PIReuk9+91elDjGkDX3YCEzFjSWkadJ025A8/VdX7vRBaQpAQmAirEjrM8zCmQadasb1HyCXzlMZeiAzItDGNhED2rLDgARa1wdQ6doSfx3zAFd3fC6ElBD+IC5mbPa0eln+xtfgGndqJjYd02/SMMwsxppEQyNysSEZg04ls0DVKyI9jTlT1fy+ElhB8tTVkbGagB7lZi2/QqeWrP+1hv7iKaY45C+kfJAQyZQmx9WN7hUW5Ms+PaW+udDH+90LCR8lADYHshevHnVrsBJ26VOWenh3S+84jGKIH0Z+F+M6LWQhqCGSs33+Ia2XbUaoztcu3ed8fUj5U5s0Bo+yF9OHld8gCrSB31x2lVaZ08Qo/cWif+s4jLZhSacS9kGlx8OIiZKV8+gxLDNCp5oWYuyvhhy38OOTRrprSyHshPry4CJmRb2ItNR2pFnqAdZepXOUhv+y+b5wgk/SxZyH+QUIgKzMn/ceFcD62kx5gLS/wsLfk4S5VZaYw1l6ID69lQXaCDuShI4WyUrvDFC7N80E9dftB3zQZdxYS1BA87IVsnDzDWnWktZrMx03l7IMPe07qR+QUZOy9EIxDICOygqyFasZGM34AcvE2J77bP7mU2KKTWUhJZy9E1BA87IUs9OtHOB+boT821O0HdWwf83jLJmWMuBfSzwi+6QQycEbUD2lzM/4N3uUqVzj8wTU6kLH3QsTBDi5oGP0p72o4H0vbsQPCy/NcKaFDr5rEGHshGIdAVmaG8hH6q8moi1Wuhc5Axp+FoIZAdgafX92r3It9w91Y4BpIh05F9CBGmlkIvscB/r1K3ZHWKqHvM7kTNT7XV71oKpTG2gvBdghkwVp3pAsX1mMb9Mt8zBssyhhxL0SYxjgE/rJ3Lq1RQ1Ecn6RJ87gm069gV1NoK6Uy04UFS6FiBXe1deGiUF/gVlQq4gMV3Lpz50I/QXDjYr6Dn8hkbuNJ5tw8bk5eU+/veBHabQ///O85/6RZHiYXTBKPW8+Zidmp8QGLngvh5atxiKI5vJep3EfCrTPcIev0ByyMViUXAthqHKJoEIc3COKbK/ji1Hml/tjY1BE4F1JcBsqFqM1eRdM4GSH0x6JPTv2qxKGej1YpFwLY6ipL0RhXPoob5Ifgu7ebNRkQPAsxSLMQW70sS9EU7tXfYq6ykBosyFjTi8jfxyqehajdd0VjMDcjZ/sq2tGiK8jGiZ4PdRaiNnsVTeKyR1kmBEnIKKMHJCcgGI2SC+Edoq6yFE3gMTfDpX+eJXGLxyDnh7k7vKaOqDMXorayFBLQdnl/vHr7G3jOZhQECceb8EMB53oG9FwI6MfFUZe9CqDW9/I+e/zt0eOXX9JPW8+j3xQ+Y01G5o7khLCeXIifnoWob4coGsF1WaJepjwIp2BXcWciPyEszoXg5y2MluAy7i16DmNMNwx/oOgOlyXr6tvUJJ2x8EilQbBBN/kBas6FQPmXpkMc07eGK/9qoOgMUBDeDa/jrcXXLoupPAqZ6EATsxAtBvz64l/2Ooa18o/h7AwU3eGydL1+G3bHo9fJn1UNhNzQTYF+1J8LgfIX/Z29zPqnG0pBeoHD5juEPXzI5jBTjMtO0HUJ5HMheKd30fcWmb8iRClIhzguKyjUICcbJSfopqkjDWk0FxKdhe0QZvHnqahWlIL0BTfyIG7cCekDSGxkyUzQ6bkQLa0hi7u3aAyHwxUByoN0DHPLlExsCiboUEBTuRAofwH3FvWVYUSkFsqD9AvcDVg/cC7ksNiACLui/lyIlmBR9xbZ8IIV5UH6hsfcUmVKdsjOKPIfZqwf8Wk0FwI+ZLH2Fv3hStQcvEPCf0pBauLa1tYdukd3XZbpQwDZDlmPmgNodxZiL9LeIhsmUApSH7v3gpB718ibWFIuBChY4Y3AHqTZXAiUvzAdYlhDi+tHhPIgtXH/IJhxfZs8R3fFPiSF3AtOzi/6AyGfC5GZhSzg3qI1TKMUpCau3QwuuH6nXo+e1S1535jCBuQCPaEfteVCDDgwC0E+ZBEuex1rph9cQ/hRc5BauBP2R8xNwlPWEviPQh9S/jXvm9AfsiAPIpkLAR+yAHuLTtgZ86g5SC39cT1IcPN+c3N0KGaW7pDDfw0i60MMei4ENOTKoN9E/cErUokLlAepge21IMXt3epjQtCO+UKIOkS8/L4uISFSuRCjVC6El93zzV5nKER5EDK31oI5DnabnKNDLgQzGmetYXF0iX2sOnMh/PR5HJLUD/AhIWoOQmRrNQBoHeIh/5G3kyXukIw5OqfTWUivxyFO3BUIpSA0TlcDAXvNTUGgChsEuGFywIPI3GPRcyHR6fNmL9cP0JCED1EehMSLQMxRtSkIR34WAmSN0pGEtJsL4dXXF53E/SFEKQiBN0EW95qZgkBJNQjYEHkfolXIhYg9SF/fau1h/UjN0yEXohREjidBNseVFrEK5iDFEpI1LRwjCWkzFwI+pI8DQyvWj+hglIJU5V6Qx9Mqd1hkF7JTah9LfhZCz4VE1ct0SNgfuFZgp1d5kIocBfm8kbcggHwuBBokb6DeZi4EexBb699I3bdCoDMEKAWpwu5eUMS+7B2WdJmIcU5mKqJKLgQ8CH0W0rsvIxhC/UjvY81yIUpBpNg9CBC0DmGxdkj4EFPmo2yTPsxCbK1fI3V2oR+5PkQpiDT3bwdlOJW7w5Ivqe+mb6JZSFnqyoXw6lEG17GG4krlQpQHqbbeXszqlsQTFpcQuVmIVIOMR53nQjQ7oj+vk7NioCtEKAWRXm8vyeqt0lrPUE9UyYVMcqPpm1K5EMo+ljgXwk9/EoZ2rn6AD1FzECm2rwelWdtOKc/+k+Ojvb17T77vz3WOw0KQB0EdAadSOH3jxofuciG2nTiDPmCCflycYYYPUQoivb4r3yFbx7dTvzh6gRyIfLHC5G364nc6/dlxLkTz+6IhDu8NXDgXojyI1PquFDyEu318XdA8x3eSAgIuRCIXUvhl6FHSlvyZTqdfO82FcPqwluVZAHRFBkpBynIaSMFDuNcyh+7HPKELT1Go5HIhJ6hBUr5kGnH3pNtcCK/OOwSerVChXIiag5RlP5Dn5ve1HBv/ZDcWEJAQmVxIwbbiBk8agoCEfBrpQBezkD5oiJ/Uj+JZiFIQwno7jZvb4EDos5Ad1CAh2g3oj4izVnIhWR6kFxrC4t5AJc6FKA9ShqdBE6ydshj6LGQ879HNGYcbf3h78AbRgbZyIXavfIhjAeV8iFKQYo6DhjhFHqRyLuRcvII1TfKgpVwI9iBwfLtTDVkWPFtZebkQNQchrLfT2UcSIpELwaN0/FrFB9MEH2qdhRgVciEhfng66RDoDwB7EIxSEMJ6O5XVLYKGuGhSiOPod+cEBDxIk7kQTZgL6d6H+Im+gCrIhSgPQlhvJ7O2DRIinQsxAX29uEHOepEL4fhd7GUZFiDhQ5SCENbbydx2qbMQ8aRwghrkbou5EFsr9CFa6x1iCp+tyuZClIIQ1tspPGUcYi5k9CvNIWqQM7TT28UsBHxI2/kQZgFyPkQpCGG9nczqnXpmIRvCF/7cTQpIw7kQA81C8n1IuylcR/hcVSoXojxI9tupW+CIOAsRD0JO4BYLBAQkpLtcCNBSh+D+kJ6FKAUhrLfTucX/+im5EDwI0bgzEQhIYg7SYC5EE+dCoOzo6IOW8MTPVcW5EHWLlff29nY44rpAzIVMRIP0u0hAQEK6y4XY4EOMQSt4lpDSuRClIIT1djoEFwIdcogH6SPkQOS/F2JUzYVgD4I1JCpv0DyOJaR8LkQpSAf9AbxnjJ4LWUdjkLMHUywgICGd5kJARwhf2CH2h0wuRCnIHPurQXvs4T6Qn4WczI9B3k2Bd2aKCrkQ2izEhwP6ER9z0CzMQsjOQtQcBK23t8nqbh25kI30GOTDFPhqxvRtFjI7hjdoENMSI5cLUQpCWm+n32NVL+E976b5FfzHmTlPL3IhNlSDM0PdAqQ9CPgQ5UHQenuLvCfmQvA978gcveMbil83TaCmWYheSy4EdKTBiYhvASQfohQErbe3x3EduZAJuuU9OxuZmXDl6DQXwk+Tt1nessVBe+4yuZBLrCBLXljOkoO5cnEcb2lpaeB5tPV2+jCdngs5RGkQRP2zEKNULsQW50LgRAUi0oI9l8+FXKrvpPOu4J3BD+qPzNoL2mePufRcyDpads+i4VwIUJwLsRNVt1d3/GUrLoR8LuRSKMiSBx2BEPUI/M/P/YOgAw5cxsi5kBO0y1skIb3IhcQHnEjj7lzeh1yGBgHVgHJkNeTa7aALblM8SHjQPe+mmUMvciEwC0mVM6gJtoycB2kWstgNEvqIgo7A/SE6sN7eLgegCYRcyDi5qtiAhGhNzUJAQ3zfcOp6ukLI+ZBLoyDch6NCOlJCQQjr7VST7tJq7r0NO2YOvcqFYA2x6S3i2BbXD6jqsxBroT1I1B24Q3LAHQL6AevtbXMMekCYhUyQR69bQmrKhdiiWQiUrXt0bx7y33sQ3huoQ8r5EKwht9aCrvgOf/2EXMh6KpCeRae5EJ+ffA3RlrXKKuKYsWLEB81B5HMhC+lBvMh38N5Ymh2H6EO21oLOOAVfQcmFjCFvm013uRDsQTJ8iLYc/r5Ci3jM530Bh+RBrMVVEFAOUJDcAjIU5HQ16I77VA/CO+RcokG4B+lRLiRRy9qsmCf1J2FGziNd4EMQMj5k4TwI9EV2h5QgOQfZDzrkALSAlAuZSDaIPFlzEHouJFV2qCGzMp2S0mEsL0Nf/OcexCvqD6jS8/Q3QZc8/Uve2b3OEIVx/Iyzu/ZtvCQiFyIX3l/ymshr5CV3fj+UC0WhvVMopRCFhFwpJfEf7LRXU0r+AUkpyoV7F/wDZp0dz8yes2PPPGfmPOe3n9Pk9Ubt47vfOeczg86PVlNjQBBeiO5eyBwNLyTVQmBVWo2sJPHbrYqUHCZ7yDzHOojoHHAZ6SCXA6tsgU6h64UAkWGrOSD4vZBKMXshIkNEjkT0s6TaajR8P9FAG43onyxyI84O+HneHjJXXA53EJ8rF3IvZDqwBJzEwq9IQL8vnTRB7IVY8UKghShWCjkx1P0Dvxfi0FNNfJ+PNyF657GmArtshmzIvxciBPT4fTnVwiIk8zwW1guBVRf5IZYK9awY7SHOdRDuZy29DgITsudUYJejyk+/5vrnD4r35VSHcccLEUuRH1KGjJkj4sJ6IfQHRN09fPhRp4MA8PR2WxxpwlToeiEQH2mqgAUvpILyQubAXsg4+QG9o5boIdi9EPc6CCSF0QyB4+22uAQ5kC9DVj2PxwPYUB3gohcCLUTKEP38gIXxQsh3ECkrfOXiuh0Ejrfb4qh0f0rPCzndV88RA6KPh/BCsjpIuofMifJDu4fUkD1EvufrSIJkpAbqPBYcb7fGFC4/YDzUA6LphUTQ8ELkFlLLmSFoL8SBDgKdI/PydfdCouPt9rkM3UJzL2T0fNyvxhDxQjzcXsiYPcRgB4Ee4kCCqPMCvxeyhcJ8BMEtxO6H3D7gQXHW90KQXojcQfT3Qkx6IVQHxJfuWY09IdlEx9tpcBA+8bp7Iatun3yX5tzJk7fvVmPIeCHq81gF7IWYOJPlVgfhPiJBMnrI5hUBFc4rskHDC9lwYcCqVlXCnBdSseCFKDuIp9tB8F4I3Q7ij9c/9L2Q83TmI1hxBHqFCS8EoOOFeDm9EHHVsjNktnSZ9UIIJ4hGemh5IQcDSqw+Mm7r2DXfCofMeiGQIZp7IRrnTAx7ITQ7iLJ/wI/5vZBbAS1Wb4FcyPBCdi3uWmLhIg0vRImn74UQO4/F6JGZFQgv5HJAja3jvGVqbdci83N7IRWFF2JtLwR+pddDKO6kc85G9w6EF8KnA3rs2/jfvZBFH7oWebUU6YV4BryQDArwQqh3EA4JYjJD/FMBRY6e+V+CXOtaZe2keyGMGJz5o+5h6Xkh1I7vjuDwmf/shazsWuUa1gvxHPdCGC24WLgEkfOD7HxEE9LMPpNleUAWEvRCZhfjhbjQQfr5EV1yfuTxQigdb8/gVDPTCyEyIPm9EK9UL0Qs5F4I4Q7CGTffQuwfb89kSt5Pp5cgE+uFMFIM/HMGGaGxH5L+VkXqeHs205IXQqeDLMR7IZ7TXgijBIdlLkGIHN/N4jL9DmLRC6mV5IWQTxC/3z/ElewaSC9kC5Xju1ncGt4LIdtBSvJCRH5o9RD40aAXQipBOCxzLYTM8fZsDiZTg2qCmPNC5pThhdS0vBD6HUR8yqUMyeuFENM//sf5oftYVDtIcV5Iev39M8ReCOSHLnQ7CIdlrIXQvn+VYMVmyQshlSAT64UwKvicQX7AXgjOCzkSOMPqI+keQrWDlOSFwH2scr0Quh2EwzLXQq4H7rB6ixsd5F+GTIYXwojA/WhBD4ngHO2FEDOk/nv4vZWEagcpywvxaJzHYjTgsEy2kOOBS+w7QztBRH5ETJIXwojA4w4Cl2/AC6F7SFHFVGovhGyCmPRCBOq9EIwXgt8LodVBOCyjLeS4K7d5BRtJJ4hAx02fAV4II0HiE87EldML4an5oPWcnzHo3+sFyCZISV6IR8ELYRTgsIzvhZwPHOJ6ai+EYoLE97Eq5XshtZK8EIIJIjz0RAcx5oWQe9bPWO8tjCGbICV5IXUDXgjmTC+ZDsJhmd8LIfe0n9HsG/ZC6CWIoOJZ8ULkDIGl0UOc6yCw/5E4j+X7+l6I2k0n+LyfERwZ9kJIJwj0D4NeiPyMLO0zWTVpPmZuBzF0IutS4AR3mi1XOsisWTPQCyHbQUT/gMu8F0LxmVgSBxXPyCKbIAgvpO6UF8Lsw2EV00LIPhUryYrzDvggufZCKjp7IeS8EGadoU832guRn/rjwpb6is3KdxaSPM1L3AtBdhCASgfh8jJvp++h/OSf0U96b1FLkInzQph1xB4I9BDjXoi4SE/I1i3q96HTG5CJ80KYbbi8irHTz9C1C7ceb7rhpKdyxDPuhdQJeiHMNj7nUv9AeiHKN+h0Oh2qz8fat1F+n20E/QSZBC+E2YbDKrCFvDgbhuEVmk/IOrqx2XIqQRBeiOecF8IswzlPXsV4IZ0r4V/OPgnocfhM6n2EDnWQsr0QQT2rg8heyMzvIOgWcuJBGHOFnh6yf0+z5ViCYLwQz8heCN4LcaaDSJ6HcS/k0dkQIKeHnBr1TnQHOog5L6Ru2gupGeshzC4cVjEt5OHjMEmH2IRMRWPhZILk9kI8x7wQZhepfxj2Ql6EaU7Q0kMuQX4kL1c6CGEvpGbAC6HQQTgs8y0kLufAY1rPyrrzdxacTJD8XojnlhfC7MIj4P98s15IXM6Bsw8bEXeCAS9/vgxscr2ZRjrt7kaClOWFJFY2IkHGP5M1AzpIngyJyzlw9p648yv0kCefot/6VNyN39X7T01fmjq8NeOJ7nI3l9eyrk1gQIx4IWIvxCkvhFkltQdi1AsR5VyejwihhzwJBUEhbJ3e3B6w8fqp1erj7WnUeyEWXwMNA4LaC6m47YUwTRxJkBehcj7idao/H4KfgXn23Wq2k+x5vVo+vgtzkbnmd20CA2LQC/Fc8kKYVbgAeoQZL6RzRTkfCfZ/Cgd8CoxzuS2xcVo1H8oMGfZCFnQtAgOi7YXo74XUKXohzCa8kAQR5VyVH7BggowPyNYjbRXnVwwfb4eZyF5rPnStAQNi0guB71bK81ikvBBmE9E7fOgg+byQVet2HFsX/xrKuaJ/xFdihEzfyDp6pq0m8bKrfcebI2ipvJCla/fuXXBtoY37WTAgk+qFMJtwExmyasf6Xp/dp/u/gnKekR+PQsB0fhxvj2LLVji+K83EOOvQgk1dPPgBwXshdXe8EGYTnuog2V4IG9E/Vm3vxexeJXbOJa48HEyGoBMWFiArjrRHs1GI8YejjGkC2XshQDNi+RJEjOAGZFK9EKYFwQS52QN2vlHPx4lUflw8GxbWQO60M9k8tf/y3xGS7+1mL3h3+hJEI8EMiHUvpIbwQhA9hFmECxhc+l7Iul6KLxHfVfMB/ePEleICZF97XJoS8ryo352+6FW3PGBAJtULYTbh+AzZ3ZNY/zsrP/jjsLgA2aw3IDATOmvp4m5pwIDY90K8IrwQ0h2EJ8jrhazvyXwNEzxIzoe4gQU8Mnv4/XC7jY0QeV6A5oCl5RURGBCEF1Jx2QthWpBLkHU9BT+S8zFkp79NHe41/H6dO/oD0srTQxYV30NgQKqzgHK9EKmFFOKF0O4gjAtyeiGnd/ayE+TB0POxOmGSiw2z79fZ2MZGiNoLiWnGHOiiMJ8gM9cLYTbhyAzZMPwFS/z6KXyFStvpvH8DC3jQMPum6KPtvAPS0l2IGoIYEKwXUkF6IZ5JLwR+RbWDcAlNL0TMh8Svp6Pm42H6jNbDRp9b5vzytgYaeyFNOUJ2dfHgBwTwZqwXwuzBsQmyvafi2cdvg+3zG0PPNzmRno8H4luXuffrTLc1yLUXAn9nW7dwoIPQ3AupwTVzOwj0D30v5HRPxY/3V68OjpcMvy/kcfr4yYnGgOkSOzp+L0T8GaaF4BNExjPqhdTpeCFMC1IZskM9H+8/fxTbH8NPyBo6hvIWTp9MBUa4hRqQltZa2i0FGBAaXghyL0SdJoQHBMjhhagG5Nn7iKvvozu4g/mACXk7tL/eAPxT5j0Q/F6I+n0hMeXUdBgQKl6I9jsL3e0g2AQ51pN58z7i29PwQXLGYD4SdJJ3f/fsDwxwqa2JPBNj74WU5FFBByHihfwh7+xio6jCMDwz2126OmsELLau2u22iqWaWhYv0NQCrUWCBtRaUiUiGLX4rzWFC/XCaNR44c8NMTEhJibeeDez7l7ohtSqiTYgQcQoCSSSCDeiJv7dOdOz69fZM3P2fHtmds9ZnuOmkhS46cs77/nOOyfR2F5I0xuFxETq7IV4Q/oP7zjbvHMux99+k7ovZH/1C4CSHkK5PWTSxMKdQcBHKt/TZUUPOEicw0FasxeiIZHJQ67zKOTU3KlPfphb5E3qDVn7q1tUD1fdjhDG7SEbBASCPpP1tBUt4CBEHbL0QvSweyEyZxBIIfX1Qq6n4gfh1aocA/kctnirGdzSuEk6wH0eC2jsJKTD4EZvyV6IhkQmB0l5jyr+NFfhCa8+7oD9XdjiLXsHfAY32KLsMzGI9UKWW1EDGUTeWUiIvRApM8iig9Sch6QCZyE/fOKrkCc885KH6XecfJj0Yeu6hp3mFe+FNDSDhDYL0cObhSTq7IUolkHEPCT3B7WHRTlI8sP76Iph9Q1tJIfk+m1BdptAxL2QEUsc8QwCwD6WCrMQqhcirUBiAL4XsuOfG3wt5An4fQ/D4xXwapImFIVsERAIshcya2ERdxB8L8RQvheioZHHQYb7s395NnrnytwBb1g89inNG1XeAR6yORvpaRPxXsjFlRwSj74SAgLhziGeDCJ3L2Tpfm9CaoE41NkL2Wfb5/66AfRxfI7wSMWDhjaQd1RTCZ0ogka4QJXNCVgIpheC3OUVd5CoeiG65L0QrfnU7SHucC/7zx9leZwi6oAnrNHyxm21QvZ7E4hXLaOis5ApoVkI70I/YYlnkKh6Ie1y90K0phOrtxeSK/+jffavP37++dTM23OEJ990v3f4Zdi1PUadcmewzxZj4xReIPheyIQlgICD4HshbbV6IbpAL0TwTFaLO8gOm3Du7FFHF28fPTpz8uRrj+53TylO7fVs2R5j7GBROeQDUYVEPwvBRXTxOYjcsxCBXojsp3mFeiFT/XaZs8Q8Th49evQF11u27qhKEm8tvWSqShE007YYOaxA8LOQMQuJuINE1wvRBXshiFkIpQ0lHKROD4Gq7Pk5B2Iir6ZiuUk6aP8Kh3hjSf8FiBaoXjKj7oWsPmhFDzgIWRdoL0STgFhdvRA4O/XvXJnjM7GhjTZAP2S9CYpgMGlLUQsJ6oWkuy0s4g4SYS9El7kXoslAPQ4ytGRvdeZ4xUPGbX/eJ/p4D/TBzCEbG38iCzQh15sV4wbxj4h6IZfI3gvRZCBWuxeSqsohnhJg9vxJVyLHTwZfyUlKINBPZ2QQUYVsNbGgMkgT382L74W0ceUQXeJeiCYHaAfZWhXDz8/MzJwHffimkMd6kjHmAqbG7Sh7hfheSJPe7g4ZBN8LgSXeC2mPvhcicQZx9IHuhXDHBNjIuu9hShH+CBWoNiZNPNznscY6rYYCDhJpL0SXtxeiyQHWQQazNhJngp5ieQd8CHXWQzYOg0DCnoVMdHVYjaYj7jiH/LOQEHshkgoEMgdXLwQ/qzj2nutJ7AwiXg+519GHqIXQWhlbvrxrZJZr70oCBxGdhUTfC3GXYhkE6SHD/TYWZ4LOcBBQDZDDK2TSUYegQmj/6Oq0mgZkkAu1F6JJAq4X8rKNJhdL0QoBQqmHTCcJJiA+CxmwmkkHqCLSXggjg0TbC1EkgyAdBJ8PRom++DMIoh4CZZAkOEhYvZCbrWYBcxA3h4TfC2kLsReSCKMXIu8cxIU9B/HmkFG8PuCMMEMRYvWQfY51uPYRooVEca4dH9LLSNcL4X1Pb2tkEIyHoIcU05UnNJ4MAmDu18nuNpOwRGchsPqs5gACIftYF2ovRJMG/l7IEHpvCTIMIoOgClTZIeIdoaeQG60mAQIx8ED+wPZC2N1073KheyF4D2k1B8GeAxkfBn1gZiGI+3X6N3v8I8RZSJMFcs1lYTChbi9EkwjOXkjOxrFhyrsnlkTlEK77ddbliH/Ax8QjpYNkDoXCrnQksxAd7k5H9UKofK6Eg/B6yKSNYt0g9aZe1qLZUfuv2GomKQcRnoVI4SAgEDHeTUs7C0kokkF4eyGDNor3n6j6E/wVIVIP2TAI+UMkhbSwgxw69GAkvZB2wV6IUhmE00GmbQzZ/aAMUAgyh7Dv19kyCM4RTgqRKIOEJpB3Fe2FaDLB0wtBnjIZ9eQP8pXzTBbAvF9nfIr4B/XB08oOciiaXkg7theyLLAXooCDcHgI8pTJ3lSM20FgUQyPM47vmkmEg6B6Ia3vIPL3QjSp4OiFrEMNCFMxLoUA2HrIvcOQP6q+mnha2EGu8MxBOGYhnDmkXbgXolAG4XCQURvBDkob+FkIux4ySTlHuLOQlnGQtWnhXkh7Q2chCUkFUqsXgin6jYMHVX1oRQCYesg0lT0EZyGt6iCPpyPrhehivRDFMkgtDxnCDAgH/f0D0wsBTB+FvJw0WaseZMsgxe3bH7ysmgMLi1R+eeV2F/rbXiHfduCyy9IivRBYDeyFSCsQdi8Ec8qkf2ssxasQHkyqHrLP4xcEU3AWIpuDzJd60/FFjCXcWnTZRH6R7i05bF9tUMwWXboCeyEqzEI02WA6SA4xAPmYoQ9ELwQwvfWQ7G7wihA9RLIMMl/aRfTh6YV0FV1uIjJ4ruRypU8v5Nqiy61K90I02WDOQSb59fH7x3T2SKHOY7HrIdkh4hfsz83LHdanTX6kc5AD8TIGkM4UHTLENK4suTxn0PTcVnRZpXIvRJMNsXeZgD7OMh0EnUFI6gaF9G+u5R4TXWu6rTJ9swNjaIVIkUHme3viBE8v5Kaiyx7DYfX2kkNv2vDh7qLLgMq9EE06GL2QaYQ+zn0Av6+mQjggnjAKx3dNOn/A156BTquKvhE+I5HMQR5fog+g/PBkOOwpuewy/FhfdOluaC8kUX8vRAkH0cJ4l8nv57L2S6AG4VkIeMjudbbDeI7pHukR3x/r+ZUT/AqRJYOsiAPwnt7yw9OE8/9rSy4H/LvpVxddxhYziJr3hWgS4t8LQZwyceRh2y+53sH44HIIeMTmD0YHmbmjZ+W8FcQaDheRykEyHn0Aa8jDk2FMlFx6ewxfriq6XLUkg8jSC/E/j6W2g6BOmeAchF5+mDxr+UGLwY3Xos70Nl0gfR6BwFpefngyrii5PB7QTR8rutyuxDuyEopkkMBZyKiNYl8KpxAeKrnDDPaPAasGK81ayOQgnXFfC4GHJ/KEtcIIoLvosh72saKYhYjfWahUBgnykC1IgTC0gemF4Dxk1qpJRw+vQCTIIJ0rApglo5AHF1x61wdB9rHW8L+nF/ax5OiFaDLi2wsZsnGMBuePFGQQ7Jks9tyjp4Prh65WEJHIQeZLQRQRXN3jd19IG7IXAkTaC1HVQTZiBYJ0EHrhU0iHxUVnDQ+RKIMECyRTRHAt6r4QRgaJsBeyzPtV4gzi2wvJ2UhGwSu4FVIbk5VD1lic3GSyUcFBFooIZuE8lmK9EE1OaAeZtpHsBiWEOgsJXl0WNyMmE3kyCAhE6BnrtjTqvhBdnl6IJif0HGQvWiDMOYi7Qs4gYxaC9SYTaRwk0xtIplgmczUL8m2bIrovpLKgF5Lg7oUsW6oZpTKIn4MMbhFzkOhnIZ0Wgr64GgLpiANVs5CBostCqbTWCARO/uLuC9Gl6YVokuIzC9nbb2MYIh7BrZAkYhbiNwfZZKEYMJnIK5D/WU38o1TaY9DQJ391XcleiCYrfmex9mYxAgEdhNwL8V99FoobLzZZyJJBiEDo81hQm1qAqpQPbZWTv124+0LaZemFaLLi2wsZnO7nFwjkDXwvBJ9BnraQdJlMZHWQePXDU+ZKgwGc/K3rvpD2pZ/20Hsh6maQoGn6zq//PhO1g8DyRSyBAH2KCgRySLoIrRAgsDbFm0FgFiJDL0STlhhNSv/a4ZfTNg+bwStC74XQ8xDYwgprI0tagUAIWagc6QUYtanq+0IMJXohmrzE6LXt+ROuRP48zRFGpkAFDZiFjFhoVioqkP9zyJ4FqE0F0Qa1KdAEYhbSyF4IaETy07yBvZCdBYcT3y3ayG9nap80ifF8wskh3RaaPq5xerfVVGZ95UFYWyqWa1Ms4OSvrjeoF5IQ7oUo6iAPFAhEI38yNHIvvPOnMbMQqw4meASy0moqm4IziFOV4nnGgtoU7u70S3TxXgj+Pb3KzEH8UshDBQfQCDGS07RK+ieHlnpEI3ohq+r64eOxkIl5q4lAX4q2kCsqAuk2alCuTXn3sRTphWgyE/MuYiBejbhO4qjk9Jl+VxlnTp8+9fcvD1EaEO2FTMx2sqnrQehgZy06Nl100bVW87hxVdwfw/lv7f/nsVbVuje9Upsyou6F6OK9EIUySFUv5JkCxfOOSGi2UTlDsBfSxMec7rFbPnrXag6Zb1+/NB5oIWNwpHek1g3RI6Q2xcggor0Q8BA4kyXYC1HOQe4v+HPixHdlTjg8Xyjcg3YQ9hqwmsjBB/L5w198VYPvrTo4wv4zv8jn89sCHcR4EI703m7UYFW5NmXoUfdCEjV7Icu4eyHSZxBvCrm0wMv9Xo/A9UJo/5iwmsmRPA+HrTr4Il+bnYEW8mzJ5faiywqjBteQ2pSuK9cL0eQmBuvFAi93UQoQmoU01UDgp5jN5xaaTL4WYCE0K0ouz46UN6hqzEIGSG3K8Y+oeyF6mL0Q6R1kaS/k/gI3O6m8ge2FSJJAHL7Mc3HEQvNtnoOn4v4Yj5dcrig/PLUZbFZnSG3K0FXrhWhyE4N1V4Gbp8QdBJYaAvnKQvNNnoPL4/709JZcJuLk4elpgwVcmADeEVkvJBFKL0SJOYgnhewsILiF8ghOhUi2h0UEwsVnFpJMXkQgB0ouaysPT3cbALM2pRuK9UI02ak4yIsFBNvCSiFJVRwkj97HOiIkkF0llz2V2lSmx4hz1aba9Mh7IcwMkmixDAK9kG0FBHfpVNbA90LUcpDDGQvF/JciAoFbpeC2KSaV2pSuM3ohflAZJIpeiLoZRKOmIHy8iHQQ5TMIOqYfyYsIZBO5VSpuxOG2Ka7alKEbkfdCRDOIQnMQsBA4Z8LFnR6PwPVC1Mwg+fyChWDhsJBAdsGtUnDbFFdtCvKHDlpB90IA8V7IskAPUcJBKh5yVwHFzgvOQfI/Wgh+zIsIhNwqtT292AspPzyxM0hbpTaFyCCoXgh+FtIiGeQ/9s6m94UoCuP33pkRWhWxMCHxFhHCTmJBFxIhsWmoWkjwJywllNhaCAtrG9+ADyCTigQLb5EKVhIWPouZ3hmn0/sy93TacS59bhqCWHk888y5v548Q1ojnOA+FpIL8bWDpPr23FmPk1oGga1SUw9PVgE2xYVXXAijryA73RFO/Y3IFuJ/giTJD8QDVi2DFFulouzsOYXCpgRfPhfi8D29/wIPMp0g3RFSQyUjcA7xr4MkyYezjm+w3icog4jpk2orbJUqbZsqFE6fPyq2TXGvuBDmgwIWbB4h9eg/TJDkvVtRHyfOGr826kbOhaTbphA6LbjwiQthHiibg/ARUn3IDjQX4mkHyRyy2yE/xslCDLIliuDhyV1HBW+OC3G5j6VyIZ51EEOC3K18xkJmyD+QIKlDXlb2j/fJQgyyFx6+dmAMcpAL7hEXwnwQ8OhT+lT1jBUEdbkQ/xKkemD440OyGINcBTr9GHLblDBzISE1LoT5oaCnGqQiQvr/ZYJkIWJhQ959T0D1DHJyii48jXHILcE94kKYF9Ld5f30qXJWGNTmQjxMkFTfDU1k99cvCVIXtyq6I1Ep6Y5p5vzc1grlf4xz7g8XwvzQI41BqiJk0AmQ599IkFRffj7WlA+tPfBzkByVgvyIhCs29WfblD9cCPNCm/s6g3yqvo+F5EL+hQ5SeOT7t+mpyNlv42QexWZUajpCcNiU4FgupKqDQH5AhixmFsK8kA4GuVsZIZv/2wQpTDL+/jXV959j1N9iN8hDiUqVv6c3x6Yyu0QO2JTg3nAhzAutjXQJUuWQ65AfdbgQfw2yAMWGJ6xrUaHph6c9QrhtmxJYLoQ3woX42kGuj3QJkhnkpv1Fbwd7/q0EWahBAJXKtL/8LVlIbEpwb7gQ5oMujgwJEke9kVlrSkaguBC/O8iyDHICnrCmIgSJTXHOsVwIn4MLQbPpMkO86yDdkckg94LIRhpeWiVIXcUGVKr8i38enjJCxG3blEMHITELYR7ojNEgl1gQPLK86IWegeZCVh0EDKJBpcr2gIcnx21TAj8L4YVgZ+HSuBC/OggfGQ0yYUUGtu8gRZ9VgpgNAqiUui8kf3iK3LApIbgnXAijr4HRILHsEeamvlHJB7RDVh1Eh0rNGAQenva7bpsSaC6E1+BC8DsL5fGhg7T6RoNckrQhN/Lqw1WCLNYg53NUSrMvpMCm7BlSYFOh8IQLYeQFQ0Llqknxvb3XLbdNghpcyKqDzBpke4FKqRHy8EWmfWKiqGrblOAczYXwprkQPzrImtEgg4Dlp2e+bYI/qwQxG+SwRKW0Wwt3Ftum7Bkit00dE5P8IMGF+J0gkA7KnJD/+b9/ODKIy9/HcSGrDmIyyElApcqCVZ3HRYWKhQmco7kQpYM43MlKheVC/OogPaNBYmX/raohWyXIAg1yFVAppYNEEps6DfexqrdNCfzudDiLnIX4myCXRkaDdGF3iHG7zpk0KNA9ZNVBTAa5DaiUJkJOFw9Pdu3Kb/4aZyGheRayTC4EeodPHcT4CvdTL2BwTK+6emyeFkIoQV59Sf6qYs1WKdPWwuLhyd5BioUJoRBoLmTTcrgQjztId2TSJEDg//2BibtlQYDnQmh0kN3fxl+Sv6zYhEqpEYLFpgRfGhdS/zuyfOkgZ4xPWNBArN+82A2YpwmSEk4EFBtRKdUhsG0KeogNmwoJcCGed5DNfaNBDkxygP359Cz3FetxIX/FIG/fJyQUG1ApVQK7bUoI3ggXsh7PhXjTQQaWL6dm5XPPBE3VbiF/wSAvfyZEFJtRKVVIbEoID7gQRlkbjAGyVvQP+WN6Nps26XQ6QT0upHmDfE3IKDahUqrQ26aEaIYL4XNyIfQ7yHUzTQvZYZ+mT6btniUImfgAg6iolHYWkj88QQexYlOhEPS5EEZZa+YHrFSs/BmYBiEMZiGYz99KkN0fE0KKraiUCZty3TYlmuFC1uO5EDkLIZ4gQ+MDVhQw5XQtXaWDP38rQd4Raee5YhWVMmp621TkhE2FfJ5ZyPplcCE+dpCe+RY7CP7P1+bNI5Z2EBbU4UKaNQiJl7ugZ4cL3QZUyqTi4enUvgrtKrAp0QwXwlFciC8d5JL520qY5uhnJjfl73mTIN8TWhq/LutJZFX68ITQVpGJh5S5EEZXNy1L0FkgJbNB/jjUGiTrIJ1a97GaNMi3hJjAIIBKmZVtm0LouBANcSHQQZy5EPIdpDsy39DVHq7F0iFB0Kf5BPn816+WVBjkRmQXcttUKEK+EC4EDoIL8byDnDG9wWIyPtQe0tN/bwNkCI4LCZwS5F8uIKpBtkR2IbdNHROiIS6EO3MhvjDpplsmay2WKtCdgSVBmA8J8iMhp94dqe2AStlUbJs6sq1CR/Kbv6EgzoUwqjIESL/LUsn+Mfu5pDOIzA9WgwtpziC03vBOFCuolF0ix6YEyI5NmWYh4WK5EJiFgCq5EModhPdNI/SJAu3p66h0VreFGA3yHwRIEquolF1T2FTkhE2FnAYXktrBpw4yMLzhha2Fmh5yUU9MyQzBcyHNdhBaV0xmDHIMUCm7AJuqENz8VbmQkBAXwmgq0gfImmC2BBnYEoRRT5B3CUHF8IQFqJRVgE0BF2LDplJR5kIYTd0zFhAp3RxEu8mwV3SQ+bkQq0H+5RlIbhBApbZGDsJumxJNcSHrcFwI7bdYa3r6iYECzWlp32LVbSFGg/wHT1hJrKBSVYJtU5ETNpWKL4ELWY/mQnzqIENLQVdbCHAhPfMcZC4upMEO8te/v0SvuBKVqo9NEeZCqHaQi1q0g4EMLeSMNUEY6QTZnVBUrKBSlYKHJ+ggVmxqLi6EL5gL8aqDXNJeGmFlwX0s+Fw3z0Hm50IaMQjNl7zSIIBKuQm3bSr9WT0uBDoIYhZSyYWQ5kF01xR7EZuRAxNSP0E6DSUI0Y6exAoqVa0Cm4qErYfAwoT5ZiEINh3DhfiQIF3zCyxDCzEzITczV5hnIYHDM9Z/bxBApRyF3DYl9FxI+Pe4EOLfi3XT9gLL3kJuankQOKsEQSpuwVYpV8G2KTubfivHpkLpECwXwpfEhZBPkK79BRYoULmQgWIQyI85uZD/PEHasFXKWcq2Kb1L9vxZmLBkLgTO9BzE2w7yyPoCy54hwyr6sIM/DRnkcUJRcasNW6WcVTw82TMEFibMx4XwBXEhnnWQAxoskOmk40IixSCdvIPMzYX852+x2m3YKuUs2DZlFdz8pcuFMHIa6N5EuSZI0Kvi18kmyNmEotIEga1S7sofniLrLAQWJtSYhSyHCyGcIFHf+oIXpOdCzui+F6vGLEQmSCNKKCpuw1YphJDbpqQWzIVsqsOF0O0gyjXFtc0MVJkh12cN4k2CUMSlsgQBVMpZsG0K8sOOTc07C1kIF6L4gnQH6esHII4tRBkVDgpH4LiQ5jsIvW/8yRMEUCmMsNumSHIhFO9iXTcMQJxbyNqMQfxJEJLveWNApVAqPzxFldhUOB8XwufgQvzuID3lO36sUrmQmzMGgezIP1TnIDRvK8aASqGE3TYlqHIhjJaGyoCwShV7Qu6pGUM1QQh+6U9qEEClcJLY1EO4j1WBTc3JhfBFcCFlke4gPacBoY0LuTRjkKJ/ILmQ5jsIzVFhDy7y4oTdNiWa40Lc2XRyHeSS8h1x6ATZOBNBHiUIxfdYzyQq1Y5ASGwKZiE2bCpc+Cxkk3EWYr2PRbuD3ET7Q+VCLpYNIvOj3ENI8iDPSdb0sUSl2hFa2G1TRLkQRkldhD9A1u9XHAZMPVQThCB1OzHI4XYLHILDpk7vqNCRApsKm+NCuAMXQjJBHuH9oXIhw7JB5L/yUo50ZmYhROYgzym2kIlB7rTbYBAENoXQfiHqcyHrEVyIjx2kq+nn+ASJymMUrxKE3rBwPEGlUoO0IqyOYAxySIhlcCHrre+x7D2EXoLc//UJ7Q+VCylThd0A+gd8iHYQcgvYpEGutDNFWJ3AGGSXkFoCF7Kpggvxp4NcfvPmzS+8P5ht01Q3YLpDNUGevyK2ISQzyJNWu4VvIfhtUw1wIbYWwql3kAdvJspS5B5DKSipdFtlM8xBSvMQinOQiX7Qcsg4Q6Xa+AgBbGrfwQrtKt385UvgQjZVcCGedJDLb6R+9YcMhE6QcpVpeZYg1BySGuRGWyYI2iG3pEGmuMLIik2FDXIh+g6iMLeUEiQLEKn7DCOVC5kuIZNf62h6CM0OQs4hqUG2tHNFSIXAnFtVvvnLF8GF2O9jwSzEp7dYWYBIPWVoBXBK9xX7LDAcsgmS9hBCTX38eq/MD3QLAWwqggypwKYa5EK86yAQIJcZXsG07k3RVkEnP3guBDpI4/pKJkTGr6+2C6ENgt02JcVrciHrkVyInKWTTxAIkAesZoJcmjKIjwmS6iyVr3ofvz426R/yE6EE2FSRHZEdm1JmIWFdLsT1Tu86+BDtIBAgby4wlFQu5Dd7588aRRCG8dndOzzvzgO3UNxb1MY/KKRIaWERItgYRVIIoifRTlDiNxBDPoA2aWwstFYR5CBcEUVEQSvBQj+BH8Jdx+O9vbmd3Xdm/7zZmWcYjsCa6l6ePPvMz+nO8OzTDCLmELIZhGtMY0S+bHZ76haCvW2Ky6HEhTAiAgOZMJCih8Ch+ZvMS12UHSTW1x8EjmZ9CXpdWG2MAJty23xlY1OKXMhAhQvJPo9FKIO8nGgPCGjmvOIDyB+LuRByPUhCP7/XnUa+HOmBkBYC2BTitqlYQg9SOhdCPoOsTUBLug4CXOLntX3sILFqP+D7Cvyjh3yPBdjUOTejCwFsihwXwmhodkDWFB0Ecohz+/PvWNHvin9O7UIoZxAiA3KFTwbCQjRum4K/sVK5kFa5XAhZB3k8mdET7RQymWqbeZJlHSRTN8FB0CkEsKnTLnQhcmyKFhdygMyALE1mtaQbQmaGDb7pmVwInR6EzoAc7YEQFoK9bWqFY1MQQkrhQgYLuJB9kkHYve0JaHtJ20HgV1kH0RqQhH+gBwRum2q7Mg8ZTi9MaFHhQmIRyiCM3ZiNIbfOqgwIcCGzw/aSZ5CFXIjNIJkDAi0hwkJ0bpvicirgQgZJLoR0Bon15JbmhCQcBLT2JN1DrIPgHASfQlbgtim+5LdNcQEXkrlaxXMhVAeEnX22DSd6tVLIJKntx0ueAhdiMwjPIF2NFAK3TYHkt02pcyEOmgsZJLkQyhmE6yy4iNaJrLXJvG49u2EdpBAHQQ0I3DbVbku7ELhtCrqQFgUuhFHTyzXdM73MSwwImNLZRV2IzSB5MoiGhTzE3jalzoU4ylwI/bdYM1p6vP2vwdBIIc8moIw3WtZBEA6CTyGATUEGaWdjU3S6EEZFRy5cCKbauvvm2Q2dLmRpslBr+bkQ24MIGQRhIXq3TalzIY4+F0LRQbaCcGdPUHh/ZV3RQY4EzxcZyIvXW9ZBNHsQfBcC2FQbuBApNoXgQlrlcSFkMkgAwyHo/lDFQ+5E//Lp8+cvYj2P9OtPJP4LN8UzWTaDYHoQvIXgb5vS4EIcLS6EZg+ysyfRioqH+OFeijZXFqQQ6yDIDIIaEMCm2tCF5MGmWiVxIcKinkHW76SOyGhLMYUM/eB+mBiT5XAUbK2ncyG2B0l1EPAOJQsBbCpDcPJXgwtx9LgQmhmEra8Eo3BzD7QThnc2LjAFif4wTPxkHUTLQfBcCGBThzPOY7nTk78tSlwIo6XhhSMMpMmFJLaEC7EZJEcGUeVCAJu6eDpD5+Dkr0YXos2FEHSQYuWhl3UQhIMguhDAphDi2FRxXMhAYNPzdCENHhAvIfACCRcy5xm2BxEyiGYXchEzIcdcV4cLcdTuTiedQayD0B0QcA0NLuQYZkBibIoOF8KaJy+ScH96tCVciM0giB4EbyH426Z0uBCnAC6k0Q6i4iHWQRAOgkwhgE0dP5GhS1Nsig4Xwhooz8vIISIXYnuQrAyix4XMM+eZ2FTxXIj8PVaCC2l4BrEOUomDwIBgsKm2lAsBbIoMF8KaKMgfubsQm0EwPQjeQoA5lwiwqRK6EDkX8v88lhFvsdQ8xDoIykEghaCwKTiPlYVNUeFCWCPlCUp2GyIXktKDeDaD8GlAdiH6t03JuZBW4VzIXAbpWAexDoJyED0uBG6basu5EMCm1LmQgRIXYlIGiZTVg4g5xGYQmYP0dLgQwKZOtV254OSvpAsphQtxgAtpfA+i5iHWQZAZhA8ICpu6HLmHPIecggEplgsZZHEhJmUQxoT84aX0IMCFpHHpx97WqU/vatVVmAdNLuT8lJqS6xhQU/m4kFZRXAj3Dr4an0GKcRB/K+KuNq+9rVPf3tWq7+Pl8E7gr/Y0uBBo06/Hn66cC7kenXgfupFocCGsqdLkQvxgtLn7Xyff1qiTtf6N9WU81fJow9fkQs6cacfKJAvhLFaFXIjQhXQa7iA6HrIy2k3o/dv6dO1pjZewfdobJzR6pNGFgCCDRFsieI9VGxfS4AFR50KWd+f19f2HevR1dzz++eNjPfr0bSxopJxCQC5CSC5EvwsxJoNoOMid3RI1nu68ayzsMXxWrZ0NDS4EJM8hIMggalxIR4sLaXYG0eFC1jfC3aoEEyPOAwHt/dtcO6NHQ/FMbyUWIrmzsEguxJnnQho9IHpvslY37oQ7u6CCJwK96p2ZzTB4tFoAF4LNIOAj1XAhJmUQCRfCcnMhvh8EIdZO9CeGhntE2gnDIPBXu0KfXqGF6HMhHUUupOEZpMg2fd33N+JRCfWnoYgcUrLCeCw2fH8o+IVWFwJygQvJm0OccriQ+WVSBimWC4G96kcFYhBViGG4XG4OqUzLYRjVgZFX+P56N1ZP2OlcSIkWQoALYU2Wp+Qh2LXqRwoCPjORNkvJITA3+rPApyH2CB86crWl34XkVjVciEkZBMeFHMrgQiTr4Ow6GO1Yqz5XMFUIWs4xMcrffq5RwMXHYGoNoLQzVslnumkn3SuykNq5kIYPSOkOIk6IMC2wE+rPrqGvpn6GhO961urJn9PnQkAuKoPgz2OpciEmZRB9LkS+4dmD0RYmQq4+evfx6qZIkivEDMKX8DyZLgTBhcxmkGwupPE9SFUpxDsoX4vUxy/9AemVstTOmyByiDoX4ihwISZlEDQXEistf3j5JySP+twXhE++Iwmf2haSmi8SSjyTkkOqSiF1cSHAprOmq6YUIuaQejxE8l2X5QpsDin3PJZGDukocCFGOYguFyLflWaQwiwkrd8AC0nPIb3k3u9diIwLMeItFo0UEk0LjRSS6gK1dyGlcSGOAhdilIMUeF8IsguRKyV/pOSQ4lNIr/YuxP0n6lwIa748Ml1IjSmkB7uYDLJvuBBHgQsxykFUuRBcH5KSQah2IQvPWYEkz8GuxUKyM4iD+D+yOoPFXIg5PQiNFHKQ7/pTSA+WhofsMy7EUeBCjHIQBBdySOBCEH2IJ05EhhA9SPEpRNpvZD3HdyEWQpwLYSaonhQC02K7kFq5kI4CF2KUg6hxIdgcYkAXIskhOhZCmgthJsirvU23XUjVXEhL1oV0srsQoxykPi5ELpgQiWcI0p0QSlyI+0+UuRBmhjwyXYhXhodYLkTOhfC/rXB9ulEOYrkQqlyIC6qOC+nk4UJMyiD1O4jlQiQZBFaWWspcSCfzTJZ1EMuFUORCXBWJPUjxXIhZGYSCh+y3LqRLlgvR7EIG+bgQsxykUVxInxoX0rwuJF4mZRAKDmK7ENpciLDMcpBGcSF9w7mQZA9SKhfCzJFHpguxXMi8uHNQ40LMchCBC2GFcSGHKudC+pYLKZcLGfzbJmWQ+h3EciH1cCEtdS7ELAdZxIUcKp8LARXJhfQN50Kc4rgQkMiFGJVBWEVkYVO4EPCPirkQUCVciOxMr1kO0igu5G87d5ACMAgDUdRAA12E3v+47c5NCoVGifnGM8gwxKfBXYjMcSGkDpKhhRB2IVrJhbASxHUh/Tgu5Jm/LqRPrAsxuAuRIBdyvu9CcAnSEv1vUtiF6EAXcgS6kOuLC2mwKeRCbLuQ8S6EdkEytJD6LkRXcSFehrATxHmPta4LMbgLkRku5AaRvci+Yo2MWgAAAABJRU5ErkJggg=="}}]);
